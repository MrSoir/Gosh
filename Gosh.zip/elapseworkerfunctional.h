#ifndef ELAPSEWORKERFUNCTIONAL_H
#define ELAPSEWORKERFUNCTIONAL_H

#include <QObject>
#include <QString>
#include <QThread>
#include <QTimer>
#include <QDebug>
#include <QProgressDialog>
#include <functional>
#include <memory>
#include "staticfunctions.h"

class ElapseWorkerFunctional : public QObject
{
    Q_OBJECT
public:
    explicit ElapseWorkerFunctional(
            std::function<void()> caller,
            QString infoMessageStr = QString(""),
            bool startThreadImmediately = true,
            QObject *parent = nullptr);
    ~ElapseWorkerFunctional();
signals:
    void finished();
    void kill();
public slots:
    void prepare();
    void start();
    void process();
private:
    std::function<void()> m_caller = nullptr;
    QString m_infoMessageStr;

    bool m_isPrepared = false;
    QThread* m_thread = nullptr;
};

#endif // ELAPSEWORKERFUNCTIONAL_H
