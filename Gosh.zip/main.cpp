#include "mainwindow.h"
#include <QApplication>

#include <QDebug>
#include <QDir>
#include <QVector>
#include <QFileInfo>
#include <QDateTime>
#include <QTime>

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>
#include <QScrollArea>
#include <QFrame>
#include <QMainWindow>
#include <QStatusBar>
#include <QIcon>
#include <memory>
#include "staticfunctions.h"
#include "filescoordinator.h"
#include "fileinfobd.h"
#include "windowcoordinator.h"
#include "custommainwindowbd.h"


int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    app.setApplicationDisplayName("Gosh");

//    app.setWindowIcon(QIcon(QString("%1%2%3")
//                                .arg(QString("pics"))
//                                .arg(QDir::separator())
//                                .arg(QString("MrSoir_antique_big.png"))));

    QFile styleFile(QString("styles%1%2").arg(QDir::separator()).arg("stylesheet.qss"));
    if(styleFile.open(QIODevice::ReadOnly))
    {
        QTextStream textStream(&styleFile);
        QString styleSheet = textStream.readAll();
        styleFile.close();
        app.setStyleSheet(styleSheet);
    }

    QMainWindow* window = new QMainWindow();

    WindowCoordinator* windowCoord = new WindowCoordinator();

    std::shared_ptr<DynamicFunctionCaller<QString, std::function<void()>>> caller
        = std::make_shared<DynamicFunctionCaller<QString, std::function<void()>>>();
    caller->setFunction(QString("setFullScreen"), [=](){window->showFullScreen();});
    caller->setFunction(QString("setMaximized"), [=](){window->showMaximized();});
    windowCoord->setFullScreenCaller(caller);
    window->setCentralWidget( windowCoord );

    StaticFunctions::setIconToWidget(window);

//    window->showFullScreen();
    window->showMaximized();
    window->show();

    return app.exec();
}
