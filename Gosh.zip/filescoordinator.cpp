﻿#include "filescoordinator.h"
#include "filescoordinator.h"

FilesCoordinator::FilesCoordinator(QObject* parent)
    : QObject(parent),
      m_root(std::shared_ptr<FileInfoBD>()),
//      m_mainGrid(new QGridLayout()),
//      m_toolBar(new QHBoxLayout()),
//      m_folderViewer(new GraphicsView()),
      m_self(std::weak_ptr<FilesCoordinator>())
{
    qDebug() << "in FilesCoordinator-Constructor";

    m_watcher = std::make_shared<QFileSystemWatcher>();
    *m_watcherConn = connect(m_watcher.get(),   &QFileSystemWatcher::directoryChanged,
                             this,        &FilesCoordinator::directoryChanged);

    resetQWidgets();

//    m_toolBar->setAlignment(Qt::AlignLeft);
//    m_mainGrid->addLayout(m_toolBar, 0,0);
//    m_mainGrid->addWidget(m_folderViewer, 1, 0);
//    m_mainGrid->setContentsMargins(0, 4, 0, 4);
//    m_mainGrid->setSpacing(0);
//    revalidateToolBar();

    qDebug() << "FilesCoordinator-Constructor finished";
}

FilesCoordinator::~FilesCoordinator()
{
    qDebug() << "in filesCoordinator-Destructor!";

    if(m_root){
        m_root->close();
        m_root.reset();
    }

    if(m_watcherConn){
        disconnect(*m_watcherConn);
        m_watcherConn.reset();
    }
    if(m_watcher){
        m_watcher->removePaths(m_watcher->directories());
        m_watcher.reset();
    }

    // Pointer werden von Qt zuverlaessing geloescht:
//    m_folderViewer->close();

//    if(m_toolBar)
//        delete m_toolBar;
//    if(m_mainGrid)
//        delete m_mainGrid;
}

void FilesCoordinator::setThisToFolderViewer(std::shared_ptr<FilesCoordinator> selfReference){
//    qDebug() << "setting this to folderViewer";
    m_folderViewer->setFilesCoordinator( selfReference );
}

void FilesCoordinator::setRootFolder(const QDir& dir)
{
    qDebug() << "in setting rootFolder";

    if(m_root)
        m_root->close();

    if(m_watcher){
        m_watcher->removePaths(m_watcher->directories());
    }

    m_dirStack.push(dir.absolutePath());

    m_root = std::make_shared<FileInfoBD>(dir.absolutePath());
    m_root->setSelf(m_root);

    m_lastSelection = FilInfoForOneDim(m_root, true);

    for(int i=0; i < m_depthIdsElapsed.size(); i++){
        m_depthIdsElapsed[i] = (i==0); // der initialeordner wird automatisch von anfang an auf 'elapsed' gesetzt, alle danach vorerst nicht
    }

    revalidateOneDimnFolderOrder();

    if(m_self.expired()){
        throw QString("FilesCordinator.m_self is nut set or expired!!! -> must not add listener to root!!!");
    }else{
        m_root->addListener( m_self );
    }
    m_root->setElapsed(true);

    revalidateToolBar();

    setRootToGraphicsView();
}

int FilesCoordinator::evaluateDepth(std::weak_ptr<FileInfoBD> filInfo, int* curRow, int curDepth){
    if(auto locked = filInfo.lock()){
        if(*curRow < m_oneDimnFolderOrder.size()){
            int max = 0;
            m_oneDimnFolderOrder[*curRow].m_depth = curDepth;
            ++(*curRow);
            foreach(auto subFold, locked->getSubFolders()){
                int depth = evaluateDepth(subFold, curRow, curDepth+1);
                if(max < depth)
                    max = depth;
            }
            for(int i=0; i < locked->getFileCount(); i++){
                m_oneDimnFolderOrder[(*curRow)++].m_depth = curDepth;
            }
            return 1+max;
        }
    }
}

int FilesCoordinator::getDepth(){
    return m_maxDepth;
}

void FilesCoordinator::sort(std::weak_ptr<FileInfoBD> fiBD, ORDER_BY order)
{
    if(auto locked = fiBD.lock()){
        QTimer::singleShot(0, [=](){
            locked->sortBy(order, true);
            repaintFolderViewer();
        });
    }
}

void FilesCoordinator::sortAllFolders(ORDER_BY order)
{
    if( m_root){
        QTimer::singleShot(0, [=](){
            m_root->sortByReversedWithouNotification(order);
            revalidateOneDimnFolderOrder();
            repaintFolderViewer();
        });
    }
}

void FilesCoordinator::openSelection()
{
    if(singleFolderSelected() && singleContentSelected()){
        // set folder to root
        this->setRootFolder(QDir(m_slctdFolds[0].getAbsoluteFilePath()));
    }else{
        QTimer::singleShot(0,[=](){
            for(int i=0; i < m_slctdFiles.size(); i++){
                QString absFilePath = m_slctdFiles[i].getAbsoluteFilePath();
                if( !absFilePath.isEmpty() ){
                    QDesktopServices::openUrl(QUrl(QString("file:%1").arg( absFilePath )));
                }
            }
            for(int i=0; i < m_slctdFolds.size(); i++){
                QString absFolderPath = m_slctdFolds[i].getAbsoluteFilePath();
                if( !absFolderPath.isEmpty() ){
                    QDesktopServices::openUrl(QUrl(QString("file:%1").arg( absFolderPath )));
                }
            }
        });
    }
}

void FilesCoordinator::setParentToRoot()
{
    if(m_root){
        QDir rootPath(m_root->getFileInfo().absoluteFilePath());
        if(rootPath.cdUp()){ // QDor.cdUp() holt sich den parent-root-path, aber nur, wenn dieser auch existiert!
            this->setRootFolder(rootPath);
        }
    }
}

FilInfoForOneDim FilesCoordinator::getFileAt(int id)
{
    if( id < m_oneDimnFolderOrder.size() ){
        return m_oneDimnFolderOrder[id];
    }
    return FilInfoForOneDim();
}

FilInfoForOneDim FilesCoordinator::getDisplayedFileAt(int id)
{
    if( id < m_oneDimnFolderOrderDisplayed.size() ){
        return m_oneDimnFolderOrderDisplayed[id];
    }
    return FilInfoForOneDim();
}

int FilesCoordinator::getFileCount()
{
    return m_oneDimnFolderOrder.size();
}

int FilesCoordinator::getDisplayedFileCount()
{
    return m_oneDimnFolderOrderDisplayed.size();
}

void FilesCoordinator::revalidateOneDimnFolderOrder(){
    if(m_blockRevalidating)
        return;

    m_oneDimnFolderOrder.clear();
    m_oneDimnFolderOrderDisplayed.clear();
    if(m_root){
        m_root->traverse(
            [=](std::weak_ptr<FileInfoBD> weakFiBD, int depth){
                m_oneDimnFolderOrder.append( FilInfoForOneDim(weakFiBD, true, QString(""), depth) );
            },
            [=](std::weak_ptr<FileInfoBD> weakFiBD, int depth){
                if(auto locked = weakFiBD.lock()){
                    if(locked->fileCount() > 0){
                        const QVector<QFileInfo> files = locked->getFiles();
                        foreach(QFileInfo fi, files){
                            m_oneDimnFolderOrder.append(FilInfoForOneDim(weakFiBD, false, fi.fileName(), depth));
                        }
                    }
                }
            },
            false,
            0
        );
        m_root->traverse(
            [=](std::weak_ptr<FileInfoBD> weakFiBD, int depth){
                m_oneDimnFolderOrderDisplayed.append( FilInfoForOneDim(weakFiBD, true, QString(""), depth) );
            },
            [=](std::weak_ptr<FileInfoBD> weakFiBD, int depth){
                if(auto locked = weakFiBD.lock()){
                    if(locked->fileCount() > 0){
                        const QVector<QFileInfo> files = locked->getFiles();
                        foreach(QFileInfo fi, files){
                            m_oneDimnFolderOrderDisplayed.append(FilInfoForOneDim(weakFiBD, false, fi.fileName(), depth));
                        }
                    }
                }
            },
            true,
            0
        );

        m_maxDepth = 0;
        for(int i=0; i < m_oneDimnFolderOrder.size(); i++){
            if(m_maxDepth < m_oneDimnFolderOrder[i].m_depth)
                m_maxDepth = m_oneDimnFolderOrder[i].m_depth;
        }
        for(int i=m_depthIdsElapsed.size(); i <= m_maxDepth; i++){
            m_depthIdsElapsed.append(false);
        }

        int id = 0;
        while(id < m_slctdFiles.size()){
            QString absFilePath = m_slctdFiles[id].getAbsoluteFilePath();
            if( absFilePath.isEmpty() || !QFileInfo(absFilePath).exists()){
                m_slctdFiles.removeAt(id);
            }else{
                ++id;
            }
        }
        id = 0;
        while(id < m_slctdFolds.size()){
            QString absFilePath = m_slctdFolds[id].getAbsoluteFilePath();
            if( absFilePath.isEmpty() || !QFileInfo(absFilePath).exists()){
                m_slctdFolds.removeAt(id);
            }else{
                ++id;
            }
        }
    }

    revalidateSearchIds();

//    qDebug() << "revalidateOneDimnFolderOrder.size: " << m_oneDimnFolderOrder.size();
//    for(int i=0; i < m_oneDimnFolderOrder.size(); i++){
//        qDebug() << "   m_oneDimnFolderOrder[" << i << "]: " << m_oneDimnFolderOrder[i].m_fileInfoBD.lock()->fileName()
//                 << "   " << m_oneDimnFolderOrder[i].m_isFolder
//                 << "   " << m_oneDimnFolderOrder[i].m_fileName
//                 << "   depth: " << m_oneDimnFolderOrder[i].m_depth;
//    }
}

std::shared_ptr<FilInfoForOneDim> FilesCoordinator::iterateBackwards(FilInfoForOneDim fileInfoOneDim, int offs,
                                                                     std::function<void(FilInfoForOneDim)> func)
{
    return iterateForwBackwHelper(fileInfoOneDim, offs, false,func);
}
std::shared_ptr<FilInfoForOneDim> FilesCoordinator::iterateForwards(FilInfoForOneDim fileInfoOneDim, int offs,
                                                                    std::function<void(FilInfoForOneDim)> func)
{
    return iterateForwBackwHelper(fileInfoOneDim, offs, true, func);
}

std::shared_ptr<FilInfoForOneDim> FilesCoordinator::iterateForwBackwHelper(FilInfoForOneDim fileInfoOneDim, int offs,
                                                                           bool iterateForwards,
                                                                           std::function<void(FilInfoForOneDim)> func)
{
     int targetId = getIdOf(fileInfoOneDim);
     if(targetId > -1){

         targetId = iterateForwards ? targetId+1 : targetId-1;
         if(targetId < 0)
             targetId = m_oneDimnFolderOrderDisplayed.size()-1;
         else if(targetId >= m_oneDimnFolderOrderDisplayed.size())
             targetId = 0;

         if(func){
             FilInfoForOneDim retVal;
             bool found = false;
             while(offs > 0){
                 found = true;
                 retVal = m_oneDimnFolderOrderDisplayed[targetId];
                 func(retVal);
                 targetId = iterateForwards ? ++targetId : --targetId;
                 if(targetId < 0)
                     targetId = m_oneDimnFolderOrderDisplayed.size()-1;
                 else if(targetId >= m_oneDimnFolderOrderDisplayed.size())
                     targetId = 0;
                 --offs;
             }
             if(found)
                 return std::make_shared<FilInfoForOneDim>(retVal);
             return std::shared_ptr<FilInfoForOneDim>(nullptr);
         }else{
             --offs; // muss gemacht werden, da sonst eins zu viel uebersprungen wird
             targetId = iterateForwards ? targetId + offs : targetId - offs;
             if(targetId < 0)
                 targetId = m_oneDimnFolderOrderDisplayed.size() - targetId;
             else if (targetId >= m_oneDimnFolderOrderDisplayed.size())
                 targetId = targetId - m_oneDimnFolderOrderDisplayed.size();
             return std::make_shared<FilInfoForOneDim>(m_oneDimnFolderOrderDisplayed[targetId].m_fileInfoBD,
                                                       m_oneDimnFolderOrderDisplayed[targetId].m_isFolder,
                                                       m_oneDimnFolderOrderDisplayed[targetId].m_fileName);
         }
     }else{
         return std::shared_ptr<FilInfoForOneDim>(nullptr);
     }
}

void FilesCoordinator::setSelectionToRoot()
{
    if(singleFolderSelected()){
        if(auto locked = m_slctdFolds[0].m_fileInfoBD.lock()){
            setRootFolder(locked->getFileInfo().absoluteFilePath());
        }
    }
}

void FilesCoordinator::setLastPathToRoot()
{
    if(m_dirStack.size() > 1){
        QString path("");
        while( !m_dirStack.isEmpty() && (path = m_dirStack.pop()) == m_root->getFileInfo().absoluteFilePath())
            ;
        if( !path.isEmpty() && QFileInfo(path).exists() ){
            this->setRootFolder(QDir(path));
        }
    }
}

QWidget *FilesCoordinator::getWidget()
{
    return m_folderViewer;
}

QLayout *FilesCoordinator::getLayout()
{
    return m_mainGrid;
}


void FilesCoordinator::elapseAll()
{
    elapseFolderRecursive(m_root, true);
}

void FilesCoordinator::elapseFolder(std::weak_ptr<FileInfoBD> fiBD){
    if(auto lockedFiBD = fiBD.lock()){
        lockedFiBD->setElapsed();
        QTimer::singleShot(0, [=](){
            revalidateOneDimnFolderOrder();
            repaintFolderViewer();
        });
    }
}
void FilesCoordinator::elapseFolderRecursive(std::weak_ptr<FileInfoBD> fiBD, bool blockRevalidating)
{
//    if(auto lockedFiBD = fiBD.lock()){
//        if( !lockedFiBD->isLoaded() ){

            bool threadingOn = true;

            if(threadingOn){
                if(auto locked = fiBD.lock()){
                    m_blockRevalidating = true;
                    setWaitingAnimation(true);

                    QString pathToElapse = locked->getFileInfo().absoluteFilePath();

                    QElapsedTimer timer;
                    timer.start();

                    QThread* thread = new QThread;
                    ElapseWorker* worker = new ElapseWorker(pathToElapse,
                                                            0);
                    worker->moveToThread(thread);
                    connect(thread, &QThread::started,       worker, &ElapseWorker::process);
                    connect(worker, &ElapseWorker::finished, thread, &QThread::quit);
                    connect(worker, &ElapseWorker::finished, worker, &ElapseWorker::deleteLater);
                    connect(thread, &QThread::finished,      thread, &QThread::deleteLater);
                    connect(worker, &ElapseWorker::sendingFiBdToReceiverThread,
                            this, [=](FileInfoBD* fiBDElapsed){
                                qDebug() << "milliseconds elapsed for folder-elapsing: " << timer.elapsed();
                                if(locked){
                                    std::shared_ptr<FileInfoBD> parentFiBD = locked->getParentFiBD();
                                    if(parentFiBD){
                                        parentFiBD->replaceSubFolder(fiBDElapsed);
                                    }
                                }
//                                qDebug() << "finished main thread";
                                m_blockRevalidating = false;
                                setWaitingAnimation(false);
                                revalidateOneDimnFolderOrder();
                                repaintFolderViewer();
                            }
                            , Qt::QueuedConnection
                    );
                    thread->start();
                }
            }else{
                // ohne threading blockiert es die GUI!!!:
                if(auto fiBDLock = fiBD.lock()){
                    fiBDLock->elapseAll();

                    repaintFolderViewer();
                }
            }
//        }else{
//            lockedFiBD->setElapsed();
//        }
//    }
}

void FilesCoordinator::elapseFolders(const QVector<std::weak_ptr<FileInfoBD>> &folds)
{
//    for(std::weak_ptr<FileInfoBD> fiBD: folds){
//        if(std::shared_ptr<FileInfoBD> fiBDLock = fiBD.lock()){
//            fiBDLock->elapseAll();
//        }
//    }
//    repaintFolderViewer();
}

void FilesCoordinator::elapseSelectedFolders()
{
    m_blockRevalidating = true;
    for(int i=0; i < m_slctdFolds.size(); i++){
        elapseFolderRecursive(m_slctdFolds[i].m_fileInfoBD, true);
    }
//    m_blockRevalidating = false;
    revalidateOneDimnFolderOrder();
    repaintFolderViewer();
    //    elapseFolders(m_slctdFolds);
}

void FilesCoordinator::collapseSelectedFolders()
{
    if(m_slctdFolds.size() > 0){
        foreach(const auto& fold, m_slctdFolds){
            if(auto locked = fold.m_fileInfoBD.lock()){
                locked->disableSignals(true);
                locked->collapseAll();
                locked->disableSignals(false);
            }
        }
        revalidateOneDimnFolderOrder();
        repaintFolderViewer();
    }
}


void FilesCoordinator::folderChanged(std::weak_ptr<FileInfoBD> f)
{
//    if(m_oneDimnFolderOrder.size() > 0){
//        if(auto refLock = f.lock()){
//            const QVector<QFileInfo> files = refLock->getFiles();
//            QVector<QString> fileNames;
//            for(int i=0; i < files.size(); i++){
//                fileNames.append(files[i].fileName());
//            }
////            QVector<QString> selectedFilePaths;
//            int i = 0;
//            while(i < m_slctdFiles.size()){
//                if( !m_slctdFiles[i].m_fileInfoBD.expired() ){
////                    selectedFilePaths.append(m_slctdFiles[i].getAbsoluteFilePath());
//                    ++i;
//                }else{
//                    m_slctdFiles.removeAt(i);
//                }
//            }
////            QVector<QString> selectedFolderPaths;
//            i=0;
//            while(i < m_slctdFolds.size()){
//                if( !m_slctdFolds[i].m_fileInfoBD.expired() ){
////                    selectedFolderPaths.append(m_slctdFolds[i].getAbsoluteFilePath());
//                    ++i;
//                }else{
//                    m_slctdFolds.removeAt(i);
//                }
//            }
//            const QVector<std::weak_ptr<FileInfoBD>> subFolds = refLock->getSubFolders();
//            QVector<QString> subFoldNames;
//            for(int i=0; i < subFolds.size(); i++){
//                if(auto locked = subFolds[i].lock()){
//                    subFoldNames.append(locked->getFileInfo().absoluteFilePath());
//                }
//            }
//            QVector<QString> deletedFolders; // wird nachher gebraucht um die m_slctdFolds zu aktualisieren
//            QVector<QString> deletedFiles;   // wird nachher gebraucht um die m_slctdFiles zu aktualisieren

//            int id = 0;
//            int refFolderId = -1;
//            while( id < m_oneDimnFolderOrder.size() ){
//                if(m_oneDimnFolderOrder[id].m_isFolder){
//                    if(auto vglLock = m_oneDimnFolderOrder[id].m_fileInfoBD.lock()){
//                        if(vglLock == refLock){
//                            refFolderId = id;
//                            break;
//                        }
//                    }else{
//                        m_oneDimnFolderOrder.removeAt( id );
//                    }
//                }
//            }
//            int firstSubFileId = -1;
//            if(refFolderId > -1){
//                int subFoldId = refFolderId+1;
//                while( subFoldId < m_oneDimnFolderOrder.size() ){
//                    if( m_oneDimnFolderOrder[subFoldId].m_isFolder &&
//                        m_oneDimnFolderOrder[subFoldId].m_fileInfoBD
//                }
//            }else{
//                // hier ist offensichtlich etwas schief gelaufen... alles neu ermitteln:
//                revalidateOneDimnFolderOrder();
//            }

////            int id = 0;
//            while(id < m_oneDimnFolderOrder.size()){
//                if(auto vglLock = m_oneDimnFolderOrder[id].m_fileInfoBD.lock()){
//                    if(m_oneDimnFolderOrder[id].m_isFolder){
//                        QString absFilePath = m_oneDimnFolderOrder[id].getAbsoluteFilePath();
//                        if( !subFoldNames.contains(absFilePath) ){
//                            // folder wurde geloescht!, daher mussen nun der inhalt des folders geloescht werden!
////                            QString delFoldPath = m_oneDimnFolderOrder[id].getAbsoluteFilePath();
//                            deletedFolders.append(absFilePath);
//                            // alle folder bis (ausschl.) id loeschen:
////                            for(int i=0; i < id;){
////                                QString fileOrFoldPth = m_oneDimnFolderOrder[i].getAbsoluteFilePath();
////                                if( fileOrFoldPth.isEmpty() || fileOrFoldPth.startsWith(absFilePath)){
////                                        m_oneDimnFolderOrder.removeAt(i);
////                                        --id;
////                                }else{
////                                    ++i;
////                                }
////                            }
//                            // id loeschen:
//                            m_oneDimnFolderOrder.removeAt(id);
//                            // alles ab id loeschen:
//                            i=id;
//                            while(i < m_oneDimnFolderOrder.size()){
//                                QString fileOrFoldPth = m_oneDimnFolderOrder[i].getAbsoluteFilePath();
//                                if( fileOrFoldPth.isEmpty() || fileOrFoldPth.startsWith(absFilePath)){
//                                    m_oneDimnFolderOrder.removeAt(i);
////                                    --id;
//                                }else{
//                                    ++i;
//                                }
//                            }
//                        }else{
//                            ++id;
//                        }
//                    }else{
//                        if(refLock == vglLock){
//                            int indexOf = fileNames.indexOf( m_oneDimnFolderOrder[id].m_fileName );
//                            if( indexOf == -1 ){
//                                // file wurde geloescht:
//                                deletedFiles.append(m_oneDimnFolderOrder[id].getAbsoluteFilePath());
//                                m_oneDimnFolderOrder.removeAt(id);
//                            }else{
//                                fileNames.removeAt( indexOf );
//                                ++id;
//                            }
//                        }else{
//                            ++id;
//                        }
//                    }
//                }else{
//                   m_oneDimnFolderOrder.removeAt(id);
//                }
//            }
//            i=0;
////            while(i < m_slctdFolds.size()){
////                if(m_slctdFolds[i].m_fileInfoBD.expired()){
////                    m_slctdFolds.removeAt(i);
////                }else{
////                    bool deletedFolderDetected = false;
////                    for(int j=0; j < deletedFolders.size(); j++){
////                        if(m_slctdFolds[i].getAbsoluteFilePath().startsWith(deletedFolders[j])){
////                            m_slctdFolds.removeAt(i);
////                            deletedFolderDetected = true;
////                            break;
////                        }
////                    }
////                    if( !deletedFolderDetected ){
////                        ++i;
////                    }
////                }
////            }
////            i=0;
////            while(i < m_slctdFiles.size()){
////                if(m_slctdFiles[i].m_fileInfoBD.expired()){
////                    m_slctdFiles.removeAt(i);
////                }else{
////                    bool deletedFileDetected = false;
////                    for(int j=0; j < deletedFiles.size(); j++){
////                        if(m_slctdFiles[i].getAbsoluteFilePath().startsWith(deletedFiles[j])){
////                            m_slctdFiles.removeAt(i);
////                            deletedFileDetected = true;
////                            break;
////                        }
////                    }
////                    if( !deletedFileDetected ){
////                        ++i;
////                    }
////                }
////            }
//        }else{
//            // fallnetz: die integritaet der kopie-listen kann nicht mehr garantiert werden:
//            revalidateOneDimnFolderOrder();
//        }
//    }else{
//        // fallnetz: die integritaet der kopie-listen kann nicht mehr garantiert werden:
//        revalidateOneDimnFolderOrder();
//    }

    revalidateOneDimnFolderOrder();

    repaintFolderViewer();
}

void FilesCoordinator::folderElapsed(std::weak_ptr<FileInfoBD> f)
{
    revalidateOneDimnFolderOrder();
}

void FilesCoordinator::sortingChanged(std::weak_ptr<FileInfoBD> f)
{
    if(auto refLock = f.lock()){

        int oneDimId = -1;
        int oneDispDimId = -1;

        for(int i=0; i < m_oneDimnFolderOrderDisplayed.size(); i++){
            if( !m_oneDimnFolderOrderDisplayed[i].m_isFolder ){
                if (auto vglLock = m_oneDimnFolderOrderDisplayed[i].m_fileInfoBD.lock()){
                    if(refLock == vglLock){
                        // first file of folder detected:
                        oneDispDimId = i;
                        break;
                    }
                }
            }
        }
        for(int i=0; i < m_oneDimnFolderOrder.size(); i++){
            if( !m_oneDimnFolderOrder[i].m_isFolder ){
                if (auto vglLock = m_oneDimnFolderOrder[i].m_fileInfoBD.lock()){
                    if(refLock == vglLock){
                        // first file of folder detected:
                        oneDimId = i;
                        break;
                    }
                }
            }
        }
        if(oneDimId > -1 || oneDispDimId > -1){
            int offs = 0;
            foreach(const auto& fi, refLock->getFiles()){
                if(oneDimId > -1 && oneDimId+offs < m_oneDimnFolderOrder.size()){
                    m_oneDimnFolderOrder[oneDimId+offs] = FilInfoForOneDim(f, false, fi.fileName(),
                                                                           m_oneDimnFolderOrder[oneDimId+offs].m_depth);
                }
                if(oneDispDimId > -1 && oneDispDimId+offs < m_oneDimnFolderOrderDisplayed.size()){
                    m_oneDimnFolderOrderDisplayed[oneDispDimId+offs] = FilInfoForOneDim(f, false, fi.fileName(),
                                                                            m_oneDimnFolderOrderDisplayed[oneDispDimId+offs].m_depth);
                }
                ++offs;
            }
        }
    }
    revalidateSearchIds();
}

void FilesCoordinator::addDirectoryToWatcher(QString directory)
{
    if(m_watcher){
        m_watcher->addPath(directory);
    }
}

void FilesCoordinator::directoryChanged(QString path)
{
    for(int i=0; i < m_oneDimnFolderOrder.size(); i++){
        QString refPath = m_oneDimnFolderOrder[i].getAbsoluteFilePath();
        if( m_oneDimnFolderOrder[i].m_isFolder &&
                !refPath.isEmpty() && refPath == path){
            if(auto locked = m_oneDimnFolderOrder[i].m_fileInfoBD.lock()){
                locked->directoryChanged(path);
            }
            return;
        }
    }
}

void FilesCoordinator::copySelectedContent()
{
    copyCutToClipboardHelper(false);
}

void FilesCoordinator::cutSelectedContent()
{
    copyCutToClipboardHelper(true);
}

void FilesCoordinator::copyCutToClipboardHelper(bool deleteSourceAfterCopying)
{
    QClipboard *clipboard = QApplication::clipboard();
    QList<QUrl> urls;

    if(deleteSourceAfterCopying){
        urls.append(QUrl("cut"));
    }

    foreach (const auto& fold, m_slctdFolds) {
        QString foldPath = fold.getAbsoluteFilePath();
        if( !foldPath.isEmpty() && QFileInfo(foldPath).exists() ){
            urls.append( QUrl::fromLocalFile(foldPath) );
        }
    }
    foreach (const auto& file, m_slctdFiles) {
        QString filePath = file.getAbsoluteFilePath();
        if( !filePath.isEmpty() && QFileInfo(filePath).exists() ){
            urls.append( QUrl::fromLocalFile(filePath) );
        }
    }
    if( urls.size() > 0 ){
        QMimeData *mimeData = new QMimeData;
        mimeData->setUrls(urls);
        clipboard->setMimeData(mimeData);
    }
}

void FilesCoordinator::duplicateSelectedContent()
{
    auto caller = [=](){
        foreach(const FilInfoForOneDim& fi, m_slctdFiles){
            if( !fi.m_fileInfoBD.expired() ){
//                auto caller = [=](){
                    StaticFunctions::duplicateFile( QFileInfo(fi.getAbsoluteFilePath()) );
//                };

            }
        }
        foreach(const FilInfoForOneDim& fi, m_slctdFolds){
            if(auto locked = fi.m_fileInfoBD.lock()){
//                auto caller = [=](){
                    StaticFunctions::duplicateFolder(locked->getFileInfo());
//                };
//                new ElapseWorkerFunctional(caller, QString("copying folder..."));
            }
        }
    };
//    new ElapseWorkerFunctional(caller, QString("copying files..."));
    launchElapseWorkerFunctional(caller, QString("copying files..."));
}

void FilesCoordinator::pasteFromClipboard()
{
    const QClipboard *clipboard = QApplication::clipboard();
    const QMimeData *mimeData = clipboard->mimeData();

    if      (mimeData->hasUrls()) {
        pasteHelper( mimeData->urls() );
    }else if(mimeData->hasText()) {
        QString paths = mimeData->text();
        pasteHelper( paths );
    }
}

void FilesCoordinator::paste(QString paths, QString tarPath)
{
    pasteHelper(paths, tarPath);
}
void FilesCoordinator::pasteHelper(QString paths, QString tarPath){
    QTextStream stream(&paths);
    QString line;
    QVector<QString> pathsFromClpbrd;
    while (stream.readLineInto(&line)) {
        pathsFromClpbrd.append(line);
    }
    if(pathsFromClpbrd.size() > 0){
        pasteHelper(pathsFromClpbrd, tarPath);
    }
}

void FilesCoordinator::pasteHelper(QList<QUrl> urls, QString tarPath)
{
    QVector<QString> pathsFromClpbrd;
    foreach (const auto& url, urls) {
        QString pth = url.toLocalFile();
        if( !pth.isEmpty() ){
            pathsFromClpbrd.append( url.toLocalFile() );
        }else if (url.toString() == QString("cut")){
            pathsFromClpbrd.append( QString("cut") );
        }
    }
    if(pathsFromClpbrd.size() > 0){
        pasteHelper(pathsFromClpbrd, tarPath);
    }
}
void FilesCoordinator::pasteHelper(QVector<QString> pathsFromClpbrd, const QString tarPath_)
{
    auto caller = [=](){
        QString tarPath = tarPath_;
        bool deleteSourceDataAfterCopying = false;
        if(pathsFromClpbrd.size() > 0){
            if(pathsFromClpbrd[0] == QString("cut"))
                deleteSourceDataAfterCopying = true;

            if(!tarPath.isEmpty()){
                QFileInfo fi(tarPath);
                if(fi.exists()){
                    if(fi.isFile()){
                        tarPath = fi.absolutePath();
                    }else{
                        tarPath = fi.absoluteFilePath();
                    }
                }
            }
            if( (tarPath.isEmpty() || !QFileInfo(tarPath).exists())
                    && singleFolderSelected()){
                tarPath = m_slctdFolds[0].getAbsoluteFilePath();
            }
            if( tarPath.isEmpty() || !QFileInfo(tarPath).exists()){
                if(m_root){
                    tarPath = m_root->getFileInfo().absoluteFilePath();
                }
            }
            if( !tarPath.isEmpty() && QFileInfo(tarPath).exists()){
                foreach (const auto& sourcePath, pathsFromClpbrd) {
                    qDebug() << "   sourcePath: " << sourcePath
                             << "   exists: " << QFileInfo(sourcePath).exists();
                    QFileInfo fi(sourcePath);
                    if(fi.exists()){
                        QString targetName = fi.fileName();
                        if( !targetName.isEmpty()){
                            if(fi.isDir()){
                                StaticFunctions::copyFolder(sourcePath,
                                                            tarPath,
                                                            targetName);
                                if(deleteSourceDataAfterCopying){
                                    StaticFunctions::deleteFolder(sourcePath);
                                }
                            }else if(fi.isFile()){
                                StaticFunctions::copyFile(sourcePath,
                                                          tarPath,
                                                          targetName);
                                if(deleteSourceDataAfterCopying){
                                    StaticFunctions::deleteFile(sourcePath);
                                }
                            }
                        }
                    }
                }
            }
        }
    };
//    ElapseWorkerFunctional worker = new ElapseWorkerFunctional(caller, QString("copying files..."), false);
//    if( !m_infoMessageStr.isEmpty() ){
//        QProgressDialog* progress = new QProgressDialog(m_infoMessageStr, QString(""), 0, 100);
//        progress->setWindowModality(Qt::WindowModal);
//        progress->show();

//        StaticFunctions::setIconToWidget(progress);

//        QTimer* timer = new QTimer(this);
//        QObject::connect(timer, &QTimer::timeout, progress, [=](){
//            int val = progress->value();
//            if(++val > progress->maximum()-1)
//                val = 0;
//            progress->setValue(val);
//        });
//        timer->start(50);
//        connect(this, &ElapseWorkerFunctional::finished,   timer, &QTimer::stop);
//        connect(this, &ElapseWorkerFunctional::finished,   progress, &QProgressDialog::deleteLater);
//    }
//    worker.start();
    launchElapseWorkerFunctional(caller, QString("copying files..."));
}

ElapseWorkerFunctional* FilesCoordinator::launchElapseWorkerFunctional(std::function<void()> caller,
                                                                       QString infoMessageStr,
                                                                       bool launchThread){
    ElapseWorkerFunctional* worker = new ElapseWorkerFunctional(caller, infoMessageStr, false);
    worker->prepare();

    if( !infoMessageStr.isEmpty() ){
        QProgressDialog* progress = new QProgressDialog(infoMessageStr, QString("cancel"), 0, 100);
        progress->setWindowModality(Qt::WindowModal);
//        progress->setWindowFlag( Qt::FramelessWindowHint );
        progress->show();

        StaticFunctions::setIconToWidget(progress);

        QTimer* timer = new QTimer(this);
        QObject::connect(timer, &QTimer::timeout, progress, [=](){
            int val = progress->value();
            if(++val > progress->maximum()-1)
                val = 0;
            progress->setValue(val);
        });

        // folgender kill-connect bringt nichts, frage, wieso....
        QObject::connect(progress, &QProgressDialog::canceled,
                         worker, &ElapseWorkerFunctional::kill, Qt::QueuedConnection);
        QObject::connect(progress, &QProgressDialog::canceled,
                         timer, &QTimer::stop, Qt::QueuedConnection);

        connect(worker, &ElapseWorkerFunctional::finished,   timer, &QTimer::stop);
        connect(worker, &ElapseWorkerFunctional::finished,   progress, &QProgressDialog::deleteLater);

        timer->start(50);
    }
    if(launchThread)
        worker->start();
    return worker;
}

void FilesCoordinator::deleteSelectedContent()
{
    if(contentSelected()){
        QMessageBox msgBox;
        msgBox.setText("Are you sure you want to delete the selected content?");
        msgBox.setInformativeText(QString("%1 files and %2 folders selected for deletion")
                                  .arg(m_slctdFiles.size())
                                  .arg(m_slctdFolds.size()));
        msgBox.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
        msgBox.setDefaultButton(QMessageBox::Ok);

        int ret = msgBox.exec();

        if(ret == QMessageBox::Ok){
            QVector<QFileInfo> filesToDelete;
            foreach(const FilInfoForOneDim& fi, m_slctdFiles){
                if( !fi.m_fileInfoBD.expired() ){
//                    qDebug() << "about to delete: " << fi.getAbsoluteFilePath();
                    filesToDelete.append( QFileInfo(fi.getAbsoluteFilePath()) );
                }
            }
            QVector<QFileInfo> foldersToDelete;
            foreach(const FilInfoForOneDim& fi, m_slctdFolds){
                if(auto locked = fi.m_fileInfoBD.lock()){
                    foldersToDelete.append( locked->getFileInfo() );
                }
            }

            auto caller = [=](){
                m_blockRevalidating = true;
                foreach(const QFileInfo file, filesToDelete){
                    StaticFunctions::deleteFile(file);
                }
                foreach(auto folder, foldersToDelete) {
                    StaticFunctions::deleteFolder(folder);
                }
            };
            m_blockRevalidating = true;
            ElapseWorkerFunctional* worker = launchElapseWorkerFunctional(caller, QString("deleting files..."), false);

            connect(worker, &ElapseWorkerFunctional::finished, [=](){
                m_blockRevalidating = false;
                revalidateOneDimnFolderOrder();
                repaintFolderViewer();
            });
            worker->start();
        }
    }
}

void FilesCoordinator::openSelectedContent()
{
    QTimer::singleShot(0, nullptr, [=](){
        foreach(const FilInfoForOneDim& fi, m_slctdFiles){
            if( !fi.m_fileInfoBD.expired()){
                QDesktopServices::openUrl(QUrl(QString("file:%1").arg(fi.getAbsoluteFilePath())));
            }
        }
        foreach(const FilInfoForOneDim& fi, m_slctdFolds){
            if(auto locked = fi.m_fileInfoBD.lock()){
                QDesktopServices::openUrl(QUrl(QString("file:%1").arg(locked->getFileInfo().absoluteFilePath())));
            }
        }
    });
}

void FilesCoordinator::showDetailsOfSelectedContent()
{
}

void FilesCoordinator::renameSelectedContent()
{
    if(m_slctdFiles.size() == 1){
        if( !m_slctdFiles[0].m_fileInfoBD.expired() ){
            StaticFunctions::renameFolder(QFileInfo(m_slctdFiles[0].getAbsoluteFilePath()));
        }
    }else if (m_slctdFolds.size() == 1){
        if(auto locked = m_slctdFolds[0].m_fileInfoBD.lock()){
            StaticFunctions::renameFolder(locked->getFileInfo());
        }
    }
}

void FilesCoordinator::createNewFolder()
{
    addNewFileFolderHelper(false);
}

void FilesCoordinator::createNewFile()
{
    addNewFileFolderHelper(true);
}

void FilesCoordinator::addNewFileFolderHelper(bool createFile)
{
    bool ok;
    QString fileOrFoldName = QInputDialog::getText(nullptr, QString(""),
                                         QString("Choose a name for the new %1:")
                                                   .arg(createFile ?
                                                            tr("file") :
                                                            tr("folder")),
                                                   QLineEdit::Normal,
                                         createFile ?
                                         QString("new_File.txt") :
                                         QString("new_Folder"), &ok);
    if (ok && !fileOrFoldName.isEmpty()){
        QString path;
        if(m_slctdFolds.size() == 1){
            path = m_slctdFolds[0].getAbsoluteFilePath();
            QFileInfo fi(path);
            if( !path.isEmpty() && fi.exists()){
                path = fi.absoluteFilePath();
            }
        }else if (m_slctdFiles.size() == 1){
            path = m_slctdFiles[0].getAbsoluteFilePath();
            QFileInfo fi(path);
            if( !path.isEmpty() && fi.exists()){
                path = fi.absolutePath();
            }
        }else{
            if(m_root){
                path = m_root->getFileInfo().absoluteFilePath();
            }
        }
        if(!path.isEmpty()){
            if(createFile){
                StaticFunctions::createNewFile  (path, fileOrFoldName);
            }else{
                StaticFunctions::createNewFolder(path, fileOrFoldName);
            }
        }
    }
}

void FilesCoordinator::initDragging(QString initiator)
{
    QList<QUrl> urls;
    for(int i=0; i < m_slctdFiles.size(); i++){
        QString path = m_slctdFiles[i].getAbsoluteFilePath();
        if( !path.isEmpty() && QFileInfo(path).exists() ){
            urls.append( QUrl::fromLocalFile(path) );
        }
    }
    for(int i=0; i < m_slctdFolds.size(); i++){
        QString path = m_slctdFolds[i].getAbsoluteFilePath();
        if( !path.isEmpty() && QFileInfo(path).exists() ){
            urls.append( QUrl::fromLocalFile(path) );
        }
    }

    if( !initiator.isEmpty() && QFileInfo(initiator).exists()){
        QUrl initatorUrl = QUrl::fromLocalFile(initiator);
        if( !urls.contains(initatorUrl) ){
            urls.append( initatorUrl );
        }
    }

    if(urls.size() > 0){
        QDrag *drag = new QDrag(this);
        QMimeData *mimeData = new QMimeData;

        mimeData->setUrls( urls );
        drag->setMimeData(mimeData);
//        drag->setPixmap(iconPixmap);

        Qt::DropAction dropAction = drag->exec();
        Q_UNUSED( dropAction )
    }
}

QVector<FilInfoForOneDim> FilesCoordinator::selectedFolders() const
{
    QVector<FilInfoForOneDim> retVct;
    for(int i=0; i < m_slctdFolds.size(); i++){
        retVct.append(m_slctdFolds[i]);
    }
    return retVct;
}

QVector<FilInfoForOneDim> FilesCoordinator::selectedFiles() const
{
    QVector<FilInfoForOneDim> retVct;
    for(int i=0; i < m_slctdFiles.size(); i++){
        retVct.append(m_slctdFiles[i]);
    }
    return retVct;
}

QVector<FilInfoForOneDim> FilesCoordinator::selectedContent() const
{
    QVector<FilInfoForOneDim> retVct;
    for(int i=0; i < m_slctdFiles.size(); i++){
        retVct.append(m_slctdFiles[i]);
    }
    for(int i=0; i < m_slctdFolds.size(); i++){
        retVct.append(m_slctdFolds[i]);
    }
    return retVct;
}

bool FilesCoordinator::isSelected(FilInfoForOneDim fold)
{
    return m_slctdFolds.contains(fold) || m_slctdFiles.contains(fold);
}

int FilesCoordinator::getIdOf(FilInfoForOneDim fileInfOneDim, bool searchInDisplayedContent) const
{
    const QList<FilInfoForOneDim>* vec;
    if(searchInDisplayedContent){
        vec = &m_oneDimnFolderOrderDisplayed;
    }else{
        vec = &m_oneDimnFolderOrder;
    }
    if(auto refLock = fileInfOneDim.m_fileInfoBD.lock()){
        for(int i=0; i < vec->size(); i++){
            if(vec->at(i).m_isFolder == fileInfOneDim.m_isFolder){
                if(auto curLock = vec->at(i).m_fileInfoBD.lock()){
                    if(curLock == refLock &&
                                   vec->at(i).m_fileName == fileInfOneDim.m_fileName){
                        return i;
                    }
                }
            }
        }
    }
    return -1;
}
int FilesCoordinator::getIdOf(std::shared_ptr<FilInfoForOneDim> fileInfOneDim, bool searchInDisplayedContent) const
{
    if(fileInfOneDim){
        const QList<FilInfoForOneDim>* vec;
        if(searchInDisplayedContent){
            vec = &m_oneDimnFolderOrderDisplayed;
        }else{
            vec = &m_oneDimnFolderOrder;
        }
        if(auto refLock = fileInfOneDim->m_fileInfoBD.lock()){
            for(int i=0; i < vec->size(); i++){
                if(vec->at(i).m_isFolder == fileInfOneDim->m_isFolder){
                    if(auto curLock = vec->at(i).m_fileInfoBD.lock()){
                        if(curLock == refLock &&
                                       vec->at(i).m_fileName == fileInfOneDim->m_fileName){
                            return i;
                        }
                    }
                }
            }
        }
    }
    return -1;
}

void FilesCoordinator::selectContent(FilInfoForOneDim cont,
                                     bool controlPrsd, bool shiftPrs)
{
    if(!controlPrsd && !shiftPrs){
        m_slctdFolds.clear();
        m_slctdFiles.clear();
    }
    if(shiftPrs){
        int lastSelectiondId = getIdOf(m_lastSelection);
        int curId = getIdOf(cont);
        int offs = abs(lastSelectiondId-curId);
        qDebug() << "lastSelectiondId: " << lastSelectiondId << "   curId: " << curId;
        if(lastSelectiondId > curId){
            iterateBackwards(m_lastSelection, offs, getSelectionFunction());
        }else{
            iterateForwards (m_lastSelection, offs, getSelectionFunction());
        }
        m_lastSelection = cont;
        repaintFolderViewer();
    }else{
        m_lastSelection = cont;
        if(cont.m_isFolder){
            if(m_slctdFolds.contains(cont)){
                deselectContent(cont);
                return;
            }else{
    //            lastSelection = cont;
                m_slctdFolds.append(cont);
                repaintFolderViewer();
            }
        }else{
            if(m_slctdFiles.contains(cont)){
                deselectContent(cont);
                return;
            }else{
    //            lastSelection = cont;
                m_slctdFiles.append(cont);
                repaintFolderViewer();
            }
        }
    }
//    qDebug() << "\nin filesCoordintator.selectContent<FileInfoBD>: file: " << cont.m_fileInfoBD.lock()->fileName()
//             << "   controlPrsd: " << controlPrsd << "  shiftPrsd: " << shiftPrs;
//    qDebug() << "cont.isFolder: " << cont.m_isFolder;
//    printSelectedFolders();
//    printSelectedFiles();
//    qDebug() << "\n";
}


void FilesCoordinator::selectEntireContent()
{
    m_slctdFolds.clear();
    m_slctdFiles.clear();

    auto func =
            [=](std::weak_ptr<FileInfoBD> fiBD, int depth){
        m_slctdFolds.append(FilInfoForOneDim(fiBD, true, QString(""), depth));
    };
    auto fileFunc =
            [=](std::weak_ptr<FileInfoBD> fiBD, int depth){
        if(std::shared_ptr<FileInfoBD> fiBDLock = fiBD.lock()){
            foreach(const QFileInfo& fi, fiBDLock->getFiles()){
                m_slctdFiles.append(FilInfoForOneDim(fiBD, false, fi.fileName(), depth));
            }
        }
    };
    m_root->traverse(func, fileFunc, true, 0);

    if(m_slctdFolds.size() > 0){
        m_lastSelection = m_slctdFolds[0];
    }else if(m_slctdFiles.size() > 0){
        m_lastSelection = m_slctdFiles[0];
    }

    repaintFolderViewer();
}

void FilesCoordinator::deselectContent(FilInfoForOneDim cont)
{

    if(cont.m_isFolder){
        if(m_slctdFolds.contains(cont)){
            for(int i=0; i < m_slctdFolds.size(); i++){
                if(m_slctdFolds[i] == cont){
                    m_slctdFolds.removeAt(i);
                    break;
                }
            }
//            m_slctdFolds.removeAt(id);
            repaintFolderViewer();
        }
    }else{
        if(m_slctdFiles.contains(cont)){
            for(int i=0; i < m_slctdFiles.size(); i++){
                if(m_slctdFiles[i] == cont){
                    m_slctdFiles.removeAt(i);
                    break;
                }
            }
//            m_slctdFiles.removeAt(id);
            repaintFolderViewer();
        }
    }

//    qDebug() << "in deselectContent<FileInfBD>: file: " << fold.lock()->fileName();
//    printSelectedFolders();
//    printSelectedFiles();
//    qDebug() << "\n";
}

void FilesCoordinator::clearContent()
{
    m_slctdFiles.clear();
    m_slctdFolds.clear();
    repaintFolderViewer();
}

std::function<void(FilInfoForOneDim)> FilesCoordinator::getSelectionFunction(){
    return [=](FilInfoForOneDim fiForOneDim){
        if(fiForOneDim.m_isFolder){
            if( !m_slctdFolds.contains(fiForOneDim) ){
                this->m_slctdFolds.append(fiForOneDim);
            }
        }else{
            if( !m_slctdFiles.contains(fiForOneDim) ){
                this->m_slctdFiles.append(fiForOneDim);
            }
        }
        m_lastSelection = fiForOneDim;
    };
}
void FilesCoordinator::selectButtonUp(bool ctrl_prsd, bool shft_prsd)
{
    if( !(shft_prsd || ctrl_prsd) ){
        m_slctdFolds.clear();
        m_slctdFiles.clear();
    }
    std::function<void(FilInfoForOneDim)> func = getSelectionFunction();
    auto newSelected = iterateBackwards(m_lastSelection, 1, func);

    if(newSelected){
        int id = getIdOf(newSelected);
        if (id > -1){
            focusFolderViewer(id);
        }else{
            repaintFolderViewer();
        }
    }else{
        repaintFolderViewer();
    }
}


void FilesCoordinator::selectButtonDown(bool ctrl_prsd, bool shft_prsd)
{
    if( !(shft_prsd || ctrl_prsd) ){
        m_slctdFolds.clear();
        m_slctdFiles.clear();
    }
    std::function<void(FilInfoForOneDim)> func = getSelectionFunction();
    auto newSelected = iterateForwards(m_lastSelection, 1, func);

    if(newSelected){
        int id = getIdOf(newSelected);
        if (id > -1){
            focusFolderViewer(id);
        }else{
            repaintFolderViewer();
        }
    }else{
        repaintFolderViewer();
    }
//    repaintFolderViewer();
}

bool FilesCoordinator::filesSelected()
{
    return m_slctdFiles.size() != 0;
}

bool FilesCoordinator::foldersSelected()
{
    return m_slctdFolds.size() != 0;
}

bool FilesCoordinator::contentSelected()
{
    return filesSelected() || foldersSelected();
}

bool FilesCoordinator::singleFolderSelected()
{
    return m_slctdFolds.size() == 1;
}

bool FilesCoordinator::singleFileSelected()
{
    return m_slctdFiles.size() == 1;
}

bool FilesCoordinator::singleContentSelected()
{
    return (m_slctdFolds.size() + m_slctdFiles.size()) == 1;
}

int FilesCoordinator::selectionCounter()
{
    return m_slctdFolds.size() + m_slctdFiles.size();
}

void FilesCoordinator::revalidateSearchIds(){
    m_searchIds.clear();

    for(int i=0; i < m_searchResults.size(); i++){
        int id = m_oneDimnFolderOrderDisplayed.indexOf( m_searchResults[i] );
        if( id > -1 ){
            m_searchIds.append( id );
        }else{
            if(auto lockedRef = m_searchResults[i].m_fileInfoBD.lock()){
                std::weak_ptr<FileInfoBD> dispParentFold = lockedRef->getFirstDispParent();
                if(auto lockedParentFold = dispParentFold.lock()){
                    for(int j=0; j < m_oneDimnFolderOrderDisplayed.size(); j++){
                        if(m_oneDimnFolderOrderDisplayed[j].m_isFolder){
                            if(auto lockedVgl = m_oneDimnFolderOrderDisplayed[j].m_fileInfoBD.lock()){
                                if(lockedVgl == lockedParentFold){
                                    m_searchIds.append( j );
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

void FilesCoordinator::searchForKeyWord(QString keyword)
{
    clearSearchResults();

    keyword = keyword.toLower();

    for(int i=0; i < m_oneDimnFolderOrder.size();i++){
        QString fileOrFoldername = m_oneDimnFolderOrder[i].getFileName();
        if( !fileOrFoldername.isEmpty() && fileOrFoldername.toLower().contains(keyword) ){
            m_searchResults.append(m_oneDimnFolderOrder[i]);
        }
    }

    revalidateSearchIds();

    if(m_searchResults.size() > 0){
        m_searchIndex = 0;
//        QSingleShot;
    }else{
        m_searchIndex = -1;
        QTimer::singleShot(0, [=](){
            QMessageBox msgBox;
            msgBox.setText(QString("Sorry, but couldn't find any matches for '%1'").arg(keyword));
            msgBox.exec();
        });
    }
}

void FilesCoordinator::searchForBeginsWith(QString startWith)
{
    Q_UNUSED(startWith)
}

bool FilesCoordinator::searchResultsEmpty()
{
    return m_searchResults.size() == 0;
}

int FilesCoordinator::searchResultsFound()
{
    return m_searchResults.size();
}

int FilesCoordinator::getSearchIndex()
{
    return m_searchIndex;
}

void FilesCoordinator::nextSearchResult()
{
    if(m_searchResults.size() > 0){
        ++m_searchIndex;
        if(m_searchIndex >= m_searchResults.size()){
            m_searchIndex = 0;
        }
        if(m_searchIndex < m_searchIds.size()){
            int id = m_searchIds[m_searchIndex];
            if(id > -1)
                focusFolderViewer(id, true);
        }
    }
}

void FilesCoordinator::previousSearchResult()
{
    if(m_searchResults.size() > 0){
        --m_searchIndex;
        if(m_searchIndex < 0){
            m_searchIndex = m_searchResults.size()-1;
        }
        if(m_searchIndex < m_searchIds.size()){
            int id = m_searchIds[m_searchIndex];
            if(id > -1)
                focusFolderViewer(id, true);
        }
//        int id = getIdOf(m_searchResults[m_searchIndex]);
//        if(id > -1){
//            focusFolderViewer(id, true);
//        }else{
//            id = getIdOf(m_searchResults[m_searchIndex], false);
//            if(id > -1 && id < m_oneDimnFolderOrder.size()){
//                int dispId = getIdOfFirstDispParent(m_oneDimnFolderOrder[id]);
//                if(dispId > -1){
//                    focusFolderViewer(dispId, true);
//                }
//            }
//        }
    }
}

int FilesCoordinator::getIndexOfCurrentSearchResult()
{
    if(m_searchIds.size() > 0 && m_searchIndex > -1 &&
            m_searchIds.size() > m_searchIndex){
        return m_searchIds[m_searchIndex];
    }
//    if(m_searchResults.size() > 0 && m_searchIndex > -1){
//        auto curRslt = m_searchResults[m_searchIndex];
//        for(int i=0; i < m_oneDimnFolderOrder.size(); i++){
//            if (m_oneDimnFolderOrder[i] == curRslt){
//                return i;
//            }
//        }
//    }
    return -1;
}

QString FilesCoordinator::getCurSearchResultStr()
{
    if(m_searchResults.size() > 0 && m_searchIndex > -1){
        return m_searchResults[m_searchIndex].getFileName();
    }
    return QString("");
}

FilInfoForOneDim FilesCoordinator::getCurSearchResult()
{
    if(m_searchResults.size() > 0 && m_searchIndex > -1){
        return m_searchResults[m_searchIndex];
    }
    return FilInfoForOneDim();
}

bool FilesCoordinator::isCurentSearchResult(FilInfoForOneDim fiForOneDim)
{
    if(m_searchResults.size() > 0 &&
            m_searchIndex > -1 &&
            m_searchIds.size() > m_searchIndex &&
            m_oneDimnFolderOrderDisplayed.size() > m_searchIds[m_searchIndex]){

        return m_oneDimnFolderOrderDisplayed[m_searchIds[m_searchIndex]] == fiForOneDim;

//        if(auto locked = m_searchResults[m_searchIndex].m_fileInfoBD.lock()){
//            if(locked->isBeingDisplayed()){
//                qDebug() << "in falscher";
//                return m_searchResults[m_searchIndex] == fiForOneDim;
//            }else{
//                qDebug() << "in else";
//                int dispId = getIdOfFirstDispParent(fiForOneDim);
//                return dispId > -1;
//            }
//        }
    }
    return false;
}

void FilesCoordinator::clearSearchResults()
{
    m_searchResults.clear();
    m_searchIds.clear();
    m_searchIndex = -1;
}

int FilesCoordinator::getIdOfFirstDispParent(FilInfoForOneDim oneDimFi)
{
    if(auto locked = oneDimFi.m_fileInfoBD.lock()){
        std::weak_ptr<FileInfoBD> firstDispParent = locked->getFirstDispParent();
        if(auto lockedRef = firstDispParent.lock()){
            for(int i=0; i < m_oneDimnFolderOrderDisplayed.size(); i++){
                if(auto lockedTar = m_oneDimnFolderOrderDisplayed[i].m_fileInfoBD.lock()){
                    if(lockedTar == lockedRef && m_oneDimnFolderOrderDisplayed[i].m_isFolder == true ){
                        return i;
                    }
                }
            }
        }
    }
    return -1;
}

int FilesCoordinator::getMaxDepth()
{
    return m_maxDepth;
}

void FilesCoordinator::elapseAllFoldersOfDepthId(int depthId)
{
    m_depthIdsElapsed[depthId] = !m_depthIdsElapsed[depthId];
    QVector<FilInfoForOneDim> foldersToElapse;
    for(int i=0; i < m_oneDimnFolderOrder.size(); i++){
        if(m_oneDimnFolderOrder[i].m_isFolder &&
                depthId == m_oneDimnFolderOrder[i].m_depth){
            foldersToElapse.append(m_oneDimnFolderOrder[i]);
        }
    }
    if(foldersToElapse.size() > 0 ){
        QTimer::singleShot(0, [=](){
            m_blockRevalidating = true;
            for(int i=0; i < foldersToElapse.size(); i++){
                if(auto locked = foldersToElapse[i].m_fileInfoBD.lock()){
                    locked->setElapsed(m_depthIdsElapsed[depthId]);
                }
            }
            m_blockRevalidating = false;
            revalidateOneDimnFolderOrder();
            QTimer::singleShot(0, [=](){repaintFolderViewer(); });
        });
    }
}

bool FilesCoordinator::depthIdElapsed(int depthId)
{
    if(depthId < m_depthIdsElapsed.size()){
        return m_depthIdsElapsed[depthId];
    }
    return false;
}

void FilesCoordinator::setSelf(std::shared_ptr<FilesCoordinator> self)
{
    m_self = self;
}

void FilesCoordinator::resetQWidgets()
{
    m_folderViewer = new GraphicsView();
    m_mainGrid = new QGridLayout();
    m_toolBar = new QHBoxLayout();

    m_toolBar->setAlignment(Qt::AlignLeft);
    m_toolBar->setSizeConstraint(QLayout::SetNoConstraint);

    m_mainGrid->addLayout(m_toolBar, 0,0);
    m_mainGrid->addWidget(m_folderViewer, 1, 0);
    m_mainGrid->setContentsMargins(0, 4, 0, 4);
    m_mainGrid->setSpacing(0);

    setRootToGraphicsView();

    revalidateToolBar();

    QTimer::singleShot(0,[=](){
        m_folderViewer->setVBarValue(m_graphicsViewVBarValueBackup);
        m_folderViewer->setHBarValue(m_graphicsViewHBarValueBackup);
    });
}

void FilesCoordinator::saveGraphicsViewVBarValue()
{
    if(m_folderViewer){
        m_graphicsViewVBarValueBackup = m_folderViewer->getVScrollBarValue();
    }
}

void FilesCoordinator::saveGraphicsViewHBarValue()
{
    if(m_folderViewer){
        m_graphicsViewHBarValueBackup = m_folderViewer->getHScrollBarValue();
    }
}

void FilesCoordinator::forceRevalidation()
{
    revalidateOneDimnFolderOrder();
    repaintFolderViewer();
}

QString FilesCoordinator::getCurRootPath()
{
    if(m_root)
        return m_root->getFileInfo().absoluteFilePath();
    else
        return QString("");
}

void FilesCoordinator::printSelectedFolders()
{
    qDebug() << "   folders: size: " << m_slctdFolds.size();
    for(int i=0; i < m_slctdFolds.size(); i++){
        qDebug() << "       " << m_slctdFolds[i].m_fileName;
    }
}

void FilesCoordinator::printSelectedFiles()
{
    qDebug() << "   files: size: " << m_slctdFiles.size();
    for(int i=0; i < m_slctdFiles.size(); i++){
        qDebug() << "       " << m_slctdFiles[i].m_fileName;
    }
}


void FilesCoordinator::revalidateToolBar()
{
    StaticFunctions::removeChildrenFromLayout(m_toolBar);

    m_toolBar->setAlignment(Qt::AlignLeft);
    m_toolBar->setSpacing(5);
    m_toolBar->setContentsMargins(0, 0, 0, 4);

    QString return_icon_path = QString("pics").append(QDir::separator()).append("undo_icon.png");
    QPixmap pix_map(return_icon_path);
    QIcon icon(pix_map);// = StaticFunctions::getFileIcon(QFileInfo(return_icon_path));
    QPushButton* returnBtn = new QPushButton(icon, QString(""));
    returnBtn->setMaximumWidth(25);
    returnBtn->setMaximumHeight(15);

    connect(returnBtn, &QPushButton::clicked,
            [=](){
        setLastPathToRoot();
    });
    if(m_dirStack.size() == 1){
        returnBtn->setEnabled(false);
    }
    m_toolBar->addWidget(returnBtn);

    if(m_root){
        QStringList pthBtns = m_root->getFileInfo().absoluteFilePath().split(QDir::separator());
        pthBtns.prepend(QDir::separator());
        int btnsWidth = 0;
        QFont goshFont = StaticFunctions::getGoshFont();
        QFontMetrics fm(goshFont);

        for(int i=pthBtns.size()-1; i >= 0; i--){
            if(btnsWidth >= this->m_folderViewer->width()-30)
                break;

            QString dirName = pthBtns.at(i);
            if( !dirName.isEmpty() ){
                QPushButton* btn = new QPushButton(dirName);

                int curBtnWidth = fm.width(dirName);
                if(curBtnWidth < 15){
                    curBtnWidth = 15;
                }
                curBtnWidth+=10;
                // allerletzer button dar expanden, da sonst QHBoxLayout
                // sinnlos ist, wenn gar kein button expanden darf:
                if(i != pthBtns.size()-1){
                    btn->setMaximumWidth(curBtnWidth);
                    btn->setMinimumWidth(0);
                }else{
                    btn->setObjectName(QString("rootButton"));
                }
                btnsWidth += curBtnWidth;

                btn->setFont(goshFont);
                QString path("");
                for(int j=0; j <= i; ++j){
                    path.append(pthBtns.at(j));
                    if(j<i){
                        path.append(QDir::separator());
                    }
                }
                connect(btn, &QPushButton::clicked, [=](){setRootFolder(QDir(path));});
                m_toolBar->insertWidget(1,btn);
            }
        }
    }
}

void FilesCoordinator::repaintFolderViewer()
{
    if( !m_blockRevalidating ){
        QTimer::singleShot(0, m_folderViewer, &GraphicsView::revalidate);
    }
}
void FilesCoordinator::focusFolderViewer(int id, bool repaintAnyway){
    if( !m_blockRevalidating ){
        QTimer::singleShot(0, [=](){m_folderViewer->focusId(id, repaintAnyway);});
    }
}

void FilesCoordinator::setWaitingAnimation(bool wait)
{
    Q_UNUSED(wait);
    QTimer::singleShot(0, m_folderViewer, &GraphicsView::setWaitingAnimation);

}


void FilesCoordinator::setRootToGraphicsView()
{
    if(m_root){
        QTimer::singleShot(0, m_folderViewer, [=](){
            m_folderViewer->setRoot(m_root);
        });
    }
}
