#include "staticfunctions.h"

QFont StaticFunctions::getGoshFont(int fontSize, int weight)
{
    return QFont("Helvetica [Cronyx]", fontSize, weight);
}

QColor StaticFunctions::getGoshBlueColor()
{
    return QColor(180,180,255,90);
}

QString StaticFunctions::getFileType(const QString &fileName)
{
    int lastIndxOf = fileName.lastIndexOf(".");

    return lastIndxOf == -1 ? "" : fileName.section(".", -1);
}

QString StaticFunctions::getFileTypeWithDot(const QString &fileName)
{
    int lastIndxOf = fileName.lastIndexOf(".");

    return lastIndxOf == -1 ? "" : QString(".").append(fileName.section(".", -1));
}

QString StaticFunctions::getFileNameWithoutFileType(const QString &fileName)
{
    QString fileType = getFileType(fileName);
    if(fileType.isEmpty()){
        return fileName;
    }
    return fileName.left(fileName.length()-fileType.length()-1);
}

void StaticFunctions::removeChildrenFromLayout(QLayout* lay, const QVector<QLayoutItem*>& notToDelete){
    if ( lay != nullptr ){
        QLayoutItem* item;
        while ( (item = lay->takeAt(0)) != nullptr ){
//            if( !notToDelete.contains(item) ){
                if(dynamic_cast<QLayout*>(item) != nullptr){
                    deleteLayoutandContainingWidgets(dynamic_cast<QLayout*>(item), lay);
                }else{
                    if(item != nullptr){
                        delete item->widget();
                        delete item;
                    }
                }
//            }
        }
    }
}

void StaticFunctions::deleteLayoutandContainingWidgets(QLayout *lay, QLayout *parent)
{
    if ( lay != NULL ){
        QLayoutItem* item;
        while ( (item = lay->takeAt(0)) != NULL ){
            if(dynamic_cast<QLayout*>(item) != NULL){
                deleteLayoutandContainingWidgets(dynamic_cast<QLayout*>(item), lay);
            }else{
                if(item != NULL){
                    delete item->widget();
                    delete item;
                }
            }
        }
        if(parent)
            parent->removeItem(lay);
        delete lay;
    }
}
void StaticFunctions::deleteLayoutandContentsFromWidget(QWidget *widget, QLayout* parent)
{
    if(widget){
        QLayout* lay = widget->layout();
        widget->setLayout(nullptr);
        if(lay){
            deleteLayoutandContainingWidgets(lay);
        }
        if(parent)
            parent->removeWidget(widget);
        delete widget;
    }
}

QPoint StaticFunctions::rotatePoint(const QPoint& p, const QPoint& center, float angle)
{
    float s = qSin(qDegreesToRadians(angle));
    float c = qCos(qDegreesToRadians(angle));

    float px = p.x();
    float py = p.y();

    float cx = center.x();
    float cy = center.y();

    px -= cx;
    py -= cy;

    float xnew = px * c - py * s;
    float ynew = px * s + py * c;

    return QPoint( xnew + cx, ynew + cy );
}

QIcon StaticFunctions::getFileIcon(const QFileInfo &info)
{
    QFileIconProvider ip;
    return ip.icon(info);
}

//-------------------------------------------------------------------------------------------------------


QRect StaticFunctions::qRectF_to_qRect(const QRectF& rectF){
    return QRect((int)rectF.x(), (int)rectF.y(),
                 (int)rectF.width(), (int)rectF.height());
}
QRectF StaticFunctions::qRect_to_qRectF(const QRect& rct){
    return QRectF(((float)rct.x()),
                  ((float)rct.y()),
                  ((float)rct.width()),
                  ((float)rct.height()));
}
void StaticFunctions::paintCrossRect(QPainter *painter, const QRectF& rct){
    float offsX = ((float)rct.width()) * 0.1;
    float offsY = ((float)rct.height()) * 0.1;

    QRectF wndwRct = QRect(rct.left()+offsX,
                    rct.top()+offsY,
                    rct.width()-offsX*2,
                    rct.height()-offsY*2);

    painter->save();
    float penWidth = (float)((qMin(offsX, offsY)) *0.2);
    if (penWidth < 1.5){penWidth = 1.5;}
    if (penWidth > 3.){penWidth = 3.;}
    painter->setPen(QPen(QColor(0,0,0, 255), penWidth, Qt::SolidLine));
    painter->drawLine(wndwRct.right(), wndwRct.top(),
                      wndwRct.left(),  wndwRct.bottom());
    painter->drawLine(wndwRct.left(), wndwRct.top(),
                      wndwRct.right(),  wndwRct.bottom());
    painter->restore();
}
void StaticFunctions::paintCrossRect(QPainter *painter, const QRect& rct){
    paintCrossRect(painter, qRect_to_qRectF(rct));
}

void StaticFunctions::paintArrowUpDown(QPainter *painter, const QRectF& rct, bool up){
    float offsX = ((float)rct.width()) * 0.2;
    float offsY = ((float)rct.height()) * 0.2;
    QRectF wndwRct = QRect(rct.left()+offsX,
                    rct.top()+offsY,
                    rct.width()-offsX*2,
                    rct.height()-offsY*2);

    painter->save();
    float penWidth = qMin((float)qMin(offsX, offsY), (float)2.);
    painter->setPen(QPen(QColor(0,0,0, 255), penWidth, Qt::SolidLine));
    QPainterPath path;
    if(up){
        path.moveTo(wndwRct.left(), wndwRct.bottom());
        path.lineTo(wndwRct.center().x(), wndwRct.top());
        path.lineTo(wndwRct.right(), wndwRct.bottom());
    }else{
        path.moveTo(wndwRct.left(), wndwRct.top());
        path.lineTo(wndwRct.center().x(), wndwRct.bottom());
        path.lineTo(wndwRct.right(), wndwRct.top());
    }
    painter->drawPath(path);
    painter->restore();
}
void StaticFunctions::paintArrowUp(QPainter *painter, const QRectF& rct){
    paintArrowUpDown(painter, rct, true);

}
void StaticFunctions::paintArrowDown(QPainter *painter, const QRectF& rct){
    paintArrowUpDown(painter, rct, false);
}

void StaticFunctions::paintRect(QPainter *painter, const QRectF& rct){
    QLinearGradient gradient = QLinearGradient(rct.topLeft(), rct.bottomRight());
    gradient.setColorAt(0, QColor(255,255,255, 255));
    gradient.setColorAt(1, QColor(220,220,220, 255));
    painter->setPen(QPen(QColor(0,0,0, 70)));
    painter->setBrush(QBrush(gradient));
    painter->drawRect(rct);
}
void StaticFunctions::paintRect(QPainter *painter, const QRect& rct){
    paintRect(painter, qRect_to_qRectF(rct));
}

void StaticFunctions::paintRect(QPainter *painter, const QRectF& rct,
               const QColor& gradCol1, const QColor& gradCol2,
               const QColor& penColor,
               int bordWidth){
    if(gradCol2 == nullptr){
        painter->setBrush(gradCol1);
    }else{
        QLinearGradient gradient = QLinearGradient(rct.topLeft(), rct.bottomRight());
        gradient.setColorAt(0, gradCol1);
        gradient.setColorAt(1, gradCol2);
        painter->setBrush(QBrush(gradient));
    }
    painter->setPen(QPen(penColor, bordWidth));
    painter->drawRect(rct);
}
void StaticFunctions::paintTextRect(QPainter *painter, const QString& str,
                   const QRectF& rct,
                   const QColor& gradCol1, const QColor& gradCol2,
                   const QColor& textCol,
                   const QFont font,
                   const QColor& borderCol,
                   int bordWidth){
    paintRect(painter, rct, gradCol1, gradCol2,borderCol, bordWidth);
    painter->setFont(font);
    QFontMetrics fm(painter->font());
    int strWidth = fm.width(str);
    int strHeight = fm.height();
    painter->setPen(QPen(textCol));
    painter->drawText(QPointF(rct.center()-
                             QPointF(strWidth*0.5, strHeight*0.5-fm.ascent())
                             ),
                      str);
}
void StaticFunctions::paintPixmapRect(QPainter *painter, const QPixmap& pixmap,
                   const QRectF& rct,
                   const QColor& gradCol1, const QColor& gradCol2,
                   const QColor& borderCol,
                   int bordWidth){
    paintRect(painter, rct, gradCol1, gradCol2,borderCol, bordWidth);
    QRectF pixmpRct( (rct.center()-QPointF(pixmap.width()*0.5, pixmap.height()*0.5)),
                     QSizeF(pixmap.width(), pixmap.height()) );
    painter->drawPixmap(pixmpRct, pixmap, QRectF(0,0,pixmap.width(), pixmap.height()));
}

void StaticFunctions::paintLoupe(QPainter *painter, const QRectF& rct, SHAPE shape){
    qreal edge = rct.width(); // edge==Kante -> rct muss quadratisch sein!
    qreal radFctr = 1./3.;
    qreal centFctr = 4./10.;
    qreal circRadius = edge * radFctr;
    qreal circCenterX = rct.left() + edge * centFctr;
    qreal circCenterY = rct.top() + edge * centFctr;
    qreal circLeft = rct.left() + edge * (centFctr-radFctr);
    qreal circTop = rct.top() + edge * (centFctr-radFctr);
    qreal sine45 = sin(45. * 3.141592653589793 / 180.0);
    qreal loupeCenterX = circCenterX + sine45 * circRadius;
    qreal loupeCenterY = circCenterY + sine45 * circRadius;
    qreal radialCenterX = circCenterX - (sine45 * circRadius) / 2.;
    qreal radialCenterY = circCenterY - (sine45 * circRadius) / 2.;

    painter->save();

    QRadialGradient gradient = QRadialGradient(QPoint(radialCenterX,radialCenterY), circRadius);
    gradient.setSpread(QGradient::ReflectSpread);
    QColor circCol1(255,255,255, 255);
    QColor circCol2(220,220,220, 255);
    gradient.setColorAt(0, circCol1);
    gradient.setColorAt(1, circCol2);
    painter->setPen(QPen(QColor(0,0,0), 1, Qt::SolidLine));
    painter->setBrush(QBrush(gradient));
    painter->drawEllipse(circLeft, circTop, circRadius*2., circRadius*2.);

    painter->setBrush(QColor(0,0,0));
    qreal strokeWidth = 3.;
    painter->setPen(QPen(QColor(0,0,0), strokeWidth, Qt::SolidLine));
    QPointF loupeCenter(loupeCenterX +strokeWidth*0.5, // 7/12 == 1/3<->circCenter + 1/4<->circRadius
                       loupeCenterY +strokeWidth*0.5);
    QPointF loupeRightBottom(rct.right() - edge/6.,
                            rct.bottom() - edge/6.);
    painter->drawLine(loupeCenter, loupeRightBottom);

    painter->setPen(QPen(QColor(0,0,0), strokeWidth*0.5, Qt::SolidLine));
    if(shape == SHAPE::PLUS || shape == SHAPE::MINUS){
        painter->drawLine(QPointF(circCenterX-(circRadius*2./3.),
                                  circCenterY),
                          QPointF(circCenterX+(circRadius*2./3.),
                                  circCenterY));
        if (shape == SHAPE::PLUS){
            painter->drawLine(QPointF(circCenterX,
                                      circCenterY-(circRadius*2./3.)),
                              QPointF(circCenterX,
                                      circCenterY+(circRadius*2./3.)));
        }
    }

    painter->restore();
}

void StaticFunctions::paintPixmap(QPainter *painter, const QRectF& target, QString imgPath){
    QPixmap pixmap(imgPath);
    QSize source = pixmap.size();

    painter->drawPixmap(target, pixmap, QRectF(QPointF(0,0), source));
}

//-------------------------------------------------------------------------------------------------------

QString StaticFunctions::getUniqueFileName(const QString& dirName, const QString& fileName){
    int counter = 1;
    QString suffix("");
    QString blankFileName = getFileNameWithoutFileType(fileName);
    QString fileType = getFileTypeWithDot(fileName);
    while(QFileInfo(QString(dirName).append(QDir::separator())
                 .append(blankFileName)
                 .append(suffix)
                 .append(fileType)).exists()){
        suffix = QString("_(%1)").arg(counter++);
    }
    return blankFileName.append(suffix).append(fileType);
}
QString StaticFunctions::getUniqueFolderName(const QString& path, const QString &foldName){
    int counter = 1;
    QString suffix("");
    while(QFileInfo(QString(path)
                    .append(QDir::separator())
                    .append(foldName)
                    .append(suffix)).exists()){
        suffix = QString("_(%1)").arg(counter++);
    }
    return QString(foldName).append(suffix);
}

bool StaticFunctions::copyFile(const QString& absSourcePath, const QString& tarPath, const QString& tarName)
{
//    QString absSourcePath = soucrePath.append(QDir.separator()).append(sourceName);
//    qDebug() << "in copyFile:"
//             << "\n     absSourcePath:  " << absSourcePath
//             << "\n     tarPath:        " << tarPath
//             << "\n     tarName:        " << tarName;
    if(QFileInfo(absSourcePath).exists()){
        QString uniqueFileName = getUniqueFileName(tarPath, tarName);

        QString copyTarget = QString(tarPath).append(QDir::separator()).append(uniqueFileName);
//        qDebug() << "       exists!: uniqueFileName: " << uniqueFileName
//                 << "       isFolder: " << QFileInfo(copyTarget).isDir()
//                 << "\n                 copyTarget:  " << copyTarget;

        QFile::copy(absSourcePath, copyTarget);
        return true;
    }
    return false;
}

bool StaticFunctions::copyFolder(const QString& absSourcePath, const QString& tarPath, const QString& tarName)
{
    if(QFileInfo(absSourcePath).exists()){
        QString uniqueTarFolderName = getUniqueFolderName(tarPath, tarName);
        QString tarFolderPath = QString(tarPath).append(QDir::separator()).append(uniqueTarFolderName);

//        qDebug() << "in copyFolder: "
//                    "\n   absSourcePath:        " << absSourcePath
//                 << "\n   tarPath:              "    << tarPath
//                 << "\n   tarname:              " << tarName
//                 << "\n   uniqueTarFolderName:  " << uniqueTarFolderName
//                 << "\n   tarFolderPath:        " << tarFolderPath;

        bool succ_created = QDir().mkdir(tarFolderPath);

//        qDebug() << "created";

        if(succ_created){
            QFileInfoList content = QDir(absSourcePath).entryInfoList(QDir::AllEntries | QDir::NoDotAndDotDot);

            bool success = true;
            foreach(auto cont, content){
//                qDebug() << "       subfolder: " << cont.absoluteFilePath();
                if(cont.isDir()){
                    success = copyFolder(cont.absoluteFilePath(), tarFolderPath, cont.fileName());
                }else{
                    success = copyFile(cont.absoluteFilePath(), tarFolderPath, cont.fileName());
                }

//                qDebug() << "success: " << success << "     <- file: " << cont.fileName();
//                if(!success)
//                    return false;
            }
        }else{
            return false;
        }
    }
    return false;
}

bool StaticFunctions::duplicateFile(const QFileInfo &source)
{
    return copyFile  (source.absoluteFilePath(), source.absolutePath(), source.fileName());
}

bool StaticFunctions::duplicateFolder(const QFileInfo &source)
{
    return copyFolder(source.absoluteFilePath(), source.absolutePath(), source.fileName());
}

bool StaticFunctions::deleteFile(const QFileInfo &path)
{
    if(path.exists() && path.isFile()){
        return QDir().remove(path.absoluteFilePath());
    }
    return true;// already deleted
}

bool StaticFunctions::deleteFolder(const QFileInfo &path)
{
    if(path.isDir()){
        return QDir(path.absoluteFilePath()).removeRecursively();
    }

//    if(path.exists()){
//        QFileInfoList content = QDir(path.absoluteFilePath()).entryInfoList();
//        foreach(QFileInfo fi, content){
//            if(fi.isDir()){
//                deleteFolder(fi);
//            }else{
//                deleteFile(fi);
//            }
//        }
//        return QDir::remove(path.absoluteFilePath());
//    }
//    return true; // already deleted
}


bool StaticFunctions::renameFolder(const QFileInfo &absFilePath)
{
    bool ok;
    QString text = QInputDialog::getText(nullptr, QString(""),
                                         QString("Rename to:"), QLineEdit::Normal,
                                         absFilePath.fileName(), &ok);
    if (ok && !text.isEmpty()){
        QString newAbsFilePath = absFilePath.absolutePath().append(QDir::separator()).append(text);
        if( QFileInfo(newAbsFilePath).exists() ){
            QErrorMessage().showMessage(QString("could not rename file to '%1' \n - does alread exist!").arg(text));
        }else{
            QFile().rename(absFilePath.absoluteFilePath(), newAbsFilePath);
        }
    }
}

ORDER_BY StaticFunctions::getOppositeOfOrder(ORDER_BY order)
{
    {
            if(      order == ORDER_BY::NAME){
                return ORDER_BY::R_NAME;
            }else if(order == ORDER_BY::TYPE){
                return ORDER_BY::R_TYPE;
            }else if(order == ORDER_BY::MOD_DATE){
                return ORDER_BY::R_MOD_DATE;
            }else if(order == ORDER_BY::SIZE){
                return ORDER_BY::R_SIZE;
            }

            else if(order == ORDER_BY::R_NAME){
                return ORDER_BY::NAME;
            }else if(order == ORDER_BY::R_TYPE){
                return ORDER_BY::TYPE;
            }else if(order == ORDER_BY::R_SIZE){
                return ORDER_BY::SIZE;
            }else{// if(order == ORDER_BY::R_MOD_DATE){
                return ORDER_BY::MOD_DATE;
            }
        }
}

bool StaticFunctions::zipFile(const QVector<QFileInfo> &absSourcePaths, const QString &tarPath, const QString &tarName)
{
//    QString tarPath = QString("%1%2%3").arg(tarPath).arg(QDir::separator()).arg(tarName);


//    QByteArray compressedData;// = qCompress(uncompressedData,9);

//    foreach(QFileInfo fi, absSourcePaths){
//        if(fi.isDir()){

//        }else if (fi.isFile()){
//            QFile infile( fi.absoluteFilePath() );
//            if(infile.open(QIODevice::ReadOnly)){
//                QByteArray uncompressedData = infile.readAll();
//                compressedData.append( qCompress(uncompressedData, 9) );
//                infile.close();
//            }
//        }
//    }

//    QFile outfile( tarPath );
//    outfile.open(QIODevice::WriteOnly);
//    outfile.write(compressedData);
//    outfile.close();
}

bool StaticFunctions::unZipFile(const QFileInfo &absSourcePath, const QString &tarPath, const QString &tarName)
{

}

bool StaticFunctions::createNewFolder(const QString &tarPath, QString &foldName)
{
    foldName = getUniqueFolderName(tarPath, foldName);
    bool successfullyCreated = QDir().mkdir( QString("%1%2%3")
                  .arg(tarPath)
                  .arg(QDir::separator())
                  .arg(foldName) );
    return successfullyCreated;
}

bool StaticFunctions::createNewFile(const QString& tarPath, QString& fileName)
{
    fileName = getUniqueFileName(tarPath, fileName);
    QFile file( QString("%1%2%3")
                .arg(tarPath)
                .arg(QDir::separator())
                .arg(fileName) );
    bool successfullyCreated = file.open(QIODevice::WriteOnly);
    file.close();
    return successfullyCreated;
}

void StaticFunctions::setIconToWidget(QWidget *widget)
{
    QString windowIconPath = QString("%1%2%3")
            .arg("pics")
            .arg(QDir::separator())
            .arg("MrSoir_antique.png");
    widget->setWindowIcon(QIcon(windowIconPath));
}
