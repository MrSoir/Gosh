#include "graphicsview.h"

enum ORIENTATION{VERTICAL, HORIZONTAL};

class MenuBar : public GraphicsItemBD{
public:
    MenuBar(qreal maxWidthOrHeight,
            QPointF centerPosition,
            ORIENTATION orientation = ORIENTATION::HORIZONTAL,
            bool m_centerFromEnd = false,
            QGraphicsItem* parent = nullptr)
        : GraphicsItemBD(QSize(0,0), QPoint(0,0), parent),
          m_orientation(orientation),
          m_centerFromEnd(m_centerFromEnd),
          m_centerOrientation(centerPosition),
          m_maxWidthOrHeight(maxWidthOrHeight)
    {
        revalidateSize();
    }
    ~MenuBar(){
        m_btnFuncs.reset();
        m_paintingFuncs.reset();
    }

    void setPosition(QPoint position){
        m_centerOrientation += position;
    }

    QRectF boundingRect() const override{
        QRectF rct;
        if(m_centerFromEnd){
            if(m_orientation == ORIENTATION::HORIZONTAL){
                rct = QRectF(m_centerOrientation.x() - m_size.width()*0.5,
                              m_centerOrientation.y() - m_size.height(),
                              m_size.width(),
                              m_size.height());
            }else{
                rct = QRectF(m_centerOrientation.x() - m_size.width(),
                              m_centerOrientation.y() - m_size.height()*0.5,
                              m_size.width(),
                              m_size.height());
            }
        }else{
            if(m_orientation == ORIENTATION::HORIZONTAL){
                rct = QRectF(m_centerOrientation.x() - m_size.width()*0.5,
                          m_centerOrientation.y(),
                          m_size.width(),
                          m_size.height());
            }else{
                rct = QRectF(m_centerOrientation.x(),
                              m_centerOrientation.y() - m_size.height()*0.5,
                              m_size.width(),
                              m_size.height());
            }
        }
//        qDebug() << "\n\nin boundingRect:   x: " << rct.x()
//                 << "   y: " << rct.y()
//                 << "   width: " << rct.width()
//                 << "   height: " << rct.height()
//                 << "\n";
        return rct;
    }
    void setOrientation(ORIENTATION orientation){
        m_orientation = orientation;
        revalidateSize();
        revalidate = true;
        update();
    }
    void revalidateSize(){
//        qDebug() <<"\nstarting revalidateSize\n";

        if(orientation() == ORIENTATION::HORIZONTAL){
            m_size = QSize(m_maxWidthOrHeight, 0);
        }else{
            m_size = QSize(0,m_maxWidthOrHeight);
        }
//        qDebug() << "in boundingRect:   "
//                 << "   width: " << m_size.width()
//                 << "   height: " << m_size.height();

        if (orientation() == ORIENTATION::VERTICAL ){
//            qreal paneWidth = (qreal)rct.width();
            qreal paneHeight = (qreal)m_size.height();
            qreal btnCountR = (qreal)m_btnsCount;
            qreal paintHeight = paneHeight - 2.0*m_padding;

//            qDebug() << "II: orientation: " << m_orientation
//                     << "   paintHeight: " << paneHeight
//                     << "   btnCountR:  " << btnCountR
//                     << "   paintHeight: " << paintHeight;

            if( paneHeight > (btnCountR*(m_btnEdge+m_offsets) + 2.0*m_padding) ){
                paneHeight = (m_btnEdge+m_offsets) * btnCountR + 2.0*m_padding;
                qreal paneWidth = m_btnEdge + m_padding*2.0;
                m_size = QSize(paneWidth, paneHeight);
                m_anzColumns = 1;
                m_anzRows = btnCountR;

//                qDebug() << "III: paneHeight: " << paneHeight
//                         << "   paneWidth: " << paneWidth
//                         << "   m_anzColumns:  " << m_anzColumns
//                         << "   m_anzRows: " << m_anzRows;
            }else{
                qreal maxElmntsPerColumn = floor( paintHeight / (m_btnEdge+m_offsets) );
                qreal anzColumns = ceil( btnCountR / maxElmntsPerColumn );
                qreal anzRows = ceil( btnCountR / anzColumns );
                paneHeight = anzRows * (m_btnEdge+m_offsets) + 2.0*m_padding;
                qreal paneWidth = anzColumns *(m_btnEdge+m_offsets) + 2.0*m_padding;
                m_size = QSize(paneWidth, paneHeight);
                m_anzColumns = anzColumns;
                m_anzRows = anzRows;

//                qDebug() << "IV: maxElmntsPerColumn: " << maxElmntsPerColumn
//                         << "   anzColumns: " << anzColumns
//                         << "   anzRows:  " << anzRows
//                         << "   paneHeight:  " << paneHeight
//                         << "   paneWidth: " << paneWidth
//                         << "   m_maxWidthOrHeight: " << m_maxWidthOrHeight;
            }
        }else{
            qreal paneWidth = (qreal)m_size.width();
//            qreal paneHeight = (qreal)rct.height();
            qreal btnCountR = (qreal)m_btnsCount;
            qreal paintWidth = paneWidth - 2.0*m_padding;

//            qDebug() << "V: paneWidth: "   << paneWidth
//                     << "   btnCountR: "   << btnCountR
//                     << "   paintWidth:  " << paintWidth
//                     << "   m_btnEdge: "   << m_btnEdge
//                     << "   offsets: "     << m_offsets
//                     << "   padding: "     << m_padding;

            if(paneWidth > (btnCountR*(m_btnEdge+m_offsets) + 2.0*m_padding) ){
                paneWidth = btnCountR*(m_btnEdge+m_offsets) + 2.0*m_padding;
                qreal paneHeight = m_btnEdge + 2.0*m_padding;
                m_size = QSize(paneWidth, paneHeight);
                m_anzColumns = btnCountR;
                m_anzRows = 1;

//                qDebug() << "VI: paneWidth: " << paneWidth
//                         << "   paneHeight: " << paneHeight
//                         << "   m_anzColumns:  " << m_anzColumns
//                         << "   m_anzRows: " << m_anzRows
//                         << "   (m_btnEdge+m_offsets): " << (m_btnEdge+m_offsets)
//                         << "   2.0*m_padding: " << (2.0*m_padding);
            }else{
                qreal maxElmntsPerRow = floor(paintWidth / (m_btnEdge+m_offsets));
                qreal anzRows = ceil( btnCountR / maxElmntsPerRow );
                qreal anzColumns = ceil( btnCountR / anzRows );
                paneWidth = anzColumns * (m_btnEdge+m_offsets) + 2.0*m_padding;
                qreal paneHeight = anzRows * (m_btnEdge+m_offsets) + 2.0*m_padding;
                m_size = QSize(paneWidth, paneHeight);
                m_anzColumns = anzColumns;
                m_anzRows = anzRows;

//                qDebug() << "VII: maxElmntsPerRow: " << maxElmntsPerRow
//                         << "   anzRows: " << anzRows
//                         << "   anzColumns:  " << anzColumns
//                         << "   paneHeight:  " << paneHeight
//                         << "   paneWidth: " << paneWidth;
            }
        }
//        qDebug() <<"\nfinishing revalidateSize\n\n";
    }
    void setCaller(auto btnFunctions, auto buttonPaintingFunctions){
        this->m_btnFuncs = btnFunctions;
        this->m_paintingFuncs = buttonPaintingFunctions;
        m_btnsCount = btnFunctions->formulaCount();
        m_buttons.clear();
        m_mouInBtns.clear();
        for(int i=0; i < m_btnsCount; i++){
            m_buttons.append(QRectF(0.,0., 0.,0.));
            m_mouInBtns.append(false);
        }
        revalidateSize();
    }

    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget){
        Q_UNUSED(widget)
        Q_UNUSED(option)

        // gaaanz wichtig: erstmal painter an boundingRect clippen!!!:
        QRectF rct = boundingRect();

        painter->setRenderHint(QPainter::Antialiasing, true);

        painter->setClipRect(rct);

        int alpha = 200;
        QColor gradCol1(255,255,255, alpha);
        QColor gradCol2(255,255,255, alpha);
        StaticFunctions::paintRect(painter, rct, gradCol1, gradCol2);

        if(revalidate){
            qreal startX;
            qreal startY;
            if(orientation() == ORIENTATION::HORIZONTAL){
                startX = m_centerOrientation.x() - m_size.width()*0.5 + m_padding;
                if(m_centerFromEnd){
                    startY = m_centerOrientation.y() - m_size.height() + m_padding;
                }else{
                    startY = m_centerOrientation.y() + m_padding;
                }
            }else{
                startY = m_centerOrientation.y() - m_size.height()*0.5 + m_padding;
                if(m_centerFromEnd){
                    startX = m_centerOrientation.x() - m_size.width() + m_padding;
                }else{
                    startX = m_centerOrientation.x() + m_padding;
                }
            }

            for(int i=0; i < m_buttons.size(); i++){
                if(orientation() == ORIENTATION::VERTICAL){
                    m_buttons[i].setX( startX + (i % m_anzColumns) * (m_btnEdge + m_offsets) );
                    m_buttons[i].setY( startY + ((int)(i / m_anzColumns)) * (m_btnEdge + m_offsets) );
                }else{
                    m_buttons[i].setX( startX + (i % m_anzColumns) * (m_btnEdge+m_offsets) );
                    m_buttons[i].setY( startY + ((int)(i / m_anzColumns))  * (m_btnEdge+m_offsets) );
                }
                m_buttons[i].setWidth (m_btnEdge);
                m_buttons[i].setHeight(m_btnEdge);
//                qDebug() << "\n button[" << i << "]:"
//                         << "   startX: " << startX
//                         << "   startY: " << startY
//                         << "   m_anzColumns: " << m_anzColumns
//                         << "   m_btnEdge: " << m_btnEdge
//                         << "   m_offsets: " << m_offsets
//                         << "\n    m_anzRows: " << m_anzRows
//                         << "   (i % m_anzColumns): " << (i % m_anzColumns)
//                         << "   (i % m_anzRows): " << (i % m_anzRows)
//                         << "   ((int)(i / m_anzColumns)): " << ((int)(i / m_anzColumns))
//                         << "   ((int)(i / m_anzRows)): " << ((int)(i / m_anzRows))
//                         << "   (m_btnEdge + m_offsets): " << (m_btnEdge + m_offsets);
            }
        }
        for(int i=0; i < m_buttons.size(); i++){
            QColor nextColor1, nextColor2;
            if(m_mouInBtns[i]){
                nextColor1 = QColor(255, 255, 255, 255);
                nextColor2 = QColor(200, 200, 200, 255);
            }else{
                nextColor1 = QColor(255, 255, 255, 255);
                nextColor2 = QColor(255, 255, 255, 255);
            }
            StaticFunctions::paintRect(painter, m_buttons[i], nextColor1, nextColor2);
            m_paintingFuncs->getFunction(QString("paintingFunction%1").arg(i))(painter, m_buttons[i]);
        }

        revalidate = false;
    }

    ORIENTATION orientation(){return m_orientation;}
protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event){
        QPointF mouP = event->pos();
        for(int i=0; i < m_buttons.size(); i++){
            if(m_buttons[i].contains(mouP) && m_btnFuncs){
                m_btnFuncs->getFunction(QString("buttonFunction%1").arg(i))();
            }
        }
        qint64 curTime = QDateTime::currentMSecsSinceEpoch();
        if(curTime - lastTmePrsd < 300){

        }
        lastTmePrsd = curTime;
        update();
    }
    void hoverMoveEvent(QGraphicsSceneHoverEvent * event){
        QPointF mouP = event->pos();
        bool anyBtnTrue = false;
        bool updt = false;
        for(int i=0; i < m_buttons.size(); i++){
            if(m_buttons.at(i).contains(mouP)){
                if(!m_mouInBtns.at(i)){
                    m_mouInBtns[i] = true;
                    updt = true;
                }
            }else{
                if(m_mouInBtns.at(i))
                    anyBtnTrue = true;
            }
        }
        if(anyBtnTrue){
            for(int i=0; i < m_buttons.size(); i++){
                m_mouInBtns[i] = false;
            }
            updt = true;
        }
        if(updt)
            update();
//        return QGraphicsItem::hoverEnterEvent(event);
    }
private:
    int m_anzRows = 1;
    int m_anzColumns = 1;
    qreal m_btnEdge = 45.0;
    qreal m_padding = 3.0;
    qreal m_offsets = 2.0;
    qreal m_maxWidthOrHeight = 0.0;
    QPointF m_centerOrientation = QPointF(0,0);
    bool m_centerFromEnd = false;
    int m_btnsCount = 0;
    QVector<QRectF> m_buttons;
    QVector<bool> m_mouInBtns;

    std::shared_ptr<DynamicFunctionCaller<QString, std::function<void()>>> m_btnFuncs = std::shared_ptr<DynamicFunctionCaller<QString, std::function<void()>>>();
    std::shared_ptr<DynamicFunctionCaller<QString, std::function<void(QPainter*, QRectF)>>> m_paintingFuncs = std::shared_ptr<DynamicFunctionCaller<QString, std::function<void(QPainter*, QRectF)>>>();

    qint64 lastTmePrsd = Q_INT64_C(0);

    ORIENTATION m_orientation = ORIENTATION::HORIZONTAL;
};

class SearchMenuBD : public GraphicsItemBD{
public:
    SearchMenuBD(const QSize& size = QSize(0,0),
                 const QPoint& pos = QPoint(0,0),
                 QGraphicsItem* parent = nullptr)
        : GraphicsItemBD(size, pos, parent)
    {}
    ~SearchMenuBD(){
        m_caller.reset();
    }
    void setCaller(auto caller){
        this->m_caller = caller;
    }

    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget){
        Q_UNUSED(widget)
        Q_UNUSED(option)

        // gaaanz wichtig: erstmal painter an boundingRect clippen!!!:
        QRectF rct = boundingRect();

        painter->setRenderHint(QPainter::Antialiasing, true);

        painter->setClipRect(rct);

        QColor gradCol1(255,255,255, 200);
        QColor gradCol2(255,255,255, 200);
        StaticFunctions::paintRect(painter, rct, gradCol1, gradCol2);

        if(revalidate){
            float prevBtnWidth = (float)qMin((float)(rct.width() * 0.2), (float)80.);
            float prevBtnHeight = rct.height() * 0.5;
            float offs = 20;
            float prevBtnX = rct.center().x() - prevBtnWidth - offs;
            float nextBtnX = rct.center().x() + offs;
            float upBtnY = 3 + rct.y();
            m_preBtn = QRectF(prevBtnX, upBtnY, prevBtnWidth, prevBtnHeight);
            m_nextBtn = QRectF(nextBtnX, upBtnY, prevBtnWidth, prevBtnHeight);

            float closeBtnWidth = (float)qMin((float)(rct.width() * 0.5), (float)40.);
            float closeBtnHeight = rct.height() * 0.4;
            offs = rct.width() * 0.05;
            float closeBtnX = rct.right()-closeBtnWidth-offs;
            float closeBtnY = rct.center().y()-(float)(closeBtnHeight*0.5);
            m_closeBtn = QRectF(closeBtnX,
                                closeBtnY,
                                closeBtnWidth,
                                closeBtnHeight);
        }
        QColor nextColor1 = QColor(255, 255, 255, 255),
               nextColor2 = QColor(255, 255, 255, 255),
               prevColor1 = QColor(255, 255, 255, 255),
               prevColor2 = QColor(255, 255, 255, 255),
               closColor1 = QColor(255, 255, 255, 255),
               closColor2 = QColor(255, 255, 255, 255);
        if(mouInNextBtn){
            nextColor1 = QColor(255, 255, 255, 255);
            nextColor2 = QColor(200, 200, 200, 255);
        }else if (mouInPrevBtn){
            prevColor1 = QColor(255, 255, 255, 255);
            prevColor2 = QColor(200, 200, 200, 255);
        }else if (mouInCloseBtn){
            closColor1 = QColor(255, 180, 180, 255);
            closColor2 = QColor(255, 0, 0, 255);
        }
        StaticFunctions::paintRect(painter, m_nextBtn,
                  nextColor1,
                  nextColor2);
        StaticFunctions::paintArrowDown(painter, m_nextBtn);
        StaticFunctions::paintRect(painter, m_preBtn,
                  prevColor1,
                  prevColor2);
        StaticFunctions::paintArrowUp(painter, m_preBtn);

        StaticFunctions::paintRect(painter, m_closeBtn,
                  closColor1,
                  closColor2);
        StaticFunctions::paintCrossRect(painter, m_closeBtn);

        if(m_caller){
            QString str = m_caller->getFunction("getSearchResult")();
            if(str.isEmpty()){
                str = QString("no match!");
            }
             str.prepend("--").append("--");

            QFont font = StaticFunctions::getGoshFont(12);
            painter->setFont(font);
            QFontMetrics fm(font);
            int pixelsWidth = fm.width(str);
            int pixelsHeight = fm.height();
            int offsTxt = 2;
            painter->setPen(QPen(QColor(0,0,0), 3, Qt::SolidLine));
            painter->drawText(QRect(rct.center().x()-pixelsWidth*0.5,
                                    rct.bottom() - pixelsHeight -offsTxt,
                                    pixelsWidth*2,
                                    pixelsHeight),
                                    str);
        }

        revalidate = false;
    }
protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event){
        QPointF mouP = event->pos();
        if(       m_nextBtn.contains(mouP) && m_caller){
            m_caller->getFunction(QString("next"))();
        }else if (m_preBtn.contains(mouP) && m_caller){
            m_caller->getFunction(QString("previous"))();
        }else if (m_closeBtn.contains(mouP) && m_caller){
            qDebug() << "SearchMenu close-Btn pressed!";
            m_caller->getFunction(QString("close"))();
        }
        qint64 curTime = QDateTime::currentMSecsSinceEpoch();
        if(curTime - lastTmePrsd < 300){

        }
        lastTmePrsd = curTime;
        update();
    }
    void hoverMoveEvent(QGraphicsSceneHoverEvent * event){
        QPointF mouP = event->pos();
        if(       m_nextBtn.contains(mouP)){
            if(!mouInNextBtn){
                mouInNextBtn = true;
                update();
                return;
            }
        }else if (m_preBtn.contains(mouP)){
            if(!mouInPrevBtn){
                mouInPrevBtn = true;
                update();
                return;
            }
        }else if (m_closeBtn.contains(mouP)){
            if(!mouInCloseBtn){
                mouInCloseBtn = true;
                update();
                return;
            }
        }else if(mouInNextBtn || mouInPrevBtn || mouInCloseBtn){
            mouInNextBtn = false;
            mouInPrevBtn = false;
            mouInCloseBtn = false;
            update();
            return;
        }
//        return QGraphicsItem::hoverEnterEvent(event);
    }
private:
    QRectF m_nextBtn;
    QRectF m_preBtn;
    QRectF m_closeBtn;

    bool mouInNextBtn = false;
    bool mouInPrevBtn = false;
    bool mouInCloseBtn = false;

    std::shared_ptr<DynamicFunctionCaller<QString, std::function<QString()>>> m_caller = std::shared_ptr<DynamicFunctionCaller<QString, std::function<QString()>>>();

    qint64 lastTmePrsd = Q_INT64_C(0);
};
class ElapseMenuBD : public GraphicsItemBD{
public:
    ElapseMenuBD(int buttonCount,
                 int columnWidth,
                 const QSize& size = QSize(0,0),
                 const QPoint& pos = QPoint(0,0),
                 QGraphicsItem* parent = nullptr)
        : m_buttonCount(buttonCount),
          m_colWidth(columnWidth),
          GraphicsItemBD(size, pos, parent)
    {}
    ~ElapseMenuBD(){
        m_caller.reset();
    }
    void setCaller(auto caller){
        this->m_caller = caller;
    }

    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget){
        Q_UNUSED(widget)
        Q_UNUSED(option)

        // gaaanz wichtig: erstmal painter an boundingRect clippen!!!:
        QRectF rct = boundingRect();

        painter->setRenderHint(QPainter::Antialiasing, true);

        painter->setClipRect(rct);

        QColor gradCol1(0,0,0, 255);
        QColor gradCol2(0,0,0, 255);
        StaticFunctions::paintRect(painter, rct, gradCol1, gradCol2);

        if(revalidate){
            int xOffs = m_pos.x();
            int yOffs = m_pos.y();
            int buttonHeight = m_size.height();
            int buttonWidth = m_colWidth;
            for(int i=0; i < m_buttonCount; i++){
                QRectF rect(xOffs, yOffs, buttonWidth, buttonHeight);
                m_buttons.append(rect);
                xOffs += buttonWidth;
            }
        }
        QColor basicColor1 = QColor(0, 0, 255, 255),
               basicColor2 = QColor(0, 0, 0, 255),
               hoverColor1 = QColor(0, 0, 255, 255),
               hoverColor2 = QColor(0, 0, 100, 255),
               elapsedColor1 = QColor(180, 0, 0, 255),
               elapsedColor2 = QColor(0, 0, 0, 255),
               hoverElapsedColor1 = QColor(255, 0, 0, 255),
               hoverElapsedColor2 = QColor(100, 0, 0, 255);
        QColor col1, col2;
        int fontSize, fontWeight;
        for(int i=0; i < m_buttons.size(); i++){
            if(m_mouInButtonId == i){
                if(m_caller->containsFunction(QString("elapsed")) &&
                                     m_caller->getFunction(QString("elapsed"))(i)) {
                    col1 = hoverElapsedColor1;
                    col2 = hoverElapsedColor2;
                }else{
                    col1 = hoverColor1;
                    col2 = hoverColor2;
                }
                fontSize = 9;
                fontWeight = QFont::Bold;
            }else{
                if(m_caller->containsFunction(QString("elapsed")) &&
                     m_caller->getFunction(QString("elapsed"))(i)) {
                    col1 = elapsedColor1;
                    col2 = elapsedColor2;
                }else{
                    col1 = basicColor1;
                    col2 = basicColor2;
                }
                fontSize = 9;
                fontWeight = QFont::Normal;
            }
            StaticFunctions::paintTextRect(painter,
                                           QString("%1").arg(i+1),
                                           m_buttons[i], col1, col2,
                                           QColor(255,255,255,255),
                                           StaticFunctions::getGoshFont(fontSize, fontWeight));
        }

        revalidate = false;
    }
protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event){
        QPointF mouP = event->pos();
        for(int i=0; i < m_buttons.size(); i++){
            if(m_buttons[i].contains(mouP) && m_caller->containsFunction(QString("call"))){
                m_caller->getFunction(QString("call"))(i);
            }
        }
        qint64 curTime = QDateTime::currentMSecsSinceEpoch();
        if(curTime - lastTmePrsd < 300){

        }
        lastTmePrsd = curTime;
        update();
    }
    void hoverMoveEvent(QGraphicsSceneHoverEvent * event){
        QPointF mouP = event->pos();
        int hoverId = -1;
        for(int i=0; i < m_buttons.size(); i++){
            if(m_buttons[i].contains(mouP)){
                hoverId = i;
                break;
            }
        }
        if(hoverId != m_mouInButtonId){
            m_mouInButtonId = hoverId;
            update();
        }
//        return QGraphicsItem::hoverEnterEvent(event);
    }
    void hoverLeaveEvent(QGraphicsSceneHoverEvent* event){
        m_mouInButtonId = -1;
        update();
    }
private:
    QVector<QRectF> m_buttons;
    int m_mouInButtonId = -1;
    int m_colWidth;
    int m_buttonCount;

    std::shared_ptr<DynamicFunctionCaller<QString, std::function<bool(int)>>> m_caller = std::shared_ptr<DynamicFunctionCaller<QString, std::function<bool(int)>>>();

    qint64 lastTmePrsd = Q_INT64_C(0);
};
class WindowSelector : public GraphicsItemBD{
public:
    WindowSelector(const QSize& size,
                   const QPoint& pos,
                   QGraphicsItem *parent = nullptr)
        : GraphicsItemBD(size, pos, parent)
    {
        rects.append(nullptr);
        rects.append(nullptr);
        rects.append(nullptr);
        rects.append(nullptr);
    }
    ~WindowSelector(){
        foreach(QRect* rct, rects){
            delete rct;
        }
        rects.clear();
    }


    void setCaller(auto caller){
        this->caller = caller;
    }

    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget){
        Q_UNUSED(widget)
        Q_UNUSED(option)

        // gaaanz wichtig: erstmal painter an boundingRect clippen!!!:
        QRectF rct = boundingRect();

        painter->setRenderHint(QPainter::Antialiasing, true);

        painter->setClipRect(rct);

        QLinearGradient gradient(rct.topLeft(), rct.bottomRight());
        gradient.setColorAt(0, QColor(255,255,255, 200));
        gradient.setColorAt(1, QColor(220,220,255, 200));
        painter->fillRect(rct, gradient);

        if(m_anzRects == 1){
            if(!rects[0]){
                float fctr = 0.8;
                float wndwWdth = (float)rct.width()*fctr;
                float xStart = rct.x() + (rct.width()-wndwWdth)*0.5;
                float yStart = rct.y() + (rct.height()-wndwWdth)*0.5;
                QRect* wndwRct = new QRect(xStart,yStart, wndwWdth,wndwWdth);

                rects[0] = wndwRct;
            }
        }else if(m_anzRects == 2){
            float fctr = 0.9;
            float rctWidth = ((float)rct.width()) *0.4;
            float offs = ((float)rct.width())*(1.0-fctr)*0.5;

            if(horizontal){
                painter->drawLine(rct.left()+offs,
                                  rct.center().y(),
                                  rct.right()-offs,
                                  rct.center().y());
                if(!rects[0]){
                    QSize size(rctWidth, rctWidth);
                    QPoint p1, p2;
                    p1 = QPoint(rct.center().x()-rctWidth*0.5,
                              rct.top()+offs);
                    p2 = QPoint(rct.center().x()-rctWidth*0.5,
                              rct.bottom()-offs-rctWidth);
                    rects[0] = new QRect(p1, size);
                    rects[1] = new QRect(p2, size);
                }
            }else{
                painter->drawLine(rct.center().x(),
                                  rct.top()+offs,
                                  rct.center().x(),
                                  rct.bottom()-offs);

                if(!rects[0]){
                    QSize size(rctWidth, rctWidth);
                    QPoint p1, p2;
                    p1 = QPoint(rct.left()+offs,
                              rct.center().y()-rctWidth*0.5);
                    p2 = QPoint(rct.right()-offs-rctWidth,
                              rct.center().y()-rctWidth*0.5);
                    rects[0] = new QRect(p1, size);
                    rects[1] = new QRect(p2, size);
                }
            }  
        }else if(m_anzRects == 3){
            float fctr = 0.9;
            float rctWidth = ((float)rct.width()) *0.4;
            float offs = ((float)rct.width())*(1.0-fctr)*0.5;
            if(horizontal){
                painter->drawLine(rct.left()+offs,
                                  rct.center().y(),
                                  rct.right()-offs,
                                  rct.center().y());
                painter->drawLine(rct.center().x(),
                                  rct.center().y(),
                                  rct.center().x(),
                                  rct.bottom()-offs);

                if(!rects[0]){
                    QSize size(rctWidth, rctWidth);
                    QPoint p1, p2, p3;
                    p1 = QPoint(rct.center().x()-rctWidth*0.5,
                              rct.top()+offs);
                    p2 = QPoint(rct.left()+offs,
                              rct.bottom()-offs-rctWidth);
                    p3 = QPoint(rct.right()-offs-rctWidth,
                              rct.bottom()-offs-rctWidth);

                    rects[0] = new QRect(p1, size);
                    rects[1] = new QRect(p2, size);
                    rects[2] = new QRect(p3, size);
                }
            }else{
                painter->drawLine(rct.center().x(),
                                  rct.top()+offs,
                                  rct.center().x(),
                                  rct.bottom()-offs);
                painter->drawLine(rct.center().x(),
                                  rct.center().y(),
                                  rct.right()-offs,
                                  rct.center().y());
                if(!rects[0]){
                    QSize size(rctWidth, rctWidth);
                    QPoint p1, p2, p3;
                    p1 = QPoint(rct.left()+offs,
                              rct.center().y()-rctWidth*0.5);
                    p2 = QPoint(rct.right()-offs-rctWidth,
                              rct.top()+offs);
                    p3 = QPoint(rct.right()-offs-rctWidth,
                              rct.bottom()-offs-rctWidth);

                    rects[0] = new QRect(p1, size);
                    rects[1] = new QRect(p2, size);
                    rects[2] = new QRect(p3, size);
                }
            }
        }else{ // == 4
            float fctr = 0.9;
            float rctWidth = ((float)rct.width()) *0.4;
            float offs = ((float)rct.width())*(1.0-fctr)*0.5;

            painter->drawLine(rct.left()+offs,
                              rct.center().y(),
                              rct.right()-offs,
                              rct.center().y());
            painter->drawLine(rct.center().x(),
                              rct.top()+offs,
                              rct.center().x(),
                              rct.bottom()-offs);
            if(!rects[0]){
                    QSize size(rctWidth, rctWidth);
                    QPoint p1, p2, p3, p4;
                    p1 = QPoint(rct.left()+offs,
                              rct.top()+offs);
                    p2 = QPoint(rct.right()-offs-rctWidth,
                              rct.top()+offs);
                    p3 = QPoint(rct.left()+offs,
                              rct.bottom()-offs-rctWidth);
                    p4 = QPoint(rct.right()-offs-rctWidth,
                              rct.bottom()-offs-rctWidth);
                rects[0] = new QRect(p1, size);
                rects[1] = new QRect(p2, size);
                rects[2] = new QRect(p3, size);
                rects[3] = new QRect(p4, size);
            }
            painter->drawRect(*rects[0]);
            painter->drawRect(*rects[1]);
            painter->drawRect(*rects[2]);
            painter->drawRect(*rects[3]);
        }
        for(int i=0; i < m_anzRects; i++){
            StaticFunctions::paintRect(painter, *rects[i]);
        }
        if(mouseRectId > -1 && rects[mouseRectId]){
            StaticFunctions::paintCrossRect(painter, *rects[mouseRectId]);
        }
    }
protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event){
        QPointF mouP = event->pos();
        for(int i=0; i < m_anzRects; i++){
            if(rects[i] && caller
                    && rects[i]->contains(QPoint(mouP.x(), mouP.y()))){
                caller(i);
            }
        }
        qint64 curTime = QDateTime::currentMSecsSinceEpoch();
        if(curTime - lastTmePrsd < 300){

        }
        lastTmePrsd = curTime;
        isPressed = true;
        update();
    }
    void hoverMoveEvent(QGraphicsSceneHoverEvent * event){
        m_hover = true;
        QPointF mouP = event->pos();
        mouseRectId = -1;
        for(int i=0; i < m_anzRects; i++){
            if(rects[i] && rects[i]->contains(QPoint(mouP.x(), mouP.y()))){
                mouseRectId = i;
                break;
            }
        }
        update();
        return QGraphicsItem::hoverEnterEvent(event);
    }
private:
    bool m_hover = false;

    bool horizontal = true;

    int m_anzRects = 2;

    bool isPressed = false;
    qint64 lastTmePrsd = Q_INT64_C(0);

    QVector<QRect*> rects;
    int mouseRectId = -1;

    std::function<void(int)> caller;
};

GraphicsView::GraphicsView(std::weak_ptr<FileInfoBD> fileInfoBD,
        QWidget *parent)
    : QGraphicsView(parent),
      m_fileInfoBD(fileInfoBD),
      m_isLoading(false),
      m_loadingId(0),
      m_animationTimer(new QTimer(this))
{
    qDebug() << "in GraphcisView-Constructor";

    revalidateRowHeight();

    connect(m_animationTimer, &QTimer::timeout, [=](){
//        qDebug() << "running in timer: loadingId: " << loadingId;
        int id = m_loadingId;
        m_loadingId = (id+1) % m_loadingLength;

        QString cursor_pixmap_path = QString("%1%2%3")
                .arg("pics")
                .arg(QDir::separator())
                .arg("MrSoir_antique_blank.png");
        QPixmap cursor_pixmap = QPixmap(cursor_pixmap_path);

        QTransform trans;
        qreal id_rl = (qreal)id;
        qreal pi = 3.14159265;
        qreal value = (id_rl / ((qreal)m_loadingLength)) * (2*pi);
        qreal scaleFactor = (sin(value) +1) * 0.3;

        trans.rotate(id * 4);
        trans.scale(1.0 + scaleFactor, 1.0 + scaleFactor);

        cursor_pixmap = cursor_pixmap.transformed(trans);
        setCursor(QCursor(cursor_pixmap,
                          (int)(-((qreal)cursor_pixmap.size().width())*0.5),
                          (int)(-((qreal)cursor_pixmap.size().height())*0.5)));

        rePaintCanvas();
    });


    // wichtig: damit die scene immer ganz oben beginnt!
    this->setAlignment(Qt::AlignTop);

//    this->setContentsMargins(0, 0, 0, 0);

    this->setScene(&m_scene);

    this->verticalScrollBar();
    connect(this->verticalScrollBar(), &QScrollBar::valueChanged,
            [=](){
        vScrollValueChanged();
    });
    connect(this->horizontalScrollBar(), &QScrollBar::valueChanged,
            [=](){
        hScrollValueChanged();
    });
    rePaintCanvas();

    qDebug() << "in GraphcisView-finished";
}

GraphicsView::~GraphicsView()
{
    if(m_mouseP)
        delete m_mouseP;
//    if(winSelctr)
//        delete winSelctr;
    m_fileInfoBD.reset();
}

void GraphicsView::revalidate(){
    rePaintCanvas();
}

int GraphicsView::getFirstToDispFi(){
    qreal yOffs = getViewportYOffset();

    int firstToDispFi = (yOffs / m_rowHeight) -m_filePuffer;
    if(firstToDispFi < 0)
        firstToDispFi = 0;
    return firstToDispFi;
}
int GraphicsView::getLastToDispFi(){
    qreal vwPrtHght = getDisplayableHeight();

    int lastToDispFi = getFirstToDispFi() + (vwPrtHght / m_rowHeight) + m_filePuffer*2.0;
    if(lastToDispFi >= m_fileCount)
        lastToDispFi = m_fileCount-1;
    return lastToDispFi;
}
bool GraphicsView::viewPortOutOfDisplayedRange(){
    int newFirstToDispFi = getFirstToDispFi();
    int newLastToDispFi = getLastToDispFi();
    int curFirst = m_firstDispFI;
    int curLast =  m_lastDispFI;

    if(curFirst < 0)
        curFirst = 0;
    if(curLast >= m_fileCount)
        curLast  = m_fileCount-1;

    qDebug() << "newFirstToDispFi: " << newFirstToDispFi
             << "    m_firstDispFI: " << m_firstDispFI
             << "   newLastToDispFi: " << newLastToDispFi
             << "   curLast: " << curLast
             << "   viewPortOutOfDisplayedRange: " <<
                (newFirstToDispFi < curFirst ||
                 newLastToDispFi  > curLast);
    return newFirstToDispFi < curFirst ||
            newLastToDispFi  > curLast;
}

qreal GraphicsView::getDisplayableHeight()
{
    return this->viewport()->height()-m_elapseBarHeight;
}

void GraphicsView::vScrollValueChanged()
{
    qDebug() << "in vScrollValueChanged -> viewPortOutOfDisplayedRange: " << viewPortOutOfDisplayedRange();

//    if(auto locked = m_filesCoord.lock()){
//        locked->saveGraphicsViewVBarValue(this->verticalScrollBar()->value());
//    }
    bool revalidate = false;
    if( viewPortOutOfDisplayedRange() ){
        revalidate = true;
    }
    if(!revalidate && m_graphicsGroup){
        m_graphicsGroup->setY(this->verticalScrollBar()->value());
    }
    if(revalidate)
        rePaintCanvas();
}

void GraphicsView::hScrollValueChanged()
{
//    if(auto locked = m_filesCoord.lock()){
//        locked->saveGraphicsViewHBarValue(this->horizontalScrollBar()->value());
//    }
    if(m_graphicsGroup){
        m_graphicsGroup->setX(this->horizontalScrollBar()->value());
    }
}

void GraphicsView::setWaitingAnimation()
{
//    qDebug() << "wait: " << wait;
    if(m_animationTimer && m_animationTimer->isActive()){
        m_isLoading = false;
        qDebug() << "stopping timer";
        this->setCursor(QCursor(Qt::ArrowCursor));
        m_animationTimer->stop();
    }else{
        qDebug() << "starting timer";
        m_isLoading = true;
        m_animationTimer->start(m_loadingPeriodMS);
    }
}

void GraphicsView::closeAllSubMenus(){
    m_paintSearchMenu = false;
    m_paintMenuBar = false;
    m_paintContBar = false;

    closeSearchMenu();
}

void GraphicsView::keyPressEvent(QKeyEvent *event)
{
    if(event->key() == Qt::Key_Escape){
        if(m_paintSearchMenu || m_paintMenuBar || m_paintContBar){
            closeAllSubMenus();
            update();
        }else{
            if(auto lockedFilesCoord = m_filesCoord.lock()){
                lockedFilesCoord->clearContent();
            }
        }
    }else if(event->key() == 16777220){ // 16777220 == Enter, Key_Enter klappt nicht, aus welchem Grund auch immer...
        if(auto lockedFilesCoord = m_filesCoord.lock()){
            if(m_paintSearchMenu){
                lockedFilesCoord->nextSearchResult();
            }else{
                lockedFilesCoord->openSelection();
            }
        }
    }else if(event->key() == Qt::Key_Backspace){
        if(auto lockedFilesCoord = m_filesCoord.lock()){
            lockedFilesCoord->setParentToRoot();
        }
    }else if(event->key() == Qt::Key_Up){
        if(auto lockedFilesCoord = m_filesCoord.lock()){
            lockedFilesCoord->selectButtonUp(m_ctrl_prsd, m_shft_prsd);
        }
    }else if(event->key() == Qt::Key_Down){
        if(auto lockedFilesCoord = m_filesCoord.lock()){
            lockedFilesCoord->selectButtonDown(m_ctrl_prsd, m_shft_prsd);
        }
    }else if(event->key() == Qt::Key_Control){
        m_ctrl_prsd = true;
    }else if(event->key() == Qt::Key_Shift){
        m_shft_prsd = true;
    }else if(event->key() == Qt::Key_F5){
        if(auto locked = m_filesCoord.lock()){
            locked->forceRevalidation();
        }
    }else if(event->key() == Qt::Key_Alt ||
             event->key() == Qt::Key_AltGr){
        m_alt_prsd = true;
    }else if(event->key() == Qt::Key_A){
        if(m_ctrl_prsd){
            if(auto locked = m_filesCoord.lock()){
                locked->selectEntireContent();
            }
        }
    }else if(event->key() == Qt::Key_C){
        if(m_ctrl_prsd){
            if(auto locked = m_filesCoord.lock()){
                locked->copySelectedContent();
            }
        }
    }else if(event->key() == Qt::Key_X){
        if(m_ctrl_prsd){
            if(auto locked = m_filesCoord.lock()){
                locked->cutSelectedContent();
            }
        }
    }else if(event->key() == Qt::Key_V){
        if(m_ctrl_prsd){
            if(auto locked = m_filesCoord.lock()){
                locked->pasteFromClipboard();
            }
        }
    }else if(event->key() == Qt::Key_F){
        if(m_ctrl_prsd){
            launchSearchMode();
        }
    }else if(event->key() == Qt::Key_N){
        if(m_ctrl_prsd){
            m_ctrl_prsd = false;
            createNewFolder();
        }
    }else if(event->key() == Qt::Key_M){
        if(m_ctrl_prsd){
            m_ctrl_prsd = false;
            createNewFile();
        }
    }else if(event->key() == Qt::Key_Delete){
        if(auto locked = m_filesCoord.lock()){
            locked->deleteSelectedContent();
        }
    }

    this->rePaintCanvas();
}

void GraphicsView::keyReleaseEvent(QKeyEvent *event)
{
    if(event->key() == Qt::Key_Control){
        m_ctrl_prsd = false;
    }else if(event->key() == Qt::Key_Shift){
        m_shft_prsd = false;
    }else if(event->key() == Qt::Key_Alt ||
             event->key() == Qt::Key_AltGr){
        m_alt_prsd = false;
    }
    this->rePaintCanvas();
}

void GraphicsView::resizeEvent(QResizeEvent *event)
{
    rePaintCanvas();
    return QGraphicsView::resizeEvent(event);
}

void GraphicsView::mousePressEvent(QMouseEvent *event)
{
    return QGraphicsView::mousePressEvent(event);
}

void GraphicsView::mouseMoveEvent(QMouseEvent *event)
{
    if(m_mouseP)
        delete m_mouseP;
    m_mouseP = new QPoint(event->pos());

    int upperRectBound = 70;

    QPoint scrAdjMouP = QPoint(m_mouseP->x() + this->horizontalScrollBar()->value(),
                               m_mouseP->y() + this->verticalScrollBar()->value());

    if(!m_paintMenuBar && !m_paintSearchMenu && m_upperRect &&
            m_upperRect->contains(scrAdjMouP)){
        qDebug() << "in upperTriangle";
        m_paintUpperRect = false;
        m_paintSearchMenu = false;
        m_paintMenuBar = true;
        rePaintCanvas();
    }else if(!m_paintMenuBar){
        if (m_paintUpperRect && m_mouseP->y() > upperRectBound){
            m_paintUpperRect = false;
            rePaintCanvas();
        }else if (!m_paintUpperRect && m_mouseP->y() <= upperRectBound){
            m_paintUpperRect = true;
            rePaintCanvas();
        }
    }
    return QGraphicsView::mouseMoveEvent(event);
}


void GraphicsView::setRoot(std::weak_ptr<FileInfoBD> fi)
{
    qDebug() << "in setRoot -> connecting fileInfoBD's!";
    if(std::shared_ptr<FileInfoBD> fiLock = fi.lock()){
        m_fileInfoBD = fiLock;
        rePaintCanvas();
    }
}

void GraphicsView::updateGraphicsView()
{
    this->viewport()->update();
}

void GraphicsView::setFilesCoordinator(std::weak_ptr<FilesCoordinator> filesCoor)
{
    m_filesCoord = filesCoor;
    if (auto filesLocked = m_filesCoord.lock()){
        m_paintContBar = filesLocked->contentSelected();
    }
}

int GraphicsView::getVScrollBarValue()
{
    return this->verticalScrollBar()->value();
}

int GraphicsView::getHScrollBarValue()
{
    return this->horizontalScrollBar()->value();
}

void GraphicsView::focusId(int id, bool repaintAnyway)
{
    qreal yStart = this->verticalScrollBar()->value();
    int startId = yStart / m_rowHeight;
    int endId = startId +
            (this->viewport()->height()-m_elapseBarHeight) / m_rowHeight-1;
    if(endId < startId)
        endId = startId;

//    qDebug() << "in GraphicsView.focusId:"
//             << "   startId: " << startId
//             << "   endId: " << endId
//             << "   tarId: " << id;

    bool repaintingIsNecessary = false;
    if(startId > id){
        qreal newVScrBrVal = id * m_rowHeight - m_elapseBarHeight + m_rowHeight;
        if(newVScrBrVal < 0)
            newVScrBrVal = 0;
        this->verticalScrollBar()->setValue(newVScrBrVal);
        repaintingIsNecessary = true;
    }else if(endId < id){
        qreal newVScrBrVal = id * m_rowHeight - m_elapseBarHeight
                - (this->viewport()->height()-m_elapseBarHeight) + m_rowHeight*2;
        if(newVScrBrVal < 0)
            newVScrBrVal = 0;
        this->verticalScrollBar()->setValue(newVScrBrVal);
        repaintingIsNecessary = true;
    }
    if(repaintingIsNecessary || repaintAnyway){
        this->rePaintCanvas();
    }
}

void GraphicsView::setHBarValue(int hBarValue)
{
    this->horizontalScrollBar()->setValue(hBarValue);
    update();
}

void GraphicsView::setVBarValue(int vBarValue)
{
    this->verticalScrollBar()->setValue(vBarValue);
    update();
}

void GraphicsView::folderChanged(std::weak_ptr<const FileInfoBD> f)
{
    Q_UNUSED(f);
    rePaintCanvas();
}

void GraphicsView::paintTopRectangle(const QPointF& center, const QSize& size){
    const QSizeF halfSize(((float)size.width())*0.5, ((float)size.height())*0.5);

    QPointF p1(-halfSize.width(), -halfSize.height());
    QPointF p2(+halfSize.width(), -halfSize.height());
    QPointF p3(0, +halfSize.height());
    p1 += center;
    p2 += center;
    p3 += center;

    if(m_upperRect){
//        delete upperRect; // bleibt als hinweis, dass die raw-pointer-scheisse von qt derbe nervt
        m_upperRect = nullptr;
    }
    m_upperRect = new QPainterPath();
    m_upperRect->moveTo(p1);
    m_upperRect->lineTo(p2);
    m_upperRect->lineTo(p3);
    m_upperRect->closeSubpath();

    QGraphicsPathItem* painterPthItm = new QGraphicsPathItem();
    painterPthItm->setBrush(QBrush(StaticFunctions::getGoshBlueColor()));
    painterPthItm->setPen(QPen(QColor(0,0,0,100), 1, Qt::SolidLine));
    painterPthItm->setPath(*m_upperRect);

    m_graphicsGroup->addToGroup(painterPthItm);
}
void GraphicsView::addMenuBar(){
    if(m_menuBar){
        m_menuBar = nullptr;
    }

    m_menuBar = new MenuBar(this->viewport()->width(),
                            QPointF(this->viewport()->width()*0.5, m_elapseBarHeight));
    m_menuBar->setPosition(QPoint(this->horizontalScrollBar()->value(),
                                   this->verticalScrollBar()->value()));

    auto menu_caller = std::make_shared<DynamicFunctionCaller<QString,std::function<void()>>>();
    auto searchModeFunc     = [=](){ launchSearchMode(); };
    auto zoomInFunc         = [=](){ zoomIn(); };
    auto zoomOutFunc        = [=](){ zoomOut(); };
    auto sortFunc           = [=](){ sortAllFolders(); };
    auto newFolderFunc      = [=](){ createNewFolder(); };
    auto newFileFunc        = [=](){ createNewFile(); };
    auto closeMenuBarFunc   = [=](){ closeMenuBar(); };

    menu_caller->setFunction(QString("buttonFunction0"), searchModeFunc);
    menu_caller->setFunction(QString("buttonFunction1"), zoomInFunc);
    menu_caller->setFunction(QString("buttonFunction2"), zoomOutFunc);
    menu_caller->setFunction(QString("buttonFunction3"), sortFunc);
    menu_caller->setFunction(QString("buttonFunction4"), newFolderFunc);
    menu_caller->setFunction(QString("buttonFunction5"), newFileFunc);
    menu_caller->setFunction(QString("buttonFunction6"), closeMenuBarFunc);

    auto painting_caller = std::make_shared<DynamicFunctionCaller<QString,std::function<void(QPainter*,QRectF)>>>();
    auto paintSearchModeFunc     = [=](QPainter* painter, QRectF rct){ StaticFunctions::paintLoupe(painter, rct, StaticFunctions::SHAPE::NONE); };
    auto paintZoomInFunc         = [=](QPainter* painter, QRectF rct){ StaticFunctions::paintLoupe(painter, rct, StaticFunctions::SHAPE::PLUS); };
    auto paintZoomOutFunc        = [=](QPainter* painter, QRectF rct){ StaticFunctions::paintLoupe(painter, rct, StaticFunctions::SHAPE::MINUS); };
    auto paintSortFunc           = [=](QPainter* painter, QRectF rct){
        QString cursor_pixmap_path = QString("%1%2%3").arg("pics").arg(QDir::separator()).arg("sort_icon.png");
        StaticFunctions::paintPixmapRect(painter, QPixmap(cursor_pixmap_path), rct ,Qt::transparent,Qt::transparent,Qt::transparent); };
    auto paintNewFoldFunc           = [=](QPainter* painter, QRectF rct){
        QString cursor_pixmap_path = QString("%1%2%3").arg("pics").arg(QDir::separator()).arg("empty_fold_icon.png");
        StaticFunctions::paintPixmapRect(painter, QPixmap(cursor_pixmap_path), rct ,Qt::transparent,Qt::transparent,Qt::transparent); };
    auto paintNewFileFunc           = [=](QPainter* painter, QRectF rct){
        QString cursor_pixmap_path = QString("%1%2%3").arg("pics").arg(QDir::separator()).arg("empty_file_icon.png");
        StaticFunctions::paintPixmapRect(painter, QPixmap(cursor_pixmap_path), rct ,Qt::transparent,Qt::transparent,Qt::transparent); };
    auto paintCloseMenuBarFunc   = [=](QPainter* painter, QRectF rct){ StaticFunctions::paintCrossRect(painter, rct); };

    painting_caller->setFunction(QString("paintingFunction0"), paintSearchModeFunc);
    painting_caller->setFunction(QString("paintingFunction1"), paintZoomInFunc);
    painting_caller->setFunction(QString("paintingFunction2"), paintZoomOutFunc);
    painting_caller->setFunction(QString("paintingFunction3"), paintSortFunc);
    painting_caller->setFunction(QString("paintingFunction4"), paintNewFoldFunc);
    painting_caller->setFunction(QString("paintingFunction5"), paintNewFileFunc);
    painting_caller->setFunction(QString("paintingFunction6"), paintCloseMenuBarFunc);

    m_menuBar->setCaller(menu_caller, painting_caller);

    m_graphicsGroup->addToGroup(m_menuBar);
}

void GraphicsView::closeMenuBar()
{
    m_paintMenuBar = false;
    QTimer::singleShot(10,[=](){
        rePaintCanvas();
    });
}

void GraphicsView::addElapseBar()
{
    if(auto locked = m_filesCoord.lock()){
        ElapseMenuBD* elapseMenu = new ElapseMenuBD(locked->getMaxDepth()+1,
                                                   m_colOffs*2,
                                                   QSize(this->viewport()->width(),m_elapseBarHeight),
                                                   QPoint(0,0)
                                                 );
        elapseMenu->setPosition(QPoint(this->horizontalScrollBar()->value(), this->verticalScrollBar()->value()));

        auto button_caller = std::make_shared<DynamicFunctionCaller<QString,std::function<bool(int)>>>();
        auto buttonClickFunc = [=](int i){
            if(auto locked = m_filesCoord.lock()){
                locked->elapseAllFoldersOfDepthId(i);
            }
            return false;
        };
        auto elapsedFunc = [=](int depthId){
            if(auto locked = m_filesCoord.lock()){
                return locked->depthIdElapsed(depthId);
            }
            return false;
        };

        button_caller->setFunction(QString("call"), buttonClickFunc);
        button_caller->setFunction(QString("elapsed"), elapsedFunc);

        elapseMenu->setCaller(button_caller);

        m_graphicsGroup->addToGroup(elapseMenu);
    }
}

void GraphicsView::addContentBar()
{
    qreal fctr = 0.75;
    m_contBar = new MenuBar(getDisplayableHeight()*fctr,
                            QPointF(this->viewport()->width(),
                                    m_elapseBarHeight+getDisplayableHeight()*0.5),
                            ORIENTATION::VERTICAL,
                            true);
    m_contBar->setPosition(QPoint(this->horizontalScrollBar()->value(), this->verticalScrollBar()->value()));

    auto menu_caller = std::make_shared<DynamicFunctionCaller<QString,std::function<void()>>>();
    auto painting_caller = std::make_shared<DynamicFunctionCaller<QString,std::function<void(QPainter*,QRectF)>>>();


    int fontWeight = QFont::Bold;
    int fontSize = 6;

    int funcId = 0;
    if(std::shared_ptr<FilesCoordinator> lockedFilesCoord = m_filesCoord.lock()){
        if(lockedFilesCoord->foldersSelected()){
            if(lockedFilesCoord->singleFolderSelected()){

                // set root:

                auto setRootFunc = [=](){
                    lockedFilesCoord->setSelectionToRoot();
                };
                menu_caller->setFunction(QString("buttonFunction%1").arg(funcId), setRootFunc);
                auto paintRootSelFunc = [=](QPainter* painter, QRectF rct){
                    StaticFunctions::paintTextRect(painter, QString("load"), rct, Qt::transparent,Qt::transparent,
                                                   QColor(0,0,0),StaticFunctions::getGoshFont(fontSize, fontWeight));
                };
                painting_caller->setFunction(QString("paintingFunction%1").arg(funcId), paintRootSelFunc);
                ++funcId;
            }

            // elapse folders:

            auto setElapseFunc = [=](){
                lockedFilesCoord->elapseSelectedFolders();
            };
            menu_caller->setFunction(QString("buttonFunction%1").arg(funcId), setElapseFunc);
            auto paintElapseFunc = [=](QPainter* painter, QRectF rct){
                StaticFunctions::paintTextRect(painter, QString("elapse"), rct, Qt::transparent,Qt::transparent,
                                               QColor(0,0,0),StaticFunctions::getGoshFont(fontSize, fontWeight));
            };
            painting_caller->setFunction(QString("paintingFunction%1").arg(funcId), paintElapseFunc);
            ++funcId;

            auto setCollapseFunc = [=](){
                lockedFilesCoord->collapseSelectedFolders();
            };
            menu_caller->setFunction(QString("buttonFunction%1").arg(funcId), setCollapseFunc);
            auto paintCollapseFunc = [=](QPainter* painter, QRectF rct){
                StaticFunctions::paintTextRect(painter, QString("collapse"), rct, Qt::transparent,Qt::transparent,
                                               QColor(0,0,0),StaticFunctions::getGoshFont(fontSize, fontWeight));
            };
            painting_caller->setFunction(QString("paintingFunction%1").arg(funcId), paintCollapseFunc);
            ++funcId;
        }
        if(lockedFilesCoord->singleContentSelected()){

            // rename file/folder:

            auto renameFunc = [=](){
                lockedFilesCoord->renameSelectedContent();
            };
            menu_caller->setFunction(QString("buttonFunction%1").arg(funcId), renameFunc);
            auto paintRenameFunc = [=](QPainter* painter, QRectF rct){
                StaticFunctions::paintTextRect(painter, QString("rename"), rct, Qt::transparent,Qt::transparent,
                                               QColor(0,0,0),StaticFunctions::getGoshFont(fontSize, fontWeight));
            };
            painting_caller->setFunction(QString("paintingFunction%1").arg(funcId), paintRenameFunc);
            ++funcId;
        }
        if(lockedFilesCoord->selectionCounter() > 0){

            // copy files/folders:

            std::function<void()> setFunc = [=](){
                lockedFilesCoord->copySelectedContent();
            };
            menu_caller->setFunction(QString("buttonFunction%1").arg(funcId), setFunc);
            std::function<void(QPainter*,QRectF)> paintElapseFunc = [=](QPainter* painter, QRectF rct){
                StaticFunctions::paintTextRect(painter, QString("copy"), rct, Qt::transparent,Qt::transparent,
                                               QColor(0,0,0),StaticFunctions::getGoshFont(fontSize, fontWeight));
            };
            painting_caller->setFunction(QString("paintingFunction%1").arg(funcId), paintElapseFunc);
            ++funcId;

            // duplicate files/folders:

            setFunc = [=](){
                lockedFilesCoord->duplicateSelectedContent();
            };
            menu_caller->setFunction(QString("buttonFunction%1").arg(funcId), setFunc);
            paintElapseFunc = [=](QPainter* painter, QRectF rct){
                StaticFunctions::paintTextRect(painter, QString("duplicate"), rct, Qt::transparent,Qt::transparent,
                                               QColor(0,0,0),StaticFunctions::getGoshFont(fontSize, fontWeight));
            };
            painting_caller->setFunction(QString("paintingFunction%1").arg(funcId), paintElapseFunc);
            ++funcId;

            // cut files/folders:
            setFunc = [=](){
                lockedFilesCoord->cutSelectedContent();
            };
            menu_caller->setFunction(QString("buttonFunction%1").arg(funcId), setFunc);
            paintElapseFunc = [=](QPainter* painter, QRectF rct){
                StaticFunctions::paintTextRect(painter, QString("cut"), rct, Qt::transparent,Qt::transparent,
                                               QColor(0,0,0),StaticFunctions::getGoshFont(fontSize, fontWeight));
            };
            painting_caller->setFunction(QString("paintingFunction%1").arg(funcId), paintElapseFunc);
            ++funcId;

            // paste files/folders:

            setFunc = [=](){
                lockedFilesCoord->pasteFromClipboard();
            };
            menu_caller->setFunction(QString("buttonFunction%1").arg(funcId), setFunc);
            paintElapseFunc = [=](QPainter* painter, QRectF rct){
                StaticFunctions::paintTextRect(painter, QString("paste"), rct, Qt::transparent,Qt::transparent,
                                               QColor(0,0,0),StaticFunctions::getGoshFont(fontSize, fontWeight));
            };
            painting_caller->setFunction(QString("paintingFunction%1").arg(funcId), paintElapseFunc);
            ++funcId;

            // delete files/folders:

            setFunc = [=](){
                lockedFilesCoord->deleteSelectedContent();
            };
            menu_caller->setFunction(QString("buttonFunction%1").arg(funcId), setFunc);
            paintElapseFunc = [=](QPainter* painter, QRectF rct){
                StaticFunctions::paintTextRect(painter, QString("delete"), rct, Qt::transparent,Qt::transparent,
                                               QColor(0,0,0),StaticFunctions::getGoshFont(fontSize, fontWeight));
            };
            painting_caller->setFunction(QString("paintingFunction%1").arg(funcId), paintElapseFunc);
            ++funcId;

            // open files/folders:

            setFunc = [=](){
                lockedFilesCoord->openSelectedContent();
            };
            menu_caller->setFunction(QString("buttonFunction%1").arg(funcId), setFunc);
            paintElapseFunc = [=](QPainter* painter, QRectF rct){
                StaticFunctions::paintTextRect(painter, QString("open"), rct, Qt::transparent,Qt::transparent,
                                               QColor(0,0,0),StaticFunctions::getGoshFont(fontSize, fontWeight));
            };
            painting_caller->setFunction(QString("paintingFunction%1").arg(funcId), paintElapseFunc);
            ++funcId;

            // show details/folders:

            setFunc = [=](){
                lockedFilesCoord->showDetailsOfSelectedContent();
            };
            menu_caller->setFunction(QString("buttonFunction%1").arg(funcId), setFunc);
            paintElapseFunc = [=](QPainter* painter, QRectF rct){
                StaticFunctions::paintTextRect(painter, QString("details"), rct, Qt::transparent,Qt::transparent,
                                               QColor(0,0,0),StaticFunctions::getGoshFont(fontSize, fontWeight));
            };
            painting_caller->setFunction(QString("paintingFunction%1").arg(funcId), paintElapseFunc);
            ++funcId;
        }
    }

    m_contBar->setCaller(menu_caller, painting_caller);

    m_graphicsGroup->addToGroup(m_contBar);
}

void GraphicsView::closeContentBar()
{
    m_paintContBar = false;
    QTimer::singleShot(10,[=](){
        rePaintCanvas();
    });
}
void GraphicsView::addSearchMenu(){
    if(m_searchMenu){
//        delete m_searchMenu;
        m_searchMenu = nullptr;
    }

    QSize menuSize(this->viewport()->width(), m_searchMenuHeight);
    if(!m_searchMenu)
        m_searchMenu = new SearchMenuBD(menuSize);
    else
        m_searchMenu->setSize(menuSize);

    m_searchMenu->setPosition(QPoint(this->horizontalScrollBar()->value(),
                                     this->verticalScrollBar()->value() + m_elapseBarHeight));


    auto menu_caller = std::make_shared<DynamicFunctionCaller<QString,std::function<QString()>>>();
    auto nextPrevCaller = [=](){nextSearchResult();return QString("");};
    auto prevPrevCaller = [=](){prevSearchResult();return QString("");};
    auto closePrevCaller = [=](){closeSearchMenu();return QString("");};
    auto getNextSearchText = [=](){ return getCurrentSearchResult(); };
    menu_caller->setFunction(QString("next"), nextPrevCaller);
    menu_caller->setFunction(QString("previous"), prevPrevCaller);
    menu_caller->setFunction(QString("close"), closePrevCaller);
    menu_caller->setFunction(QString("getSearchResult"), getNextSearchText);
    m_searchMenu->setCaller(menu_caller);

    m_graphicsGroup->addToGroup(m_searchMenu);
}


void GraphicsView::rePaintCanvas(){
//    if(winSelctr){
////        delete winSelctr;
//        winSelctr = nullptr;
//    }

//    qDebug() << "repainting canvas";

    m_graphicsGroup = new QGraphicsItemGroup();
    m_graphicsGroup->setX(getAbsoluteHorBarValue());
    m_graphicsGroup->setY(getAbsoluteVerticalBarValue());
//    m_graphicsGroup->setAcceptHoverEvents(true);
    m_graphicsGroup->setHandlesChildEvents(false);

    m_scene.clear();

    if(auto fiCoordLocked = m_filesCoord.lock()){
//        m_fileCount = fiBDLock->getDispElmntCountRecurs();
        m_fileCount = fiCoordLocked->getDisplayedFileCount();

        int height = m_rowHeight*m_fileCount + m_elapseBarHeight;
        if(height < this->viewport()->height()){
            height = this->viewport()->height();
        }
        m_scene.setSceneRect(QRect(0,0,this->viewport()->width(), height));
    }else{
        m_scene.setSceneRect(QRect(0,0,this->viewport()->width(), this->viewport()->height()));
    }

    if( !m_fileInfoBD.expired() ){

        auto lckdFiCoord = m_filesCoord.lock();

        if(m_fileCount < m_fileMaxCount){
            m_firstDispFI = 0;
            m_lastDispFI = m_fileCount-1;
            m_curDispFI = m_fileCount-1;
        }else if (m_paintSearchMenu && lckdFiCoord){
            qreal idToFocus = lckdFiCoord->getIndexOfCurrentSearchResult();
            if(idToFocus > -1){
                qreal firstFiInVieport = idToFocus - (getDisplayableHeight()*0.5 / (qreal)m_rowHeight);
                m_firstDispFI = (int)(firstFiInVieport) - m_filePuffer;
                m_lastDispFI = (int)(firstFiInVieport) + m_filePuffer + (int)(getDisplayableHeight() / (qreal)m_rowHeight);
                if(m_firstDispFI < 0)
                    m_firstDispFI = 0;
                if(m_lastDispFI >= m_fileCount)
                    m_lastDispFI = m_fileCount-1;
            }else{
                m_firstDispFI = getFirstToDispFi();
                m_lastDispFI = getLastToDispFi();
            }
        }else{
            m_firstDispFI = getFirstToDispFi();
            m_lastDispFI = getLastToDispFi();
        }
//        qDebug() << "\nfileCount: " << m_fileCount
//                 << "   firstDispFI: " << m_firstDispFI
//                 << "   lastDispFI: " << m_lastDispFI
//                 << "\n";

        std::function<void(std::weak_ptr<FileInfoBD>,int,int)> dirFunc = [=](std::weak_ptr<FileInfoBD> fiBD, int a, int b){

            auto elapseFunc = [=](){
                if(auto locked = m_filesCoord.lock()){
                    locked->elapseFolder(fiBD);
                }
                return false;
            };
            auto isElapsedFunc = [=](){ if(auto fiBDLock = fiBD.lock()){return fiBDLock->elapsed();}return false; };
            auto isLoadedFunc = [=](){if(auto fiBDLock = fiBD.lock())return fiBDLock->isLoaded(); return false;};
            auto isDirFunc = [=](){ return true; };
            auto isEmptyFunc = [=](){ if(auto fiBDLock = fiBD.lock()){return fiBDLock->isEmpty();}return false; };
            auto selectFunc = [=](){
                if(auto lockedFilesCoord = m_filesCoord.lock()){
                    lockedFilesCoord->selectContent(FilInfoForOneDim(fiBD, true), m_ctrl_prsd, m_shft_prsd);
                    bool bckup = m_paintContBar;
                    m_paintContBar = lockedFilesCoord->contentSelected();
                    if(bckup != m_paintContBar){
                        update();        //void MyObject::startWorkInAThread()
                        //{
                        //    WorkerThread *workerThread = new WorkerThread(this);
                        //    connect(workerThread, &WorkerThread::resultReady, this, &MyObject::handleResults);
                        //    connect(workerThread, &WorkerThread::finished, workerThread, &QObject::deleteLater);
                        //    workerThread->start();
                        //}
                    }

                }
                return false;
            };
            auto isSelectedFunc = [=](){
                if(auto lockedFilesCoord = m_filesCoord.lock()){
                    return lockedFilesCoord->isSelected(FilInfoForOneDim(fiBD,true));
                }
                return false;
            };
            auto setSelectedFoldToRootFunc = [=](){
                if(auto lockedFilesCoord = m_filesCoord.lock()){
                    lockedFilesCoord->setSelectionToRoot();
                }
                return false;
            };
            auto isSearchedFunc = [=](){
                if(auto lckdFiCoord = m_filesCoord.lock()){
                    return lckdFiCoord->isCurentSearchResult(FilInfoForOneDim(fiBD));
                }
                return false;
            };

            auto caller = std::make_shared<DynamicFunctionCaller<QString, std::function<bool()>>>();
            caller->setFunction(QString("elapse"), elapseFunc);
            caller->setFunction(QString("isElapsed"), isElapsedFunc);
            caller->setFunction(QString("isLoaded"), isLoadedFunc);
            caller->setFunction(QString("isDir"), isDirFunc);
            caller->setFunction(QString("isEmpty"), isEmptyFunc);
            caller->setFunction(QString("select"), selectFunc);
            caller->setFunction(QString("isSelected"), isSelectedFunc);
            caller->setFunction(QString("setAsRoot"), setSelectedFoldToRootFunc);
            caller->setFunction(QString("isSearched"), isSearchedFunc);

            auto sortFunc = [=](ORDER_BY order){
                if(auto locked = m_filesCoord.lock()){
                    locked->sort(fiBD, order);
                }
                return false;
            };
            auto isRevSortFunc = [=](ORDER_BY order){
                if(auto locked = fiBD.lock()){
                    return locked->isReversedSortedBy(order);
                }
                return false;
            };
            auto isSortFunc = [=](ORDER_BY order){
                if(auto locked = fiBD.lock()){
                    return locked->isSortedBy(order);
                }
                return false;
            };

            auto sortCaller = std::make_shared<DynamicFunctionCaller<QString, std::function<bool(ORDER_BY)>>>();
            sortCaller->setFunction(QString("sortBy"), sortFunc);
            sortCaller->setFunction(QString("isReversedSortedBy"), isRevSortFunc);
            sortCaller->setFunction(QString("isSortedBy"), isSortFunc);


            if(std::shared_ptr<FileInfoBD> fiBDLock = fiBD.lock()){
                paintFileInfo(fiBDLock->getFileInfo(),a,b, caller, sortCaller);
            }
        };
        std::function<void(std::weak_ptr<FileInfoBD>, const QFileInfo&,int,int)> fileFunc =
                [=](std::weak_ptr<FileInfoBD> fiBD, const QFileInfo& fi, int a, int b){

            auto isDirFunc = [=](){ return false; };
            auto selectFunc = [=](){
                if(auto lockedFilesCoord = m_filesCoord.lock()){
                    lockedFilesCoord->selectContent(FilInfoForOneDim(fiBD, false, fi.fileName()), m_ctrl_prsd, m_shft_prsd);
                    bool bckup = m_paintContBar;
                    m_paintContBar = lockedFilesCoord->contentSelected();
                    if(bckup != m_paintContBar){
                        update();
                    }
                }
                return false;
            };
            auto isSelectedFunc = [=](){
                if(auto lockedFilesCoord = m_filesCoord.lock()){
                    return lockedFilesCoord->isSelected(FilInfoForOneDim(fiBD, false, fi.fileName()));
                }
                return false;
            };
            auto isSearchedFunc = [=](){
                if(auto lckdFiCoord = m_filesCoord.lock()){
                    return lckdFiCoord->isCurentSearchResult(FilInfoForOneDim(fiBD, false, fi.fileName()));
                }
                return false;
            };

            auto caller = std::make_shared<DynamicFunctionCaller<QString, std::function<bool()>>>();
            caller->setFunction(QString("isDir"), isDirFunc);
            caller->setFunction(QString("select"), selectFunc);
            caller->setFunction(QString("isSelected"), isSelectedFunc);
            caller->setFunction(QString("isSearched"), isSearchedFunc);

            paintFileInfo(fi, a,b, caller);
        };

//        iterateOverFileInfos(dirFunc, fileFunc, m_firstDispFI, m_lastDispFI);

        if(auto lockedFiCoord =  m_filesCoord.lock()){
            for(int i=m_firstDispFI; i <= m_lastDispFI; i++){
                FilInfoForOneDim curFileToDisp = lockedFiCoord->getDisplayedFileAt(i);
                if(curFileToDisp.m_isFolder){
                    dirFunc(curFileToDisp.m_fileInfoBD, i, curFileToDisp.m_depth);
                }else{
                    fileFunc(curFileToDisp.m_fileInfoBD, QFileInfo(curFileToDisp.getAbsoluteFilePath()),
                             i, curFileToDisp.m_depth);
                }
            }
        }
    }

    m_scene.addItem(m_graphicsGroup);
    m_graphicsGroup->setY(this->verticalScrollBar()->value());

    if(m_ctrl_prsd){
        // windowSelector wird nun zentral ueber den WindowCoordinator gesteuert
//        float fctr = 0.8;
//        float rctWidth = qMin((float)(this->width())*fctr, (float)(this->height())*fctr);
//        QSize size(rctWidth, rctWidth);
//        QPoint p(((float)(this->width())-rctWidth)*0.5, ((float)(this->height())-rctWidth)*0.5);
//        winSelctr = new WindowSelector(size, p);
//        m_graphicsGroup->addToGroup(winSelctr);
////        scene.addItem(winSelctr);
    }
    if(!m_paintSearchMenu && m_paintUpperRect){
        qreal trnglWidth = m_upperRectWidth;//qMin(trnglWidth, (qreal)20.);
        float trnglHeight = trnglWidth*0.5;
        QPointF center( ((float)this->viewport()->width())*0.5, trnglHeight*0.5+5. + getViewportYOffset()+m_elapseBarHeight);
        paintTopRectangle(center, QSize(trnglWidth,trnglHeight));
    }
    if(m_paintSearchMenu){
        addSearchMenu();
    }else if(m_paintMenuBar){
        addMenuBar();
    }
    if(m_paintContBar){
        addContentBar();
    }
    addElapseBar();

    if(m_shwRtSel){
        m_rotSlctr = new TextRect(QString("select root"),
                                            QSize(m_rootSelWidth,m_rootSelHeight),
                                            QPoint(0,0),
                                            QColor(100,100,100, 255),QColor(0,0,0, 255),
                                            QColor(255,0,0),QColor(255,0,0),
                                            QColor(255,255,255,255));
        m_rotSlctr->setCallFunction([=](){showRootSelector();});
        m_rotSlctr->setPosition(QPoint(this->viewport()->width()-m_rootSelWidth,
                                       getViewportYOffset()));
        m_graphicsGroup->addToGroup(m_rotSlctr);
//        scene.addItem(m_rotSlctr);
    }
}

void GraphicsView::iterateOverFileInfos(
        std::function<void (std::weak_ptr<FileInfoBD>,int,int)> dirFunc,
        std::function<void (std::weak_ptr<FileInfoBD>, const QFileInfo&,int,int)> fileFunc,
        int startId, int endId){
    int curId = 0;
    iterateOverFileInfos_helper(m_fileInfoBD, dirFunc, fileFunc, &curId,startId,endId, 0);
}

void GraphicsView::iterateOverFileInfos_helper(
        std::weak_ptr<FileInfoBD> fileInfoBD,
        std::function<void (std::weak_ptr<FileInfoBD>,int,int)> dirFunc,
        std::function<void (std::weak_ptr<FileInfoBD>, const QFileInfo&, int,int)> fileFunc,
        int* curId, int startId, int endId,
        int colId)
{
    if(startId <= *curId && *curId <= endId){
        dirFunc(fileInfoBD, *curId, colId);
    }
    ++(*curId);
    if(*curId > endId)
        return;
    if(std::shared_ptr<FileInfoBD> fiBDLock = fileInfoBD.lock()){
        if(fiBDLock->elapsed()){
            foreach(std::weak_ptr<FileInfoBD> fiBD, fiBDLock->getSubFolders()){
                iterateOverFileInfos_helper(fiBD,dirFunc,fileFunc,curId,startId,endId, colId+1);
                if(*curId > endId)
                    return;
            }
            int fileCount = fiBDLock->fileCount();
            if(*curId + fileCount < startId){
                *curId = *curId + fileCount;
                return;
            }else{
                int filesStartId = *curId < startId ? startId-*curId : 0;
                int filesEndId = *curId + fileCount-1 > endId ? endId-*curId : fileCount-1;
                if(*curId < startId)
                    *curId += startId-*curId;
                foreach(const QFileInfo fi, fiBDLock->getFiles(filesStartId, filesEndId)){
                    fileFunc(fileInfoBD, fi, *curId, colId+1);
                    ++(*curId);
                    if(*curId > endId){
                        return;
                    }
                }
            }
        }
    }
}

void GraphicsView::paintFileInfo(const QFileInfo& fi, int rowId, int colId,
                                 std::shared_ptr<DynamicFunctionCaller<QString, std::function<bool()>>> caller,
                                 std::shared_ptr<DynamicFunctionCaller<QString, std::function<bool(ORDER_BY)>>> sortCaller){
    int colOffs = 30;
    GraphicsFile* gf = new GraphicsFile(fi, QSize(this->viewport()->width(),m_rowHeight),
                                        rowId, m_rowHeight,
                                        colId, colOffs,
                                        caller,
                                        sortCaller,
                                        m_fontSize);
    gf->setDetailsTextColor(QColor(0,0,0, 150));
    gf->setDropFunction([=](QString dropStr){
        if(auto locked = m_filesCoord.lock()){
            locked->paste(dropStr, fi.absoluteFilePath());
        }
    });
    gf->setInitDraggingFunction([=](QString draggingSource){
        if(auto locked = m_filesCoord.lock()){
            locked->initDragging(draggingSource);
        }
    });
    gf->setPosition(QPoint(0, rowId*m_rowHeight + m_elapseBarHeight));
    m_scene.addItem(gf);
}

qreal GraphicsView::getRelativeHorBarValue()
{
    qreal val = this->horizontalScrollBar()->value();
    qreal max = this->horizontalScrollBar()->maximum();
    qreal min = this->horizontalScrollBar()->minimum();
    qreal retVal = val / (max-min);
    return retVal;
}
qreal GraphicsView::getRelativeVerBarValue()
{

    qreal val = this->verticalScrollBar()->value();
    qreal max = this->verticalScrollBar()->maximum();
    qreal min = this->verticalScrollBar()->minimum();
    qreal retVal = val / (max-min);
    return retVal;
}

int GraphicsView::getAbsoluteHorBarValue()
{
    return this->horizontalScrollBar()->value();
}

int GraphicsView::getAbsoluteVerticalBarValue()
{
    return this->verticalScrollBar()->value();
}

int GraphicsView::getViewportYOffset()
{
    return getAbsoluteVerticalBarValue();
}

void GraphicsView::launchSearchMode()
{
    bool ok;
    QString keyword = QInputDialog::getText(this, tr("QInputDialog::getText()"),
                                         tr("Looking for:"), QLineEdit::Normal,
                                         tr(""),&ok);

    if (ok && !keyword.isEmpty()){
        if(auto locked = m_filesCoord.lock()){
            locked->searchForKeyWord(keyword);
            if( !locked->searchResultsEmpty() ){
                qDebug() << "searchResultsFound: " << locked->searchResultsFound();
                m_searchMenu = new SearchMenuBD(QSize(this->viewport()->width(),
                                                      m_searchMenuHeight),
                                                QPoint(0,0),
                                                nullptr);
                m_paintSearchMenu = true;
                m_paintMenuBar = false;
                this->update();
            }
        }
    }
}

void GraphicsView::nextSearchResult()
{
    if( auto locked = m_filesCoord.lock() ){
        locked->nextSearchResult();
//        QTimer::singleShot(0,[=](){ rePaintCanvas(); });
    }
}

void GraphicsView::prevSearchResult()
{
    if( auto locked = m_filesCoord.lock() ){
        locked->previousSearchResult();
//        QTimer::singleShot(0,[=](){ rePaintCanvas(); });
    }
}

void GraphicsView::closeSearchMenu()
{
    if(auto locked = m_filesCoord.lock()){
        locked->clearSearchResults();
    }
    m_paintSearchMenu = false;
    QTimer::singleShot(0,[=](){ rePaintCanvas(); });
}

QString GraphicsView::getCurrentSearchResult()
{
    if(auto locked = m_filesCoord.lock()){
        return locked->getCurSearchResultStr();
    }
    return QString("");
}

void GraphicsView::zoomOut()
{
    if(m_fontSize > 5){
        --m_fontSize;
        revalidateRowHeight();
        QTimer::singleShot(0, [=](){rePaintCanvas();});
    }
}

void GraphicsView::zoomIn()
{
    if(m_fontSize < 20){
        ++m_fontSize;
        revalidateRowHeight();
        QTimer::singleShot(0, [=](){rePaintCanvas();});
    }
}

void GraphicsView::sortAllFolders()
{
    if(auto locked = m_filesCoord.lock()){

        QComboBox* comboBox = new QComboBox();
        comboBox->addItem(QString("Name"));
        comboBox->addItem(QString("Type"));
        comboBox->addItem(QString("Modification Date"));
        comboBox->addItem(QString("Size"));

        QCheckBox* revChckBx = new QCheckBox(QString("Reverse ordering"));
        QPushButton* okBtn = new QPushButton(QString("ok"));
        QPushButton* cancelBtn = new QPushButton(QString("cancel"));

        QHBoxLayout* hBox = new QHBoxLayout();
        hBox->addWidget(okBtn);
        hBox->addWidget(cancelBtn);

        QVBoxLayout* lay = new QVBoxLayout();
        lay->addWidget(new QLabel(QString("Sort by:")));
        lay->addWidget(comboBox);
        lay->addWidget(revChckBx);
        lay->addLayout(hBox);

        QDialog* dialog = new QDialog();
        dialog->setModal(true);
        dialog->setLayout(lay);
        dialog->setFixedSize(QSize(200,110));

        connect(okBtn, &QPushButton::clicked,
                [=](){
            ORDER_BY ord;
            if(comboBox->currentText() == QString("Name")){
                if(revChckBx->isChecked()){
                    ord = ORDER_BY::R_NAME;
                }else{
                    ord = ORDER_BY::NAME;
                }
            }else if(comboBox->currentText() == QString("Type")){
                if(revChckBx->isChecked()){
                    ord = ORDER_BY::R_TYPE;
                }else{
                    ord = ORDER_BY::TYPE;
                }            }else if(comboBox->currentText() == QString("Size")){
                if(revChckBx->isChecked()){
                    ord = ORDER_BY::R_SIZE;
                }else{
                    ord = ORDER_BY::SIZE;
                }            }else{// if(comboBox->currentText() == QString("Modification Date")){
                if(revChckBx->isChecked()){
                    ord = ORDER_BY::R_MOD_DATE;
                }else{
                    ord = ORDER_BY::MOD_DATE;
                }            }
            dialog->close();

            locked->sortAllFolders(ord);
        });
        connect(cancelBtn, &QPushButton::clicked,
                [=](){
            dialog->close();
        });

        int retVal = dialog->exec();
        qDebug() << "retVal: " << retVal;

    }
}

void GraphicsView::createNewFolder()
{
    if(auto locked = m_filesCoord.lock()){
        locked->createNewFolder();
    }
}

void GraphicsView::createNewFile()
{
    if(auto locked = m_filesCoord.lock()){
        locked->createNewFile();
    }
}

void GraphicsView::showRootSelector()
{
//    if(animationTimer && animationTimer->isActive()){
//        isLoading = false;
//        qDebug() << "stopping timer";
//        this->setCursor(QCursor(Qt::ArrowCursor));
//        animationTimer->stop();
//    }else{
//        qDebug() << "starting timer";
//        isLoading = true;
//        animationTimer->start(loadingPeriodMS);
//    }
    qDebug() << "show RootSelector";

    if(auto locked = m_filesCoord.lock()){
        QString curRootDir =locked->getCurRootPath();
        if( !curRootDir.isEmpty() ){
            DirectorySelectorDialog* dialog = new DirectorySelectorDialog(
                    curRootDir,
                    [=](QString filePath){
                        if(auto filesCoordLock = m_filesCoord.lock()){
                            filesCoordLock->setRootFolder(QDir(filePath));
                        }
                    }
            );
            dialog->show();
        }
    }
}

void GraphicsView::revalidateRowHeight()
{
    QFont _font(StaticFunctions::getGoshFont(m_fontSize));
    QFontMetrics fm(_font);
    m_rowHeight = fm.height() +6;
}
