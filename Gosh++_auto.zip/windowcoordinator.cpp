#include "windowcoordinator.h"

class FindDialog : public QDialog
{
public:
    FindDialog(int anzRects,
               const std::function<void(int)>& caller,
               ORIENTATION orientation,
               QWidget *parent = 0)
        : m_anzRects(anzRects),
          caller(caller),
          QDialog(parent)
    {
        if(orientation == ORIENTATION::HORIZONTAL){
            m_horizontal = true;
        }else{
            m_horizontal = false;
        }
        setAttribute(Qt::WA_TranslucentBackground);
        setModal(true);

        rects.append(nullptr);
        rects.append(nullptr);
        rects.append(nullptr);
        rects.append(nullptr);

        setMouseTracking(true);

        m_size = QSizeF(400,400);
        m_pos = QPointF(0,0);
        this->setMinimumSize((int)m_size.width(), (int)m_size.height());
        this->setMaximumSize((int)m_size.width(), (int)m_size.height());
        this->setWindowFlags(Qt::FramelessWindowHint | Qt::WindowSystemMenuHint);

        QPushButton* closeBtn = new QPushButton("close window");
        QObject::connect(closeBtn, &QPushButton::clicked, [=](){
            this->close();
        });

        QVBoxLayout* vBox = new QVBoxLayout();
        vBox->setAlignment(Qt::AlignBottom);
        vBox->addWidget(closeBtn);
        vBox->setContentsMargins(0, 0, 0, 0);
        this->setLayout(vBox);
    }
    ~FindDialog(){
        caller = nullptr;
        for(int i=0; i < rects.size(); i++){
            delete rects[i];
        }
        rects.clear();
    }
    QRectF boundingRect(){return QRectF(m_pos, m_size);}
protected:
    void paintEvent(QPaintEvent *event){
        Q_UNUSED(event)

        QPainter* painter = new QPainter(this);

        // gaaanz wichtig: erstmal painter an boundingRect clippen!!!:
        QRectF rct = boundingRect();

        painter->setRenderHint(QPainter::Antialiasing, true);

        painter->setClipRect(rct);

        QLinearGradient gradient(rct.topLeft(), rct.bottomRight());
        gradient.setColorAt(0, QColor(255,255,255, 150));
        gradient.setColorAt(1, QColor(220,220,255, 150));
        painter->fillRect(rct, gradient);

        if(m_anzRects == 1){
            if(!rects[0]){
                float fctr = 0.8;
                float wndwWdth = (float)rct.width()*fctr;
                float xStart = rct.x() + (rct.width()-wndwWdth)*0.5;
                float yStart = rct.y() + (rct.height()-wndwWdth)*0.5;
                QRect* wndwRct = new QRect(xStart,yStart, wndwWdth,wndwWdth);

                rects[0] = wndwRct;
            }
        }else if(m_anzRects == 2){
            float fctr = 0.9;
            float rctWidth = ((float)rct.width()) *0.4;
            float offs = ((float)rct.width())*(1.0-fctr)*0.5;

            if(m_horizontal){
                painter->drawLine(rct.left()+offs,
                                  rct.center().y(),
                                  rct.right()-offs,
                                  rct.center().y());
                if(!rects[0]){
                    QSize size(rctWidth, rctWidth);
                    QPoint p1, p2;
                    p1 = QPoint(rct.center().x()-rctWidth*0.5,
                              rct.top()+offs);
                    p2 = QPoint(rct.center().x()-rctWidth*0.5,
                              rct.bottom()-offs-rctWidth);
                    rects[0] = new QRect(p1, size);
                    rects[1] = new QRect(p2, size);
                }
            }else{
                painter->drawLine(rct.center().x(),
                                  rct.top()+offs,
                                  rct.center().x(),
                                  rct.bottom()-offs);

                if(!rects[0]){
                    QSize size(rctWidth, rctWidth);
                    QPoint p1, p2;
                    p1 = QPoint(rct.left()+offs,
                              rct.center().y()-rctWidth*0.5);
                    p2 = QPoint(rct.right()-offs-rctWidth,
                              rct.center().y()-rctWidth*0.5);
                    rects[0] = new QRect(p1, size);
                    rects[1] = new QRect(p2, size);
                }
            }
        }else if(m_anzRects == 3){
            float fctr = 0.9;
            float rctWidth = ((float)rct.width()) *0.4;
            float offs = ((float)rct.width())*(1.0-fctr)*0.5;
            if(m_horizontal){
                painter->drawLine(rct.left()+offs,
                                  rct.center().y(),
                                  rct.right()-offs,
                                  rct.center().y());
                painter->drawLine(rct.center().x(),
                                  rct.center().y(),
                                  rct.center().x(),
                                  rct.bottom()-offs);

                if(!rects[0]){
                    QSize size(rctWidth, rctWidth);
                    QPoint p1, p2, p3;
                    p1 = QPoint(rct.center().x()-rctWidth*0.5,
                              rct.top()+offs);
                    p2 = QPoint(rct.left()+offs,
                              rct.bottom()-offs-rctWidth);
                    p3 = QPoint(rct.right()-offs-rctWidth,
                              rct.bottom()-offs-rctWidth);

                    rects[0] = new QRect(p1, size);
                    rects[1] = new QRect(p2, size);
                    rects[2] = new QRect(p3, size);
                }
            }else{
                painter->drawLine(rct.center().x(),
                                  rct.top()+offs,
                                  rct.center().x(),
                                  rct.bottom()-offs);
                painter->drawLine(rct.center().x(),
                                  rct.center().y(),
                                  rct.right()-offs,
                                  rct.center().y());
                if(!rects[0]){
                    QSize size(rctWidth, rctWidth);
                    QPoint p1, p2, p3;
                    p1 = QPoint(rct.left()+offs,
                              rct.center().y()-rctWidth*0.5);
                    p2 = QPoint(rct.right()-offs-rctWidth,
                              rct.top()+offs);
                    p3 = QPoint(rct.right()-offs-rctWidth,
                              rct.bottom()-offs-rctWidth);

                    rects[0] = new QRect(p1, size);
                    rects[1] = new QRect(p2, size);
                    rects[2] = new QRect(p3, size);
                }
            }
        }else{ // == 4
            float fctr = 0.9;
            float rctWidth = ((float)rct.width()) *0.4;
            float offs = ((float)rct.width())*(1.0-fctr)*0.5;

            painter->drawLine(rct.left()+offs,
                              rct.center().y(),
                              rct.right()-offs,
                              rct.center().y());
            painter->drawLine(rct.center().x(),
                              rct.top()+offs,
                              rct.center().x(),
                              rct.bottom()-offs);
            if(!rects[0]){
                    QSize size(rctWidth, rctWidth);
                    QPoint p1, p2, p3, p4;
                    p1 = QPoint(rct.left()+offs,
                              rct.top()+offs);
                    p2 = QPoint(rct.right()-offs-rctWidth,
                              rct.top()+offs);
                    p3 = QPoint(rct.left()+offs,
                              rct.bottom()-offs-rctWidth);
                    p4 = QPoint(rct.right()-offs-rctWidth,
                              rct.bottom()-offs-rctWidth);
                rects[0] = new QRect(p1, size);
                rects[1] = new QRect(p2, size);
                rects[2] = new QRect(p3, size);
                rects[3] = new QRect(p4, size);
            }
            painter->drawRect(*rects[0]);
            painter->drawRect(*rects[1]);
            painter->drawRect(*rects[2]);
            painter->drawRect(*rects[3]);
        }
        for(int i=0; i < m_anzRects; i++){
            StaticFunctions::paintRect(painter, *rects[i]);
        }
        if(mouseRectId > -1 && rects[mouseRectId]){
            StaticFunctions::paintCrossRect(painter, *rects[mouseRectId]);
        }
        QDialog::paintEvent(event);
    }
    void mousePressEvent(QMouseEvent *event){
        QPointF mouP = event->pos();
        for(int i=0; i < m_anzRects; i++){
            if(rects[i] && caller
                    && rects[i]->contains(QPoint(mouP.x(), mouP.y()))){
                caller(i);
                this->close();
                this->deleteLater();
            }
        }
        qint64 curTime = QDateTime::currentMSecsSinceEpoch();
        if(curTime - lastTmePrsd < 300){

        }
        lastTmePrsd = curTime;
        isPressed = true;
        repaint();
//        update();
    }
    void mouseMoveEvent(QMouseEvent *event){
        m_hover = true;
        QPointF mouP = event->pos();
        mouseRectId = -1;
        for(int i=0; i < m_anzRects; i++){
            if(rects[i] && rects[i]->contains(QPoint(mouP.x(), mouP.y()))){
                mouseRectId = i;
                break;
            }
        }
//        update();
        repaint();
        return QWidget::mouseMoveEvent(event);
    }
private:
    QSizeF m_size;
    QPointF m_pos;

    bool m_hover = false;

    bool m_horizontal;

    int m_anzRects = 2;

    bool isPressed = false;
    qint64 lastTmePrsd = Q_INT64_C(0);

    QVector<QRect*> rects;
    int mouseRectId = -1;

    std::function<void(int)> caller;
};

WindowCoordinator::WindowCoordinator(QWidget *parent)
    : QWidget(parent),
      m_toolBar(new QHBoxLayout()),
      m_vBox(new QVBoxLayout())
{
    m_vBox->setContentsMargins(0, 0, 0, 0);
    m_vBox->setSpacing(0);

    this->setLayout(m_vBox);

    layout()->setContentsMargins(0, 0, 0, 0);

    addWindow();
}

WindowCoordinator::~WindowCoordinator()
{
    for(int i=0; i < m_windows.size(); i++){
        if(m_windows[i])
            m_windows[i].reset();
    }
    m_windows.clear();

    if(m_fullScreenCaller)
        m_fullScreenCaller.reset();
}

void WindowCoordinator::removeWindow(int id)
{
    if(id < m_windowCounter && id >= 0
            && m_windows.size() > 1){
        if(m_windows[id]){
            m_windows[id].reset();
        }
        m_windows.remove(id);
        --m_windowCounter;

        this->revalidateLayout();
    }
}

QSplitter* createSplitter(Qt::Orientation orientation){
    QSplitter* splitter = new QSplitter();
    splitter->setContentsMargins(0,0,0,0);
    splitter->setOrientation(orientation);
    return splitter;
}

void WindowCoordinator::addWindow()
{
    if(m_windowCounter < m_maxWindows){

        while(m_windows.size() < m_windowCounter+1){
            std::shared_ptr<FilesCoordinator> filesCoord = std::make_shared<FilesCoordinator>();
            filesCoord->setSelf(filesCoord);
            filesCoord->setThisToFolderViewer( filesCoord );
            if(m_initPath.size() > 0){
                filesCoord->setRootFolder(QDir(m_initPath[0]));
            }else{
                filesCoord->setRootFolder(QDir(tr("")));
            }
            m_windows.append(filesCoord);
        }

        ++m_windowCounter;

        revalidateLayout();
    }
}

void WindowCoordinator::setFullScreenCaller(std::shared_ptr<DynamicFunctionCaller<QString, std::function<void()>>> fullScreenCaller)
{
    m_fullScreenCaller = fullScreenCaller;
}

void WindowCoordinator::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event)
    QPainter* painter = new QPainter(this);
    painter->setBrush(QColor(255,255,255));
    painter->drawRect(QRect(0,0, this->width(), this->height()));
    QWidget::paintEvent(event);
}

void WindowCoordinator::keyPressEvent(QKeyEvent *event)
{
    qDebug() << "key pressed";
    if(event->key() == Qt::Key_F11){
        qDebug() << "in fullscreen pressed";
        setFullScreen();
    }
}


void addLayoutToSplitter(QSplitter* splitter, QLayout* widget){
    QWidget* wrpr = new QWidget();
    wrpr->setLayout(widget);
    splitter->addWidget(wrpr);
}
void addWidgetToSplitter(QSplitter* splitter, QWidget* widget){
    QVBoxLayout* vBox = new QVBoxLayout();
    vBox->addWidget(widget);
    vBox->setContentsMargins(3,3,3,3);
    addLayoutToSplitter(splitter, vBox);
}
void WindowCoordinator::revalidateLayout(){
    for(int i=0; i < m_windows.size(); i++){
        if(m_windows[i]){
            m_windows[i]->saveGraphicsViewHBarValue();
            m_windows[i]->saveGraphicsViewVBarValue();
        }
    }

    clearChilds();

    setToolBar();

    for(int i=0; i < m_windows.size(); i++){
        if(m_windows[i]){
            m_windows[i]->resetQWidgets();
            m_windows[i]->setThisToFolderViewer(m_windows[i]);
        }
    }

    if(m_windowCounter == 1){
        m_vBox->addLayout(m_windows[0]->getLayout());
    }else if(m_windowCounter == 2){
        QSplitter* splitter;
        if(m_orientation == ORIENTATION::HORIZONTAL){
            splitter = createSplitter(Qt::Vertical);
        }else{
            splitter = createSplitter(Qt::Horizontal);

        }
        addLayoutToSplitter(splitter, m_windows[0]->getLayout());
        addLayoutToSplitter(splitter, m_windows[1]->getLayout());

        m_vBox->addWidget(splitter);
    }else if(m_windowCounter == 3){
        QSplitter* hSplitter = createSplitter(Qt::Vertical);
        QSplitter* vSplitter = createSplitter(Qt::Horizontal);
        if(m_orientation == ORIENTATION::VERTICAL){
            addLayoutToSplitter(hSplitter, m_windows[1]->getLayout());
            addLayoutToSplitter(hSplitter, m_windows[2]->getLayout());

            addLayoutToSplitter(vSplitter, m_windows[0]->getLayout());
            addWidgetToSplitter(vSplitter, hSplitter);
            m_vBox->addWidget(vSplitter);
        }else{
            addLayoutToSplitter(vSplitter, m_windows[1]->getLayout());
            addLayoutToSplitter(vSplitter, m_windows[2]->getLayout());

            addLayoutToSplitter(hSplitter, m_windows[0]->getLayout());
            addWidgetToSplitter(hSplitter, vSplitter);
            m_vBox->addWidget(hSplitter);
        }
    }else if (m_windowCounter == 4){
        QSplitter* vSplitter = createSplitter(Qt::Horizontal);
        QSplitter* hSplitter1 = createSplitter(Qt::Vertical);
        QSplitter* hSplitter2 = createSplitter(Qt::Vertical);

        addLayoutToSplitter(hSplitter1, m_windows[0]->getLayout());
        addLayoutToSplitter(hSplitter1, m_windows[1]->getLayout());

        addLayoutToSplitter(hSplitter2, m_windows[2]->getLayout());
        addLayoutToSplitter(hSplitter2, m_windows[3]->getLayout());

        addWidgetToSplitter(vSplitter, hSplitter1);
        addWidgetToSplitter(vSplitter, hSplitter2);

        m_vBox->addWidget(vSplitter);
    }
}

void WindowCoordinator::clearChilds()
{
    StaticFunctions::removeChildrenFromLayout(m_vBox);
}

void WindowCoordinator::setFullScreen()
{
    m_isFullScreen = !m_isFullScreen;
    if(m_isFullScreen){
        if(m_fullScreenCaller && m_fullScreenCaller->containsFunction("setFullScreen")){
            m_fullScreenCaller->getFunction(QString("setFullScreen"))();
        }
    }else{
        if(m_fullScreenCaller && m_fullScreenCaller->containsFunction("setMaximized")){
            m_fullScreenCaller->getFunction(QString("setMaximized"))();
        }
    }
}

void WindowCoordinator::setToolBar()
{
    m_toolBar = new QHBoxLayout();
    m_toolBar->setAlignment(Qt::AlignLeft);
    m_toolBar->setSpacing(2);
    m_vBox->setContentsMargins(2, 2, 2, 2);

    if(m_windowCounter > 1){
        QPushButton* closeBtn = new QPushButton(QString("close window"));
        closeBtn->setFont(StaticFunctions::getGoshFont());
        QObject::connect(closeBtn, &QPushButton::clicked,[=](){
            auto caller = [=](int i){
                this->removeWindow(i);
            };
            (new FindDialog(m_windowCounter, caller, m_orientation,this))->show();
        }
        );
        closeBtn->setFixedWidth(120);
        m_toolBar->addWidget(closeBtn);

        // orientation button:
        if(m_windowCounter < 4){
            QString orientationStr = m_orientation == ORIENTATION::HORIZONTAL ?
                                    QString("set vertical orientation") :
                                    QString("set horizontal orientation");
            QPushButton* orientationBtn = new QPushButton( orientationStr );
            QObject::connect(orientationBtn, &QPushButton::clicked,[=](){
                if(m_orientation  == ORIENTATION::HORIZONTAL)
                    m_orientation = ORIENTATION::VERTICAL;
                else
                    m_orientation = ORIENTATION::HORIZONTAL;
                revalidateLayout();
            });
            orientationBtn->setFixedWidth(250);
            orientationBtn->setFont(StaticFunctions::getGoshFont());
            m_toolBar->addWidget(orientationBtn);
        }
    }

    if(m_windowCounter < 4){
        QPushButton* addBtn = new QPushButton(QString("add window"));
        QObject::connect(addBtn, &QPushButton::clicked,[=](){
            this->addWindow();
        });
        addBtn->setFixedWidth(150);
        addBtn->setFont(StaticFunctions::getGoshFont());
        m_toolBar->addWidget(addBtn);
    }


    QPushButton* fullscreenBtn = new QPushButton();
    fullscreenBtn->setFont(StaticFunctions::getGoshFont());
    if(m_isFullScreen){
        fullscreenBtn->setText(QString("exit fullscreen"));
        fullscreenBtn->setFixedWidth( 200 );
    }else{
        fullscreenBtn->setText(QString("fullscreen"));
        fullscreenBtn->setFixedWidth( 150 );
    }
    QObject::connect(fullscreenBtn, &QPushButton::clicked,[=](){
        this->setFullScreen();
        if(m_isFullScreen){
            fullscreenBtn->setText(QString("exit fullscreen"));
            fullscreenBtn->setFixedWidth( 200 );
        }else{
            fullscreenBtn->setText(QString("fullscreen"));
            fullscreenBtn->setFixedWidth( 150 );
        }
    });
    m_toolBar->addWidget(fullscreenBtn);

//    QPushButton* fakeBtn = new QPushButton(QString(""));
//    fakeBtn->setDisabled(true);
//    m_toolBar->addWidget(fakeBtn);

    m_vBox->addLayout(m_toolBar);
}
