#ifndef ELAPSEWORKER_H
#define ELAPSEWORKER_H

#include <QObject>
#include <QThread>
#include <QDebug>
#include <QString>
#include <QVector>
#include <QDir>
#include <QMutex>
#include "fileinfobd.h"

class ElapseWorker : public QObject
{
    Q_OBJECT
public:
    explicit ElapseWorker(QString path,
                          int elapseDepth = 0);
    ~ElapseWorker();
public slots:
    void process();
    void receiveSubFolderFromSubThread(FileInfoBD* subFoldToAdd);
signals:
    void sendingFiBdToReceiverThread(FileInfoBD* subFoldToAdd);
    void finished();
private:
    QString getFileInfoName();

    FileInfoBD* m_fiBD = nullptr;
    QString m_rootPath;
    int m_elapseDepth;
    int m_maxElapseDepth = 2;
    int m_threadCounter = 0;
};

#endif // ELAPSEWORKER_H
