#ifndef GRAPHICSVIEW_H
#define GRAPHICSVIEW_H

#include <QGraphicsScene>
#include <QGraphicsView>
#include <QScrollBar>
#include <QSize>
#include <QRect>
#include <QPoint>
#include <QFileInfo>
#include <QDebug>
#include <QObject>
#include <functional>
#include <QTimer>
#include <QKeyEvent>
#include <QResizeEvent>
#include <QLinearGradient>
#include <QRadialGradient>
#include <QComboBox>
#include <QCheckBox>
#include <QLabel>
#include <QVBoxLayout>
#include <QStyleOptionGraphicsItem>
#include <QGraphicsSceneMouseEvent>
#include <QGraphicsSceneHoverEvent>
#include <QGraphicsItemGroup>
#include <QWidget>
#include <QDir>
#include <QPixmap>
#include <memory>
#include <thread>
#include <atomic>
#include "math.h"
#include "filescoordinator.h"
#include "fileinfobd.h"
#include "graphicsfile.h"
#include "graphicsviewupdater.h"
#include "limits.h"
#include "dynamicfunctioncaller.h"
#include "directoryselectordialog.h"
#include "staticfunctions.h"

class GraphicsItemBD;
class TextRect;
class MenuBar;
class SearchMenuBD;
class WindowSelector;

class FilesCoordinator;

class GraphicsView : public GraphicsViewUpdater,
        public QGraphicsView
{
public:
    explicit GraphicsView(std::weak_ptr<FileInfoBD> m_fileInfoBD = std::weak_ptr<FileInfoBD>(),
                          QWidget *parent = nullptr);
    ~GraphicsView();

    void setRoot(std::weak_ptr<FileInfoBD> fi);

    void updateGraphicsView() override;

    void setFilesCoordinator(std::weak_ptr<FilesCoordinator> filesCoor);

    int getVScrollBarValue();
    int getHScrollBarValue();

public slots:
    void folderChanged(std::weak_ptr<const FileInfoBD> f = std::weak_ptr<FileInfoBD>());
    void revalidate();

    void focusId(int id, bool repaintAnyway = false);

    void vScrollValueChanged();
    void hScrollValueChanged();
    void setHBarValue(int hBarValue);
    void setVBarValue(int vBarValue);

    void setWaitingAnimation();
    protected:
     void keyPressEvent(QKeyEvent *event);
     void keyReleaseEvent(QKeyEvent *event);

     void resizeEvent(QResizeEvent *event);

     void mousePressEvent(QMouseEvent *event);
     void mouseMoveEvent(QMouseEvent *event);
private:
    void paintTopRectangle(const QPointF& center,
                           const QSize& size);

    int getFirstToDispFi();
    int getLastToDispFi();
    bool viewPortOutOfDisplayedRange();

    qreal getDisplayableHeight();
    void rePaintCanvas();

    void paintFileInfo(const QFileInfo& fi, int rowId=0, int colId=0,
                       std::shared_ptr<DynamicFunctionCaller<QString, std::function<bool()>>> caller=
                            std::shared_ptr<DynamicFunctionCaller<QString, std::function<bool()>>>(),
                       std::shared_ptr<DynamicFunctionCaller<QString, std::function<bool(ORDER_BY)>>> sortCaller
                            = std::shared_ptr<DynamicFunctionCaller<QString, std::function<bool(ORDER_BY)>>>());

    void iterateOverFileInfos(
            std::function<void(std::weak_ptr<FileInfoBD>,int,int)> dirFunc,
            std::function<void(std::weak_ptr<FileInfoBD>, const QFileInfo&,int,int)> fileFunc,
            int startId=0, int endId=INT_MAX);
    void iterateOverFileInfos_helper(
            std::weak_ptr<FileInfoBD> m_fileInfoBD,
            std::function<void(std::weak_ptr<FileInfoBD>,int,int)> dirFunc,
            std::function<void(std::weak_ptr<FileInfoBD>, const QFileInfo&,int,int)> fileFunc,
            int* curId,
            int startId=0,
            int endId=INT_MAX,
            int colId=0);

    qreal getRelativeHorBarValue();
    qreal getRelativeVerBarValue();
    int getAbsoluteHorBarValue();
    int getAbsoluteVerticalBarValue();
    int getViewportYOffset();

    void addSearchMenu();
    void launchSearchMode();
    void nextSearchResult();
    void prevSearchResult();
    void closeSearchMenu();
    QString getCurrentSearchResult();

    void addMenuBar();
    void closeMenuBar();

    void addContentBar();
    void closeContentBar();
    void addElapseBar();

    void zoomOut();
    void zoomIn();

    void sortAllFolders();

    void createNewFolder();
    void createNewFile();

    void showRootSelector();

    void revalidateRowHeight();

    QGraphicsScene m_scene;

    std::weak_ptr<FileInfoBD> m_fileInfoBD;

    int m_fontSize = 9;

    int m_rowHeight = 20;
    int m_colOffs = 15;

    int m_firstDispFI = 0;
    int m_lastDispFI = 0;
    int m_curDispFI = 0;
    int m_fileCount = 0;
    int m_fileMaxCount = 500;
    int m_filePuffer = 200;

    bool m_shft_prsd = false;
    bool m_alt_prsd = false;
    bool m_ctrl_prsd = false;

    QGraphicsItemGroup* m_graphicsGroup = new QGraphicsItemGroup();

//    WindowSelector* winSelctr = nullptr;
    SearchMenuBD* m_searchMenu = nullptr;
    MenuBar* m_menuBar = nullptr;
    MenuBar* m_contBar = nullptr;

    QPainterPath* m_upperRect = nullptr;
    int m_upperRectWidth = 40;
    QPoint* m_mouseP = nullptr;

    void closeAllSubMenus();

    bool m_paintUpperRect = false;
    bool m_paintSearchMenu = false;
    bool m_paintMenuBar = false;
    bool m_paintContBar = false;
    int m_searchMenuHeight = 50;
    int m_menuBarHeight = 40;
    int m_contBarWidth = 45;

    bool m_shwRtSel = true;
    TextRect* m_rotSlctr = nullptr;
    int m_rootSelWidth = 80;
    int m_rootSelHeight = 20;
    int m_elapseBarHeight = 20;

    std::weak_ptr<FilesCoordinator> m_filesCoord = std::weak_ptr<FilesCoordinator>();

    std::atomic<bool> m_isLoading;
    std::atomic<int> m_loadingId;
    int m_loadingLength = 90;
    int m_loadingPeriodMS = 20;
    QTimer* m_animationTimer;
};

#endif // GRAPHICSVIEW_H
