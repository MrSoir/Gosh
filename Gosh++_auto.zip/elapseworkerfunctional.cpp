#include "elapseworkerfunctional.h"

ElapseWorkerFunctional::ElapseWorkerFunctional(std::function<void()> caller,
                                               QString infoMessageStr,
                                               bool startThreadImmediately,
                                               QObject *parent)
    : m_caller(caller),
      m_infoMessageStr(infoMessageStr),
      QObject(parent)
{
    if(startThreadImmediately){
        start();
    }
}

ElapseWorkerFunctional::~ElapseWorkerFunctional()
{
    if(m_caller)
        m_caller = nullptr;
}

void ElapseWorkerFunctional::prepare()
{
    m_thread = new QThread;

    this->moveToThread(m_thread);
    connect(m_thread, &QThread::started,                 this, &ElapseWorkerFunctional::process, Qt::QueuedConnection);
    connect(this, &ElapseWorkerFunctional::finished,   m_thread, &QThread::quit, Qt::QueuedConnection);
    connect(this, &ElapseWorkerFunctional::finished,   this, &ElapseWorkerFunctional::deleteLater, Qt::QueuedConnection);
    connect(m_thread, &QThread::finished,                m_thread, &QThread::deleteLater, Qt::QueuedConnection);
    connect(this, &ElapseWorkerFunctional::kill,       this, &ElapseWorkerFunctional::finished, Qt::QueuedConnection);
    connect(this, &ElapseWorkerFunctional::kill,       m_thread, &QThread::quit, Qt::QueuedConnection);
    connect(this, &ElapseWorkerFunctional::kill,       this, [=](){qDebug() << "worker killed!";}, Qt::QueuedConnection);

    m_isPrepared = true;
}

void ElapseWorkerFunctional::start(){
    if( !m_isPrepared )
        prepare();

    m_thread->start();
}

void ElapseWorkerFunctional::process()
{
    if(m_caller)
        m_caller();
    emit finished();
}
