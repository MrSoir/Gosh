#ifndef GRAPHICSVIEWUPDATER_H
#define GRAPHICSVIEWUPDATER_H


class GraphicsViewUpdater
{
public:
    virtual void updateGraphicsView() = 0;
};

#endif // GRAPHICSVIEWUPDATER_H
