#ifndef WINDOWCOORDINATOR_H
#define WINDOWCOORDINATOR_H

#include <QObject>
#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QSplitter>
#include <QPaintEvent>
#include <QPainter>
#include <QDialog>
#include <memory>
#include <functional>
#include "filescoordinator.h"
#include "staticfunctions.h"

class FilesCoordinator;

enum ORIENTATION{HORIZONTAL, VERTICAL};

class WindowCoordinator : public QWidget
{
    Q_OBJECT
public:
    explicit WindowCoordinator(QWidget *parent = nullptr);
    ~WindowCoordinator();

    void removeWindow(int id = -1);
    void addWindow();

    void setFullScreenCaller(std::shared_ptr<DynamicFunctionCaller<QString, std::function<void()>>> fullScreenCaller);
signals:
public slots:
protected:
    void paintEvent(QPaintEvent *event) override;

    void keyPressEvent(QKeyEvent *event);
private:
    void revalidateLayout();
    void clearChilds();

    void setFullScreen();

    void setToolBar();

    QHBoxLayout* m_toolBar;

    QVBoxLayout* m_vBox;

    int m_windowCounter = 1;
    int m_maxWindows = 4;
    QVector<std::shared_ptr<FilesCoordinator>> m_windows;
    ORIENTATION m_orientation = ORIENTATION::VERTICAL;

//    QString m_initPath = "/home/bigdaddy/Documents/Python/Fluent_Code/testFold";
    QStringList m_initPath = QStandardPaths::standardLocations(QStandardPaths::StandardLocation::DocumentsLocation);
    std::shared_ptr<DynamicFunctionCaller<QString, std::function<void()>>> m_fullScreenCaller
             = std::shared_ptr<DynamicFunctionCaller<QString, std::function<void()>>>();

    bool m_isFullScreen = false;
};

#endif // WINDOWCOORDINATOR_H
