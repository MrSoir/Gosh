#include "elapseworker.h"

ElapseWorker::ElapseWorker(QString path,
                           int elapseDepth)
    : m_rootPath(path),
      m_elapseDepth(elapseDepth)
{
    qDebug() << "in elapseworker-CONstructor - " << getFileInfoName();
}

ElapseWorker::~ElapseWorker()
{
//    qDebug() << "in elapseworker-DEstructor - " << getFileInfoName();
}

void ElapseWorker::process()
{
    m_fiBD = new FileInfoBD(m_rootPath);
    m_fiBD->disableSignals(true);

    if(m_elapseDepth < m_maxElapseDepth){
        QVector<QThread*> threads;

        QDir rootDir(m_rootPath);
        if(rootDir.exists()){
            QFileInfoList subFolders = rootDir.entryInfoList(QDir::AllDirs | QDir::NoDotAndDotDot);

            QFileInfoList filesLst = rootDir.entryInfoList(QDir::Files | QDir::NoDotAndDotDot);
            m_fiBD->addFiles(filesLst);

            if(subFolders.size() > 0){
                m_fiBD->setElapsedFlag(true);
                m_fiBD->setLoadedFlag(true);
//                qDebug() << "thread: subFolders.size: " << subFolders.size();
                for(int i=0; i < subFolders.size(); i++){
                    ++m_threadCounter;
//                    qDebug() << "about to creat thread " << i;

                    QThread* thread = new QThread();
                    ElapseWorker* worker = new ElapseWorker(subFolders[i].absoluteFilePath(),
                                                            m_elapseDepth+1);
                    worker->moveToThread(thread);
                    connect(thread, &QThread::started,       worker, &ElapseWorker::process);
                    connect(worker, &ElapseWorker::finished, thread, &QThread::quit);
                    connect(worker, &ElapseWorker::finished, worker, &ElapseWorker::deleteLater);
                    connect(thread, &QThread::finished,      thread, &QThread::deleteLater);
                    connect(worker, &ElapseWorker::sendingFiBdToReceiverThread,
                            this,   &ElapseWorker::receiveSubFolderFromSubThread
                            , Qt::QueuedConnection);

                    threads.append(thread);
                }
                for(int i=0; i < threads.size(); i++){
                    threads[i]->start();
                }
                threads.clear();
            }else{
                m_fiBD->elapseAll();
                emit sendingFiBdToReceiverThread(m_fiBD);
                emit finished();
            }
        }
    }
    else{
//        qDebug() << "about to finish thread: << " << getFileInfoName();
        m_fiBD->elapseAll();
        emit sendingFiBdToReceiverThread(m_fiBD);
        emit finished();
    }
}

void ElapseWorker::receiveSubFolderFromSubThread(FileInfoBD *subFoldToAdd)
{
//    if(m_elapseDepth == 0){
//        qDebug() << "in addSubFiBDToRootFiBD - m_threadCounter: " << m_threadCounter
//                 << "   [" << getFileInfoName() << "] jklasdfhjhasldfhasdlf";
//    }

    m_fiBD->replaceSubFolder(subFoldToAdd);

    if(--m_threadCounter < 1){
//        qDebug() << "m_threadCounter == 0 -> finishing thread " << getFileInfoName();
        emit sendingFiBdToReceiverThread(m_fiBD);
        emit finished();
    }
}

QString ElapseWorker::getFileInfoName()
{
    if(m_fiBD){
        return m_fiBD->getFileInfo().fileName();
    }else{
        return QString("nullptr");
    }
}
