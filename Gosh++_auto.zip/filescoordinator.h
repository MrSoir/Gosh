#ifndef FILESCOORDINATOR_H
#define FILESCOORDINATOR_H

#include <QObject>
#include <QVector>
#include <QDir>
#include <QFileInfo>
#include <QTimer>
#include <QPushButton>
#include <QMessageBox>
#include <QIcon>
#include <QPixmap>
#include <QStringList>
#include <QFontMetrics>
#include <QPalette>
#include <QStack>
#include <QElapsedTimer>
#include <QProcess>

#include <memory>
#include <functional>

#include "graphicsview.h"
#include "fileinfobd.h"
#include "folderlistener.h"
#include "staticfunctions.h"
#include "elapseworker.h"
#include "elapseworkerfunctional.h"

class GraphicsView;
class FileInfoBD;

struct OneDimFilInfoDataPoint{
    OneDimFilInfoDataPoint(std::weak_ptr<FileInfoBD> fileInfoBD, bool isFolder, int fileCount = 0)
        :m_fileInfoBD(fileInfoBD), m_fileCount(fileCount), m_isFolder(isFolder)
    {
    }
    OneDimFilInfoDataPoint()
        : m_fileInfoBD(std::weak_ptr<FileInfoBD>()), m_fileCount(0), m_isFolder(false)
    {
    }

    bool operator==(const OneDimFilInfoDataPoint& vgl) const{
        if(vgl.m_fileCount == this->m_fileCount &&
           vgl.m_isFolder == this->m_isFolder){
            if(auto locked1 = vgl.m_fileInfoBD.lock()){
                if(auto locked2 = this->m_fileInfoBD.lock()){
                    return locked1 == locked2;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }else{
            return false;
        }
    }
    bool operator!=(const OneDimFilInfoDataPoint& vgl) const{
        if(vgl.m_fileCount == this->m_fileCount &&
           vgl.m_isFolder == this->m_isFolder){
            if(auto locked1 = vgl.m_fileInfoBD.lock()){
                if(auto locked2 = this->m_fileInfoBD.lock()){
                    return !(locked1 == locked2);
                }else{
                    return true;
                }
            }else{
                return true;
            }
        }else{
            return true;
        }
    }

    std::weak_ptr<FileInfoBD> m_fileInfoBD;
    int m_fileCount = 0;
    bool m_isFolder = false;
};
struct FilInfoForOneDim{
    FilInfoForOneDim(std::weak_ptr<FileInfoBD> fileInfoBD,
                     bool isFolder = true,
                     QString fileName = QString(""),
                     int depth = 0)
        : m_fileInfoBD(fileInfoBD), m_isFolder(isFolder), m_fileName(fileName), m_depth(depth)
    {
    }
    FilInfoForOneDim()
        : m_fileInfoBD(std::weak_ptr<FileInfoBD>()), m_fileName(QString("")), m_isFolder(false), m_depth(0)
    {
    }
    FilInfoForOneDim(std::shared_ptr<FilInfoForOneDim> sharedPtr)
        : m_fileInfoBD(sharedPtr->m_fileInfoBD),
          m_isFolder(sharedPtr->m_isFolder),
          m_fileName(sharedPtr->m_fileName),
          m_depth(sharedPtr->m_depth)
    {
    }

    ~FilInfoForOneDim(){
        m_fileInfoBD.reset();
    }

    bool operator==(const FilInfoForOneDim& vgl) const {
        if(vgl.m_fileName == this->m_fileName &&
           vgl.m_isFolder == this->m_isFolder){
            if(auto locked1 = vgl.m_fileInfoBD.lock()){
                if(auto locked2 = this->m_fileInfoBD.lock()){
                    return locked1 == locked2;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }else{
            return false;
        }
    }
    bool operator!=(const FilInfoForOneDim& vgl) const {
        if(vgl.m_fileName == this->m_fileName &&
           vgl.m_isFolder == this->m_isFolder){
            if(auto locked1 = vgl.m_fileInfoBD.lock()){
                if(auto locked2 = this->m_fileInfoBD.lock()){
                    return !(locked1 == locked2);
                }else{
                    return true;
                }
            }else{
                return true;
            }
        }else{
            return true;
        }
    }

    QString getAbsoluteFilePath() const{
        if (auto locked = m_fileInfoBD.lock()){
            if(m_isFolder){
                return locked->getFileInfo().absoluteFilePath();
            }else{
                return QString("%1%2%3")
                        .arg(locked->getFileInfo().absoluteFilePath())
                        .arg(QDir::separator())
                        .arg(m_fileName);
            }
        }
        return QString("");
    }
    QString getFileName(){
        if(m_isFolder){
            if(auto locked = m_fileInfoBD.lock()){
                return locked->getFileInfo().fileName();
            }else{
                return QString("");
            }
        }else{
            return m_fileName;
        }
    }

    std::weak_ptr<FileInfoBD> m_fileInfoBD;
    bool m_isFolder = false;
    int m_depth;
//    int m_fileId = 0;
    QString m_fileName;
};

class FilesCoordinator
        : public QObject, public FolderListener
{
    Q_OBJECT
public:
    FilesCoordinator(QObject* parent = nullptr);
    ~FilesCoordinator();

    void setThisToFolderViewer(std::shared_ptr<FilesCoordinator> selfReference);

    void setRootFolder(const QDir& dir);
    void setSelectionToRoot();
    void setLastPathToRoot();

    QWidget* getWidget();
    QLayout* getLayout();

    void elapseAll();
    void elapseFolder(std::weak_ptr<FileInfoBD> fiBD);
    void elapseFolderRecursive(std::weak_ptr<FileInfoBD> fiBD, bool blockRevalidating = true);
    void elapseFolders(const QVector<std::weak_ptr<FileInfoBD>>& folds);
    void elapseSelectedFolders();
    void collapseSelectedFolders();

    void copySelectedContent();
    void cutSelectedContent();
    void copyCutToClipboardHelper(bool deleteSourceAfterCopying = false);
    void duplicateSelectedContent();

    void pasteFromClipboard();
    void paste(QString paths, QString tarPath = QString(""));
    void pasteHelper(QString paths, QString tarPath = QString(""));
    void pasteHelper(QList<QUrl> urls, QString tarPath = QString(""));
    void pasteHelper(QVector<QString> paths, const QString tarPath = QString(""));

    void deleteSelectedContent();
    void openSelectedContent();

    void showDetailsOfSelectedContent();
    void renameSelectedContent();

    void createNewFolder();
    void createNewFile();
    void addNewFileFolderHelper(bool createFile);

    void initDragging(QString initiator);

    QVector<FilInfoForOneDim> selectedFolders() const;
    QVector<FilInfoForOneDim> selectedFiles() const;
    QVector<FilInfoForOneDim> selectedContent() const;

    bool isSelected(FilInfoForOneDim fold);

    void selectContent(FilInfoForOneDim cont, bool controlPrsd = false, bool shiftPrs = false);
//    void selectContent(FilInfoForOneDim file, bool controlPrsd = false, bool shiftPrs = false);
    void selectEntireContent();
    void deselectContent(FilInfoForOneDim fold);
    void clearContent();
    void selectButtonUp(bool ctrl_prsd, bool shft_prsd);
    void selectButtonDown(bool ctrl_prsd, bool shft_prsd);

    bool filesSelected();
    bool foldersSelected();
    bool contentSelected();
    bool singleFolderSelected();
    bool singleFileSelected();
    bool singleContentSelected();

    int selectionCounter();

    void revalidateSearchIds();
    void searchForKeyWord(QString keyword);
    void searchForBeginsWith(QString startWith);
    bool searchResultsEmpty();
    int  searchResultsFound();
    int  getSearchIndex();
    void nextSearchResult();
    void previousSearchResult();
    int getIndexOfCurrentSearchResult();
    QString getCurSearchResultStr();
    FilInfoForOneDim getCurSearchResult();
    bool isCurentSearchResult(FilInfoForOneDim fiForOneDim);
    void clearSearchResults();

    int getIdOfFirstDispParent(FilInfoForOneDim oneDimFi);

    int getMaxDepth();

    void elapseAllFoldersOfDepthId(int depthId);
    bool depthIdElapsed(int depthId);

    int getDepth();

    void sort(std::weak_ptr<FileInfoBD> fiBD, ORDER_BY order);
    bool isReversedSorted(std::weak_ptr<FileInfoBD> fiBD);
    void sortAllFolders(ORDER_BY order);

    void openSelection();
    void setParentToRoot();

    FilInfoForOneDim getFileAt(int id);
    FilInfoForOneDim getDisplayedFileAt(int id);

    int getFileCount();
    int getDisplayedFileCount();


    void setSelf(std::shared_ptr<FilesCoordinator> self);

    void resetQWidgets();

    void saveGraphicsViewVBarValue();
    void saveGraphicsViewHBarValue();

    void forceRevalidation();

    QString getCurRootPath();
public slots:
    void repaintFolderViewer();
    void setWaitingAnimation(bool wait);

    void folderChanged(std::weak_ptr<FileInfoBD> f) override;
    void folderElapsed(std::weak_ptr<FileInfoBD> f) override;
    void sortingChanged(std::weak_ptr<FileInfoBD> f) override;
    void addDirectoryToWatcher(QString directory) override;

    void directoryChanged(QString path);
signals:
private:
    void setRootToGraphicsView();

    ElapseWorkerFunctional *launchElapseWorkerFunctional(std::function<void()>  caller, QString infoMessage, bool launchThread = true);

    std::function<void(FilInfoForOneDim)> getSelectionFunction();
//    int getIdOf(FilInfoForOneDim fileInfOneDim) const;
//    int getIdOfDisp(FilInfoForOneDim fileInfOneDim) const;

    int getIdOf(FilInfoForOneDim fileInfOneDim, bool searchInDisplayedContent = true) const;
    int getIdOf(std::shared_ptr<FilInfoForOneDim> fileInfOneDim, bool searchInDisplayedContent = true) const;

    void focusFolderViewer(int id, bool repaintAnyway = false);

    bool containsFile(QFileInfo file);

    int evaluateDepth(std::weak_ptr<FileInfoBD> filInfo, int* curRow, int curDepth = 0);
    void revalidateOneDimnFolderOrder();

    std::shared_ptr<FilInfoForOneDim> iterateBackwards(FilInfoForOneDim fileInfoOneDim, int offs,
                                                       std::function<void(FilInfoForOneDim)> func = nullptr);
    std::shared_ptr<FilInfoForOneDim> iterateForwards(FilInfoForOneDim fileInfoOneDim, int offs,
                                                      std::function<void(FilInfoForOneDim)> func = nullptr);
    std::shared_ptr<FilInfoForOneDim> iterateForwBackwHelper(FilInfoForOneDim fileInfoOneDim, int offs,
                                                             bool iterateForwards,
                                                             std::function<void(FilInfoForOneDim)> func = nullptr);

    void printSelectedFolders();
    void printSelectedFiles();

    void revalidateToolBar();

//    void repaintFolderViewer();
    GraphicsView* m_folderViewer;

    QGridLayout* m_mainGrid;
    QHBoxLayout* m_toolBar;

    std::shared_ptr<FileInfoBD> m_root;
    QList<FilInfoForOneDim> m_oneDimnFolderOrder;
    QList<FilInfoForOneDim> m_oneDimnFolderOrderDisplayed;

    QList<FilInfoForOneDim> m_slctdFolds;
    QList<FilInfoForOneDim> m_slctdFiles;
    FilInfoForOneDim m_lastSelection;

    QStack<QString> m_dirStack;

    QVector<FilInfoForOneDim> m_searchResults;
    QVector<int> m_searchIds;
    int m_searchIndex = -1;

    std::shared_ptr<QFileSystemWatcher> m_watcher = std::make_shared<QFileSystemWatcher>();
    std::shared_ptr<QMetaObject::Connection> m_watcherConn = std::make_shared<QMetaObject::Connection>();

    QVector<bool> m_depthIdsElapsed;

    bool m_blockRevalidating = false;

    std::weak_ptr<FilesCoordinator> m_self;

    int m_graphicsViewVBarValueBackup = 0;
    int m_graphicsViewHBarValueBackup = 0;

    int m_maxDepth = 0;
};

#endif // FILESCOORDINATOR_H
