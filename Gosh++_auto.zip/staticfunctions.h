#ifndef STATICFUNCTIONS_H
#define STATICFUNCTIONS_H

#include <QString>
#include <QLayout>
#include <QWidget>
#include <QPoint>
#include <QFileInfo>
#include <QFile>
#include <QDir>
#include <QInputDialog>
#include <QErrorMessage>
#include <QFileIconProvider>
#include <QVector>
#include <QLayoutItem>
#include <QPainter>
#include <QDebug>
#include <QGraphicsItem>
#include <QDateTime>
#include <memory>

#include <qmath.h>
#include <orderby.h>

namespace StaticFunctions {

    void setIconToWidget(QWidget* widget);

    QFont getGoshFont(int fontSize = 8, int weight = QFont::Bold);
    QColor getGoshBlueColor();

    QString getFileType(const QString& fileName);
    QString getFileTypeWithDot(const QString& fileName);
    QString getFileNameWithoutFileType(const QString& fileName);

    void removeChildrenFromLayout(QLayout* lay, const QVector<QLayoutItem*>& notToDelete = QVector<QLayoutItem*>());

    void deleteLayoutandContainingWidgets(QLayout* lay, QLayout* parent=nullptr);
    void deleteLayoutandContentsFromWidget(QWidget* widget, QLayout* parent=nullptr);

    QPoint rotatePoint(const QPoint& p, const QPoint& center, float angle);

    QIcon getFileIcon(const QFileInfo& info);

    //-------------------------------------------------------------------------------------------------------

    QString getUniqueFileName  (const QString& dirName, const QString& fileName);
    QString getUniqueFolderName(const QString& path,    const QString& foldName);

    bool copyFile  (const QString& absSourcePath, const QString& tarPath, const QString& tarName);
    bool copyFolder(const QString& absSourcePath, const QString& tarPath, const QString& tarName);

    bool duplicateFile  (const QFileInfo& source);
    bool duplicateFolder(const QFileInfo& source);

    bool deleteFile  (const QFileInfo& path);
    bool deleteFolder(const QFileInfo& path);

    bool renameFolder(const QFileInfo& path);

    bool zipFile(const QVector<QFileInfo>& absSourcePaths, const QString& tarPath, const QString& tarName);
    bool unZipFile(const QFileInfo& absSourcePath, const QString& tarPath, const QString& tarName);

    bool createNewFolder(const QString& tarPath, QString& foldName);
    bool createNewFile(const QString &tarPath, QString &fileName);
    //-------------------------------------------------------------------------------------------------------

    QRect qRectF_to_qRect(const QRectF& rectF);
    QRectF qRect_to_qRectF(const QRect& rct);
    void paintCrossRect(QPainter *painter, const QRectF& rct);
    void paintCrossRect(QPainter *painter, const QRect& rct);

    void paintArrowUpDown(QPainter *painter, const QRectF& rct, bool up);
    void paintArrowUp(QPainter *painter, const QRectF& rct);
    void paintArrowDown(QPainter *painter, const QRectF& rct);

    void paintRect(QPainter *painter, const QRectF& rct);
    void paintRect(QPainter *painter, const QRect& rct);

    void paintRect(QPainter *painter, const QRectF& rct,
                   const QColor& gradCol1, const QColor& gradCol2 = nullptr,
                   const QColor& penColor = QColor(0,0,0, 70),
                   int bordWidth = 1);
    void paintTextRect(QPainter *painter, const QString& str,
                       const QRectF& rct,
                       const QColor& gradCol1, const QColor& gradCol2 = nullptr,
                       const QColor& textCol = QColor(0,0,0),
                       const QFont font = StaticFunctions::getGoshFont(7),
                       const QColor& borderCol = QColor(0,0,0),
                       int bordWidth = 1);

    void paintPixmapRect(QPainter *painter, const QPixmap& pixmap,
                       const QRectF& rct,
                       const QColor& gradCol1, const QColor& gradCol2 = nullptr,
                       const QColor& borderCol = QColor(0,0,0),
                       int bordWidth = 1);


    enum SHAPE{PLUS, MINUS, NONE};
    void paintLoupe(QPainter *painter, const QRectF& rct, SHAPE shape = SHAPE::NONE);

    void paintPixmap(QPainter *painter, const QRectF& target, QString imgPath);


    //-----------------------------------------------------------------------------------



    template<class T>
    bool contains(const QVector<std::weak_ptr<T>>& vec, std::weak_ptr<T> tar){
        auto it = std::find_if(vec.begin(), vec.end(),
                               [&](std::weak_ptr<T> ref1){
                if(auto sp1 = ref1.lock()){
                    if(auto sp2 = tar.lock()){
                        return sp1 == sp2;
                    }
                    return false;
                }
                return false;
        });
        return !(it == vec.end());
    }
    template<class T>
    bool contains(const QVector<std::shared_ptr<T>>& vec, std::weak_ptr<T> tar){
        auto it = std::find_if(vec.begin(), vec.end(),
                               [&](std::weak_ptr<T> sp1){
                if(auto sp2 = tar.lock()){
                    return sp1 == sp2;
                }
                return false;
        });
        return !(it == vec.end());
    }

    template<class T>
    int indexOf(const QVector<std::weak_ptr<T>>& vec, std::weak_ptr<T> tar){
        int id = -1;
        int counter = 0;
        std::find_if(vec.begin(), vec.end(),
                               [&](std::weak_ptr<T> ref1){
                if(auto sp1 = ref1.lock()){
                    if(auto sp2 = tar.lock()){
                        id = counter;
                        return sp1 == sp2;
                    }
                }
                ++counter;
                return false;
        });
        return id;
    }
    template<class T>
    int indexOf(const QVector<std::shared_ptr<T>>& vec, std::weak_ptr<T> tar){
        int id = -1;
        int counter = 0;
        std::find_if(vec.begin(), vec.end(),
                               [&](std::shared_ptr<T> sp1){
                if(auto sp2 = tar.lock()){
                    id = counter;
                    return sp1 == sp2;
                }
                ++counter;
                return false;
        });
        return id;
    }

    template<class T>
    bool removeOne(QVector<std::weak_ptr<T>>& vec, std::weak_ptr<T> tar){
        int id = indexOf(vec, tar);
        if(id > -1){
            vec.removeAt(id);
            return true;
        }
        return false;
    }

    template<class T>
    bool removeOne(QVector<std::shared_ptr<T>>& vec, std::weak_ptr<T> tar){
        int id = indexOf(vec, tar);
        if(id > -1){
            vec.removeAt(id);
            return true;
        }
        return false;
    }

//    ---------------------------------------------------------------------------------------------

    ORDER_BY getOppositeOfOrder(ORDER_BY order);


//    ---------------------------------------------------------------------------------------------

}

class GraphicsItemBD : public QGraphicsItem{
public:
    GraphicsItemBD(const QSize& size = QSize(0,0),
                   const QPoint& pos = QPoint(0,0),
                   QGraphicsItem* parent = nullptr)
        : QGraphicsItem(parent),
          m_size(size),
          m_pos(pos)
    {
        setAcceptHoverEvents(true);
    }
//    virtual void setRelPositionAndSize(int viewPortXoffs,
//                                           int viewPortYoffs,
//                                           int viewPortWidth,
//                                           int viewPortHeight) = 0;
    void setSize(QSize size){
        m_size = size;
        revalidate = true;
        update();
    }
    void setPosition(QPoint position){
        m_pos = position;
        revalidate = true;
        update();
    }
    QRectF boundingRect() const {
        return QRectF(m_pos, m_size);
    }
protected:
    QSize m_size;
    QPoint m_pos;

    bool revalidate = true;
};
class TextRect : public GraphicsItemBD{
public:
    TextRect(QString str,
             const QSize& size,
             const QPoint& pos,
             const QColor& gradCol1,
             const QColor& gradCol2,
             const QColor& selectionCol1 = QColor(255,255,255),
             const QColor& selectionCol2 = QColor(255,255,255),
             const QColor& textCol = QColor(0,0,0),
             const QFont& font = StaticFunctions::getGoshFont(),
             QGraphicsItem* parent = nullptr)
        : GraphicsItemBD(size, pos, parent),
          m_str(str),
          m_gradCol1(gradCol1),
          m_gradCol2(gradCol2),
          m_selectCol1(selectionCol1),
          m_selectCol2(selectionCol2),
          m_textCol(textCol),
          m_font(font)
    {
        setAcceptHoverEvents(true);
    }
    ~TextRect(){
    }
    void setCallFunction(std::function<void()> callFunc){
        m_callFunc = callFunc;
    }
//    void setRelPositionAndSize(int viewPortXoffs,
//                               int viewPortYoffs,
//                               int viewPortWidth,
//                               int viewPortHeight){

//    }

    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget){
        Q_UNUSED(widget)
        Q_UNUSED(option)

        // gaaanz wichtig: erstmal painter an boundingRect clippen!!!:
        QRectF rct = boundingRect();

        painter->setRenderHint(QPainter::Antialiasing, true);

        painter->setClipRect(rct);

        QColor grad1, grad2;
        if(mouIn){
            grad1 = m_selectCol1;
            grad2 = m_selectCol2;
        }else{
            grad1 = m_gradCol1;
            grad2 = m_gradCol2;
        }
        StaticFunctions::paintTextRect(painter, m_str,
                      rct,
                      grad1, grad2,
                      m_textCol,
                      m_font);
    }
    void mousePressEvent(QGraphicsSceneMouseEvent *event){
        if(m_callFunc)
            m_callFunc();

//        QPointF mouP = event->pos();
//        qint64 curTime = QDateTime::currentMSecsSinceEpoch();
//        if(curTime - lastTmePrsd < 300){

//        }
//        lastTmePrsd = curTime;
//        update();
        QGraphicsItem::mousePressEvent(event);
    }
    void hoverEnterEvent(QGraphicsSceneHoverEvent *event){
        Q_UNUSED(event)
        mouIn = true;
        update();
    }
    void hoverLeaveEvent(QGraphicsSceneHoverEvent *event){
        Q_UNUSED(event)
        mouIn = false;
        update();
    }
    void hoverMoveEvent(QGraphicsSceneHoverEvent * event){
        Q_UNUSED(event)
    }
private:
    QString m_str;
    QColor m_gradCol1;
    QColor m_gradCol2;
    QColor m_selectCol1;
    QColor m_selectCol2;
    QColor m_textCol;
    QFont m_font;

    bool mouIn = false;
    std::function<void()> m_callFunc;

    qint64 lastTmePrsd = QDateTime::currentMSecsSinceEpoch();
};

#endif // STATICFUNCTIONS_H
