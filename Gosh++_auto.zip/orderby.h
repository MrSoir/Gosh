#ifndef ORDERBY_H
#define ORDERBY_H

enum ORDER_BY{  NAME,   MOD_DATE,   SIZE,     TYPE,
              R_NAME, R_MOD_DATE, R_SIZE,   R_TYPE};

#endif // ORDERBY_H
